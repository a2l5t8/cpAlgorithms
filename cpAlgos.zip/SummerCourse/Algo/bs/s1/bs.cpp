#include<bits/stdc++.h>

using namespace std;

const int maxn = 1e5 + 7;

int a[maxn];

int n,k;

bool bs(int v)
{
	int l = 0;
	int r = n;
	
	while(r >= l)
	{
		int mid = (l+r)/2;

		if(a[mid] == v)
			return true;
	
		if(a[mid] < v)
			l = mid + 1;
		else 
			r = mid - 1;
	}

	return false;
}

int main()
{
	cin>>n>>k;

	for(int i=0;i<n;i++)
		cin>>a[i];

	while(k--)
	{
		int c;
		cin>>c;

		if(bs(c))
			cout<<"YES\n";
		else 
			cout<<"NO\n";
	}
	
	return 0;
}	
