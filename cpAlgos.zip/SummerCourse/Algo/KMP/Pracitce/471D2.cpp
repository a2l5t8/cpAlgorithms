#include <bits/stdc++.h>

using namespace std;

const int maxn = 2e5 + 7;

int n, m, ans, match;

int a[maxn], b[maxn];
int f[maxn];

int main()
{
	cin>>n>>m;
	for(int i=0 ; i<n ; i++)
		cin >> a[i];

	for(int i=0 ; i<m ; i++)
		cin >> b[i];
	
	if(m == 1){
		cout << n << endl;
		return 0;
	}

	if(m > n){
		cout << "0" << endl;
		return 0;
	}

	n--, m--;
	for(int i=1 ; i<m ; i++)
	{
		while(match > 0 && b[i+1]-b[i] != b[match+1]-b[match])
			match = f[match-1];

		if(b[i+1]-b[i] == b[match+1]-b[match])
			match++;

		f[i] = match;
	}

	match = 0;
	for(int i=0 ; i<n ; i++)
	{
		while(match > 0 && a[i+1]-a[i] != b[match+1]-b[match])
			match = f[match-1];

		if(a[i+1]-a[i] == b[match+1]-b[match])
			match++;

		if(m == match)
		{
			match = f[match-1];
			ans++;
		}
	}

	cout<<ans<<"\n";

	return 0;
}

