#include<bits/stdc++.h>

using namespace std;

#define int long long

const int maxn = 1e5 + 7;
const int mod = 1e9 + 7;

int seg[maxn*4],lazy[maxn*4];

int n,q;

void show_seg(int s,int e,int id)
{
	cout<<"["<<s<<", "<<e<<") :"<<seg[id]<<"\n";
}

void build(int s=0,int e=n,int id=1)
{
	if(e - s < 2) {
		seg[id] = 1ll;
//		show_seg(s,e,id);
		return;
	}
	
	int mid = (s+e)/2ll;

	build(s,mid,id*2);
	build(mid,e,id*2 + 1);

	seg[id] = (seg[id*2] + seg[id*2 + 1])%mod;
}

void shift(int s,int e,int id)
{
	if(lazy[id] == 1ll)
		return;
	
	seg[id] = (seg[id]* lazy[id])%mod;
	if(e - s < 2) {
		lazy[id] = 1ll;
		return;
	}

	lazy[id*2] = (lazy[id*2] * lazy[id])%mod;
	lazy[id*2 + 1] = (lazy[id*2+1] * lazy[id])%mod;

	lazy[id] = 1ll;
}

void update(int l,int r,int v,int s=0,int e=n,int id=1)
{
	if(l >= e || r <= s)
		return;

	shift(s,e,id);

//	show_seg(s,e,id);
	
	if(l <= s && r >= e) {
		lazy[id] = (lazy[id]* v)%mod;
		shift(s,e,id);
		return;
	}
	
	int mid = (s+e)/2;

	update(l,r,v,s,mid,id*2);
	update(l,r,v,mid,e,id*2 + 1);

	seg[id] = (seg[id*2]  + seg[id*2 + 1])%mod;
}

int sum(int l,int r,int s=0,int e=n,int id=1)
{	
	if(l >= e || r <= s)
		return 0;

	shift(s,e,id);

	if(l <= s && r >= e)
		return seg[id];
	
	int mid = (s+e)/2;

	return (sum(l,r,s,mid,id*2)
		  +sum(l,r,mid,e,id*2 + 1))%mod;
}

int32_t main()
{
	cin>>n>>q;

	build();

	for(int i=1;i<(maxn*4);i++)
		lazy[i] = 1;

	while(q--)
	{
		int command;
		cin>>command;

		if(command == 1)
		{
			int l,r,v;
			cin>>l>>r>>v;

			update(l,r,v);
		}else {
			int l,r;
			cin>>l>>r;
			
			cout<<sum(l,r)<<"\n";
		}
	}

	return 0;
}

