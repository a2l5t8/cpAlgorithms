#include<bits/stdc++.h>

using namespace std;

double INF = 1e5 + 7;

double c;

bool equation(double v)
{
	double res = v*v + sqrt(v);
	
	return (res >= c);
}

void solve()
{
	double l = 0.0;
	double r = INF;

	double ans = 0;
	while(r - l > 0.000001)
	{
		double mid = (l+r)/2;
		
		if(equation(mid))
			r = mid,ans = mid;
		else
			l = mid;
	}
	
	cout<<setprecision(6)<<fixed<<ans<<"\n";
}

int main()
{
	cin>>c;

	solve();

	return 0;
}
