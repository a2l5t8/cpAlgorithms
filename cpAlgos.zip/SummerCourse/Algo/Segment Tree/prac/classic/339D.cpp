#include<bits/stdc++.h>

using namespace std;

#define pb push_back
#define F first
#define S second
#define debug(x) cerr<<#x<<" :"<<x<<"\n"
#define debug_seg(s,e) cerr<<"["<<s<<", "<<e<<"]\n"
#define all(x) x.begin(),x.end()
#define pii pair<int,int>
#define FAST ios_base::sync_with_stdio(false), cin.tie(), cout.tie()
#define int long long

typedef long long ll;
typedef long double ld;

const int maxn = 19;
const int mod = 1e9 + 7;
const int INF = 1e9 + 7;
const int mlog = 22;
const int SQ = 400;

int seg[1<<maxn];
int a[1<<maxn];

int n,q;

void BUILD(int s=0,int e = (1<<n),int id=1,int depth=((n+1)%2))
{
	if(e - s < 2 )
	{
		seg[id] = a[s];
		return;
	}

	int mid = (s+e)/2;

	BUILD(s,mid,id*2,depth+1);
	BUILD(mid,e,id*2 + 1,depth+1);
	
	if(depth % 2 == 0)
		seg[id] = (seg[id*2] | seg[id*2 + 1]);
	else 
		seg[id] = (seg[id*2] ^ seg[id*2 + 1]);
}

void UPDATE(int index,int val, int s=0,int e=(1<<n),int id=1,int depth=((n+1)%2))
{
	if(index < s || index >= e)
		return;

	if(e - s < 2)
	{
		seg[id] = val;
		return;
	}
	
	int mid = (s+e)/2;

	UPDATE(index,val,s,mid,id*2,depth+1);
	UPDATE(index,val,mid,e,id*2 + 1,depth+1);

	if(depth%2 == 0)
		seg[id] = (seg[id*2] | seg[id*2 + 1]);
	else 
		seg[id] = (seg[id*2] ^ seg[id*2 + 1]);
}

int32_t main()
{
	cin>>n>>q;
	for(int i=0;i<(1<<n);i++)
		cin>>a[i];

	BUILD();

	while(q--)
	{
		int p,b;
		cin>>p>>b;
		p--;

		UPDATE(p,b);
		cout<<seg[1]<<"\n";
	}

	return 0;
}
