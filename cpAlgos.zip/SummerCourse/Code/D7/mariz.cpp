#include<bits/stdc++.h>

using namespace std;

const int maxn = 3e5 + 7;

int h[maxn],dp[maxn],par[maxn],maxh[maxn],mark[maxn];
vector<int> adj[maxn];

int n,m,s,e;	

int to_e;
int to_s;
void findway(int v)
{
	if(v == e) {
		to_s = par[v];
		return;
	}
	for(auto u : adj[v]) {
		if(u != par[v]) {
			par[u] = v;
			findway(u);
		}
	}
}

int forb,forb2;
void dfs(int v,int par = -1,int st = s)
{
	mark[v] = 1;
	for(auto u : adj[v])
	{
		if(u != par && (u != forb && u != forb2))
		{
			h[u] = h[v] + 1;

			dfs(u,v,st);

			maxh[v] = max(maxh[v],maxh[u] + 1);
			int dps = maxh[v] + adj[v].size() - 1 -1 ;
//			if(v == st)
//				dps--;

			dp[v] = max(dps, dp[u] + 1);
		}
	}
}

void pro_dfs(int v,int par = -1,int st = s)
{
	if(v == forb2)
		return;

	int unseen = 0;
	for(int u : adj[v])
		if(!mark[u] && u != par)
			unseen++;
	
//	cout<<v<<" : "<<unseen<<" <==\n";
	for(auto u : adj[v])
	{
		if(!mark[u] && u != par)
		{
			h[u] = h[v] + 1;

			pro_dfs(u,v,st);
			
			maxh[v] = max(maxh[v],maxh[u] + 1);
			int dps = maxh[v] + unseen-1;
//			cout<<v<<" :"<<dps<<" <||||||||> \n";
//			if(v == st)
//				dps = 1;
			
			dp[v] = max(dps,dp[u] + 1);

			cout<<v<<" :"<<dp[v]<<" ----------\n";
		}
	}
}

int dp2[maxn];
void reach(int v,int par,int t)
{
	int infect = 0;
	for(int u : adj[v])
		if(u != par && !mark[u] && dp[u] > t)
			infect++;
	for(int u : adj[v])
	{
		if(!mark[u] && u != par && dp[u] > t)
		{
			h[u] = h[v] + 1;
			reach(u,v,t);

			maxh[v] = max(maxh[v],maxh[u] + 1);
			int dps = maxh[v] + infect-1;
//			if(v == e)
//				dps = 1;
			
			dp2[v] = max(max(dps,dp2[v]),dp[u] + 1);
		}
	}
}

bool canReach(int t)
{
	for(int i=0;i<=n;i++)
		dp2[i] = maxh[i] = h[i] = 0;

	reach(e,-1,t);
	
	cout<<t<<" :"<<dp2[e]<<"\n";
	if(dp2[e] > t)
		return false;
	return true;
}

int t1,t2;
void solve()
{
	for(int i=0;i<=n;i++)
		h[i] = maxh[i] = dp2[i] = 0;

	int l = max(t1,t2);
	int r = maxn;
	
	int ans = l;
	while(r >= l)
	{
		int mid = (l+r)/2;
		if(canReach(mid))
			r = mid-1,ans = mid;
		else
			l = mid+1;
	}

	cout<<ans<<"\n";
}

int main()
{
	cin>>n>>s>>e;
	m = n-1;
	
	for(int i=0;i<m;i++)
	{
		int u,v;
		cin>>u>>v;

		adj[u].push_back(v);
		adj[v].push_back(u);
	}

	findway(s);
	int x = e;
	while(true)
	{
		if(par[x] == s) {
			to_e = x;
			break;
		}

		x = par[x];
	}

	forb = to_e;
	forb2 = e;

//	cout<<forb<<" "<<forb2<<" <--\n";
	dfs(s,-1,s);

	forb = to_s;
	forb2 = s;

//	cout<<forb<<" "<<forb2<<" <--\n";
	dfs(e,-1,e);

	t1 = dp[s];
	t2 = dp[e];

//	cout<<t1<<" "<<t2<<"\n";

	for(int i=1;i<=n;i++)
		maxh[i] = dp[i] = h[i] = 0;
	
	forb = to_e;
	forb2 = e;
	pro_dfs(s,-1,s);
	
	solve();
}
