#include<bits/stdc++.h>

using namespace std;

int main()
{
	string s;
	cin>>s;

	int n = s.size();

	stack<int> st;

	for(int i=1;i<n;i++)
	{
		while(!st.empty())
		{
			int j = st.top();
			if(s[j] < s[i])
				st.pop();
			else 
				break;
		}
		st.push(i);
	}

	string ans ="";
	while(!st.empty())
	{
		ans += s[st.top()];
		st.pop();
	}

	reverse(ans.begin(),ans.end());
	cout<<ans;
	
	return 0;
}
