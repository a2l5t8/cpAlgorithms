#include<bits/stdc++.h>

using namespace std;

const int maxn = 1e5 + 7;
const int INF = 1e7 + 7;

double a[maxn];

int n,d;

double ps[maxn];

pair<double,int> m[maxn];

int L,R;
bool maximid(double x)
{	

	for(int i=2;i<=n+1;i++)
		ps[i] = ps[i-1] + (a[i-1]-x);
		
	for(int i=0;i<=n+1;i++)
		m[i].first = 1.0*INF;
	
	m[1].second = 1;
	for(int i=1;i<=n+1;i++)
	{
		if(m[i-1].first < ps[i])
			m[i] = m[i-1];
		else 
			m[i] = {ps[i],i};

//		cout<<m[i].first<<" "<<m[i].second<<"\n";
	}

	for(int r = d+1;r<=n+1;r++) {
		if(m[r-d].first <= ps[r]) {
			L = m[r-d].second;
			R = r-1;
			return true;
		}
	}
	return false;
}

void solve()
{
	double l = 0;
	double r = INF;
	
	double ans;
	while(r - l > 0.00001)
	{
		double mid = (l+r)/2;
		if(maximid(mid)) 
			l = mid,ans = mid;
		else 
			r = mid;

//		cout<<mid<<"\n";
	}

	maximid(ans);
	
//	cout<<"\n";
	cout<<L<<" "<<R<<"\n";
}

int main()
{
	cin>>n>>d;

	for(int i=1;i<=n;i++)
		cin>>a[i];

	solve();

	return 0;
}

/*
10 1
29 52 44 91 78 12 7 53 39 69


*/
