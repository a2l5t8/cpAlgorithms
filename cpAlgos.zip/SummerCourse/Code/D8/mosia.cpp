#include<bits/stdc++.h>

using namespace std;

const int maxn = 2e5 + 7;

int n,m,k;
int root;

vector<int> adj[maxn];

int cult[maxn],h[maxn];

int hamgp[maxn];
int dis[maxn];

void dfs(int v,int par)
{
	if(!hamgp[cult[v]])
		hamgp[cult[v]] = v;
	else 
		dis[cult[v]] = max(dis[cult[v]],abs(h[v] - h[hamgp[cult[v]]]);

	for(auto u : adj[v])
	{
		if(u == par)
			continue;	
		
		h[u] = h[v] + 1;
		dfs(u,v);


	}
}

int main()
{
	cin>>n>>k;
	m = n-1;
	
	for(int i=1;i<=n;i++)
	{
		int u,p;
		cin>>u>>p;

		cult[i] = u;

		if(p == 0)
		{
			root = i;
			continue;
		}

		adj[i].push_back(p);
		adj[p].push_back(i);
	}

	dfs(root,0);
}
