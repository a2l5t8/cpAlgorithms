#include<bits/stdc++.h>

using namespace std;

const int maxn = 1e3 + 7;

int grid[maxn][maxn];

int n,m,r,c;

int main()
{
	cin>>n>>m;

	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)
			cin>>gird[i][j];

	cin>>r>>c;

	return 0;
}
