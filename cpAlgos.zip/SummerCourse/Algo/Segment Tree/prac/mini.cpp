#include<bits/stdc++.h>

using namespace std;

const int maxn = (1<<18) + 7;
const int INF  = 1e9 + 7;

typedef long long ll;

ll a[maxn];
ll segtree[2*maxn];

ll construct(int s,int e,int i)
{
	if(e - s < 2) {
		segtree[i] = a[s];
		return segtree[i];
	}
	
	int mid = (s+e)/2;
	segtree[i] = min(construct(s,mid,i*2 + 1),
				 construct(mid,e,i*2 + 2));

	return segtree[i];
}

ll update(int s,int e,int v,int index,int i)
{
	if(index < s || index >= e)
		return segtree[i];

	if(e - s < 2) {
		segtree[i] = v;
		return segtree[i];
	}
	
	int mid = (s+e)/2;
	segtree[i] = min(update(s,mid,v,index,i*2+1),
				 update(mid,e,v,index,i*2+2));

	return segtree[i];
}

ll mini(int L,int R,int s,int e,int i)
{
	if(L <= s && R >= e)
		return segtree[i];
	
	if(e <= L || s >= R)
		return INF;

	int mid = (s+e)/2;
	return min(mini(L,R,s,mid,i*2 + 1),
		   mini(L,R,mid,e,i*2 + 2));
}	

int main()
{
	int n,q;
	cin>>n>>q;

	for(int i=0;i<n;i++)
		cin>>a[i];
	
	construct(0,n,0);

	for(int i=0;i<q;i++)
	{
		int type;
		cin>>type;

		if(type == 1)
		{
			int index,value;
			cin>>index>>value;

			update(0,n,value,index,0);
		}else {
			int L,R;
			cin>>L>>R;
			
//			R++;
			cout<<mini(L,R,0,n,0)<<"\n";
		}	

	}

	return 0;
}
