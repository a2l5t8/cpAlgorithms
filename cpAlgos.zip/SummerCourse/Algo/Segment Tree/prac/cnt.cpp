#include<bits/stdc++.h>

using namespace std;

const int maxn = (1<<18) + 7;
const int INF  = 1e9 + 7;

typedef long long ll;

ll a[maxn];
pair<ll,ll> segtree[2*maxn];

pair<ll,ll> construct(int s,int e,int i)
{
	if(e - s < 2) {
		segtree[i] = {a[s],1};
		return segtree[i];
	}
	
	int mid = (s+e)/2;
	auto p1 =  construct(s,mid,i*2 + 1);
	auto p2 =  construct(mid,e,i*2 + 2);

	if(p1.first == p2.first)
		segtree[i] = {p1.first,p1.second+p2.second};
	else if(p1.first < p2.first)
		segtree[i] = p1;
	else 
		segtree[i] = p2;

	return segtree[i];
}

pair<ll,ll> update(int s,int e,int v,int index,int i)
{
	if(index < s || index >= e)
		return segtree[i];

	if(e - s < 2) {
		segtree[i] = {v,1};
		return segtree[i];
	}
	
	int mid = (s+e)/2;
	auto p1 = update(s,mid,v,index,i*2+1);
	auto p2 = update(mid,e,v,index,i*2+2);

	if(p1.first == p2.first)
        segtree[i] = {p1.first,p1.second+p2.second};
    else if(p1.first < p2.first)
        segtree[i] = p1;
    else
        segtree[i] = p2;

	return segtree[i];
}

pair<ll,ll> mini(int L,int R,int s,int e,int i)
{
	if(L <= s && R >= e)
		return segtree[i];
	
	if(e <= L || s >= R)
		return {INF,0};

	int mid = (s+e)/2;
	auto p1 = mini(L,R,s,mid,i*2 + 1);
	auto p2 = mini(L,R,mid,e,i*2 + 2);
	
	if(p1.first == p2.first)
        return {p1.first,p1.second+p2.second};
    else if(p1.first < p2.first)
        return  p1;
    else
         return  p2;

	
}	

int main()
{
	int n,q;
	cin>>n>>q;

	for(int i=0;i<n;i++)
		cin>>a[i];
	
	construct(0,n,0);

	for(int i=0;i<q;i++)
	{
		int type;
		cin>>type;

		if(type == 1)
		{
			int index,value;
			cin>>index>>value;

			update(0,n,value,index,0);
		}else {
			int L,R;
			cin>>L>>R;
			
//			R++;
			auto ans = mini(L,R,0,n,0);
			cout<<ans.first<<" "<<ans.second<<"\n";
		}	

	}

	return 0;
}
