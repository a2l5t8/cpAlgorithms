#include<bits/stdc++.h>

using namespace std;

#define pb push_back

typedef long long ll;
typedef long double ld;

const int maxn = 2e3 + 7;
const int mod = 1e9 + 7;
const int INF = 1e9 + 7;
const int mlog = 30;
const int SQ = 400;

ld e[maxn][maxn];
ld p[maxn],ave[maxn];

int n,m;

int main()
{
	cin>>n>>m;
	
	for(int i=0;i<n;i++) {
		for(int j=0;j<m;j++) {
			cin>>e[i][j];
			ave[i] += e[i][j];
		}
		ave[i] = (ave[i] / n);
		cout<<i<<" "<<ave[i]<<"\n";
	}



	return 0;
}
