#include<bits/stdc++.h>

using namespace std;

#define int long long 

int n,x,y;

bool copy(int t)
{	
	if(x > y)
		swap(x,y);
	
	int xtimes = t/x;
	int ytimes = (t-x)/y;

	int ans = xtimes + ytimes;

	return (ans>=n);
}	

void solve()
{
	int l = 0;
	int r = 2e16 + 7;
	
	int ans = 0;
	while(r>=l)
	{
		int mid = (l+r)/2;
		
		if(copy(mid))
			r = mid-1,ans = mid;
		else 
			l = mid+1;
	}

	cout<<ans<<"\n";
}

int32_t main()
{
	cin>>n>>x>>y;

	solve();

	return 0;
}
