#include<bits/stdc++.h>

using namespace std;

#define ll long long 
#define f first
#define se second
#define pb push_back
#define debug(x) cout<<#x<<" "<<x<<"\n"

const int maxn = 1e5 + 7;
const int mod = 1e9 + 7;
const int INF = 1e9 + 7;
const int mlog = 25;
const int SQ = 400;

int main()
{
	

	return 0;
}
