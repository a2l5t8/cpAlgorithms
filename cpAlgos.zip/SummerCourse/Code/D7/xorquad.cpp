#include<bits/stdc++.h>

using namespace std;

#define pb push_back
#define F first
#define S second
#define debug(x) cerr<<#x<<" :"<<x<<"\n"
#define debug_seg(s,e) cerr<<"["<<s<<", "<<e<<"]\n"
#define all(x) x.begin(),x.end()
#define pii pair<int,int>
#define FAST ios_base::sync_with_stdio(false), cin.tie(), cout.tie()
#define int long long

typedef long long ll;
typedef long double ld;

const int maxn = 3e3 + 7;
const int mod = 1e9 + 7;
const int INF = 1e9 + 7;
const int mlog = 22;
const int SQ = 400;

int A,B,C,D;

vector<pii> AB,CD;
int cnt[4096];

bool cmp(pii a,pii b)
{
	if(a.S == b.S)
		return a.F < b.F;
	return a.S < b.S;
}

int32_t main()
{
	FAST;

	int num[4];
	cin>>num[0]>>num[1]>>num[2]>>num[3];

	sort(num,num+4);
	A = num[0],B = num[1], C=num[2], D=num[3];
	
	for(int j=1;j<=B;j++)
		for(int i=1;i<=min(j,A);i++)
			AB.pb({i,j});

//	sort(AB.begin(),AB.end(),cmp);

	for(int i=1;i<=C;i++)
		for(int j=i;j<=D;j++)
			CD.pb({i,j});
	
	int ind = 0;
	int ans = 0;
	for(int i=0;i<CD.size();i++)
	{
		pii cd = CD[i];
		int xorq = cd.F ^ cd.S;
		
		int x = 0;
		while(ind < AB.size())
		{
			int t = AB[ind].F ^ AB[ind].S;
			if(AB[ind].S <= cd.F)
			{
				cnt[t]++;
				ind++;
			}else {
				break;
			}
		}

		ans += ind-(cnt[xorq]);
	}

	cout<<ans<<"\n";


	return 0;
}
