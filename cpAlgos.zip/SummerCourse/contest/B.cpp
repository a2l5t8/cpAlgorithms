#include<bits/stdc++.h>

using namespace std;

#define pb push_back

typedef long long ll;
typedef long double ld;

const int maxn = 500 + 7;
const int mod = 1e9 + 7;
const int INF = 1e9 + 7;
const int mlog = 30;
const int SQ = 400;

int mark[maxn];
int match[maxn][maxn];
int pos[maxn];

int main()
{
	ios_base::sync_with_stdio(false), cin.tie(), cout.tie();
	int n,T;
	cin>>n>>T;

	if(T == 0)
	{
		for(int i=1;i<=n;i++)
			pos[i] = i;

		int days = (n*(n-1))/((n)/2);
//		cout<<days<<"\n";

		vector<pair<int,int>> mat;
		int k = 0;
		
		int d = 1;
		int mta = n*(n-1);
		while(mta)
		{
			// clear
			for(int i=1;i<=n;i++)
				mark[i] = 0;
			mat.clear();
			
			// matching
			for(int i=1;i<=n;i++)
			{
				for(int j=1;j<=n;j++)
				{
					if(i==j || mark[i] || mark[j])
						continue;

					if(!match[i][j])
					{	
						mark[i] = 1;
						mark[j] = 1;

						mat.pb({i,j});
						match[i][j] = 1;

						mta--;
					}
				}
			}

			// (1) query
			for(int i=0;i<mat.size();i++)
			{
				if(pos[mat[i].second] != mat[i].second) {
					k++;
//					cout<<1<<" "<<d<<" "<<mat[i].second<<" "<<mat[i].second<<"\n";
					pos[mat[i].second] = mat[i].second;
				}
/*
				cout<<1<<" ";
				cout<<d<<" ";
				cout<<mat[i].first<<" "<<mat[i].second<<"\n";
*/
				k++;
			}

			// (2) query
			for(int i=0;i<mat.size();i++)
			{
				k++;
/*
				cout<<2<<" ";
				cout<<d<<" ";
				cout<<mat[i].first<<" "<<mat[i].second<<"\n";
*/
				pos[mat[i].first] = mat[i].second;
			}

			d++;
		}

		for(int i=0;i<maxn;i++)
			for(int j=0;j<maxn;j++)
				match[i][j] = 0;

		for(int i=1;i<=n;i++)
			pos[i] = i,mark[i] = 0;
		mat.clear();

		

		cout<<k<<"\n";

		mta = n*(n-1);
		d = 1;
		while(mta)
        {
            // clear
            for(int i=1;i<=n;i++)
                mark[i] = 0;
            mat.clear();

            // matching
            for(int i=1;i<=n;i++)
            {
                for(int j=1;j<=n;j++)
                {
                    if(i==j || mark[i] || mark[j])
                        continue;

                    if(!match[i][j])
                    {
                        mark[i] = 1;
                        mark[j] = 1;

                        mat.pb({i,j});
                        match[i][j] = 1;

						mta--;
                    }
                }
            }

            // (1) query
            for(int i=0;i<mat.size();i++)
            {
                if(pos[mat[i].second] != mat[i].second) {
                    k++;
                    cout<<1<<" "<<d<<" "<<mat[i].second<<" "<<mat[i].second<<"\n";
                    pos[mat[i].second] = mat[i].second;
                }

                cout<<1<<" ";
                cout<<d<<" ";
                cout<<mat[i].first<<" "<<mat[i].second<<"\n";

                k++;
            }

            // (2) query
            for(int i=0;i<mat.size();i++)
            {
                k++;

                cout<<2<<" ";
                cout<<d<<" ";
                cout<<mat[i].first<<" "<<mat[i].second<<"\n";

                pos[mat[i].first] = mat[i].second;
            }

			d++;
        }
	}

    return 0;
}

