#include<bits/stdc++.h>

using namespace std;

const int maxn = 2e5 + 7;

int a[maxn],v[maxn],f[maxn];

int get(int x)
{
	return (x==f[x])?x:f[x]=get(f[x]);
}

int main() 
{
	int n;
	cin>>n;

	for(int i=1;i<=n;i++) 
		cin>>v[i];
	
	for(int i=1;i<=n+1;i++)
		f[i]=i;

	int m;
	cin>>m;
	while (m--) 
	{
		int k;
		cin>>k;
		if (k==1) 
		{
			int p,x;
			cin>>p>>x;
			for (p=get(p);(p<=n)&&x;p=get(p)) 
			{
				int t=min(x,v[p]-a[p]);

				x-=t;
				a[p]+=t;

				if (v[p]==a[p]) 
					f[p]++;
			}
		}else 
		{
			int p;
			cin>>p;
			
			cout<<a[p]<<"\n";
		}
	}
	return 0;
}

