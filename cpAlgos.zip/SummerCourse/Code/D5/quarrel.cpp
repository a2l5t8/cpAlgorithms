#include<bits/stdc++.h>

using namespace std;

const int maxn = 705;

int height[maxn][maxn][2];
pair<int,int> par[maxn][maxn][2];

set<int> adj[maxn];

int main()
{
//	ios_base::sync_with_stdio(false), cin.tie(), cout.tie();

    int n,m;
//  cin>>n>>m;
	scanf("%d %d",&n,&m);
	
	int s,e;
//	cin>>s>>e;
	scanf("%d %d",&s,&e);

    height[s][e][0] = 1;
    for(int i=0;i<m;i++)
    {   
        int u,v;
        scanf("%d %d",&u,&v);

        adj[u].insert(v);
        adj[v].insert(u);
    }

    queue<pair<pair<int,int>,int>> q;
    q.push({{s,e},0});
    // height
    while(!q.empty())
    {
        int a = q.front().first.first;
        int b = q.front().first.second;

        int turn = q.front().second;
        if(turn)
        {
            for(auto u : adj[b])
            {
                if(u != a && !height[a][u][0])
                {
                    par[a][u][0] = {a,b};
                    height[a][u][0] = height[a][b][1] + 1;
                    q.push({{a,u},0});
                }
            }
        }else {
            for(auto u : adj[a])
            {
                if(!height[u][b][1])
                {
                    par[u][b][1] = {a,b};
                    height[u][b][1] = height[a][b][0] + 1;
                    q.push({{u,b},1});
                }
            }
        }
        q.pop();
    }

    if(!height[e][s][0])
    {
//      cout<< -1 << "\n";
		printf("-1\n");
        return 0;
    }

    cout<<(height[e][s][0]-1)/2<<"\n";
    stack<int> Alex,Bob;

    int a = e,b = s;
    for(int i=0;i<height[e][s][0];i+=2)
    {
        Alex.push(b);
        int tmp = a;
        a = par[a][b][0].first;
        b = par[tmp][b][0].second;

        tmp = a;
        a = par[a][b][1].first;
        b = par[tmp][b][1].second;
    }

    a = e,b = s;
    for(int i=0;i<height[e][s][0];i+=2)
    {
        Bob.push(a);
        int tmp = a;
        a = par[a][b][0].first;
        b = par[tmp][b][0].second;

        tmp = a;
        a = par[a][b][1].first;
        b = par[tmp][b][1].second;
    }

    while(!Bob.empty() && !Alex.empty())
    {
//      cout<<Bob.top()<<" "<<Alex.top()<<"\n";
		printf("%d %d\n",Bob.top(),Alex.top());
        Bob.pop();
		Alex.pop();
    }
    cout<<"\n";

    return 0;
}
