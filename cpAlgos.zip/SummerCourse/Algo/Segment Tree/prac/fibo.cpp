#include<bits/stdc++.h>

using namespace std;

#define pb push_back
#define F first
#define S second
#define debug(x) cerr<<#x<<" :"<<x<<"\n"
#define debug_seg(s,e) cerr<<"["<<s<<", "<<e<<"]\n"
#define all(x) x.begin(),x.end()
#define pii pair<int,int>
#define FAST ios_base::sync_with_stdio(false), cin.tie(), cout.tie()
#define int long long

typedef long long ll;
typedef long double ld;

const int maxn = 3e5 + 7;
const int mod = 1e9 + 9;
const int INF = 1e9 + 7;
const int mlog = 22;
const int SQ = 400;

int n,q;
int a[maxn];

int fib[maxn];

int seg[maxn*4],lazy[2][maxn*4];

void preprocess()
{
	fib[1] = fib[2] = 1;
	for(int i=3;i<maxn;i++)
		fib[i] = (fib[i-1] + fib[i-2])%mod;
}

void BUILD(int s=0,int e=n, int id=1)
{
	if(e - s < 2)
	{
		seg[id] = a[s];
		return;
	}

	int mid = (s+e)/2;

	BUILD(s,mid,id*2);
	BUILD(mid,e,id*2 + 1);

	seg[id] = (seg[id*2] + seg[id*2 + 1])%mod;
}

void shift(int s,int e,int id)
{
	int mid = (s+e)/2;

	lazy[0][id*2] = (lazy[0][id*2] + lazy[0][id])%mod;
	lazy[1][id*2] = (lazy[1][id*2] + lazy[1][id])%mod;

	seg[id*2] += ((fib[mid-s+1]-1)*lazy[0][id])%mod;
	seg[id*2] += ((fib[mid-s+2]-1)*lazy[1][id])%mod;
	seg[id*2]%=mod; seg[id*2]+=mod; seg[id*2]%=mod;
	
	int f1 = (((fib[mid-s-1]*lazy[0][id])%mod)+((fib[mid-s]*lazy[1][id])%mod))%mod;
	int f2 = (((fib[mid-s]*lazy[0][id])%mod)+((fib[mid-s+1]*lazy[1][id])%mod))%mod;

	lazy[0][id*2 + 1] = (lazy[0][id*2 + 1] + f1)%mod;
	lazy[1][id*2 + 1] = (lazy[1][id*2 + 1] + f2)%mod;

	seg[id*2 + 1] += ((fib[e-mid+1]-1)*f1)%mod;
	seg[id*2 + 1] += ((fib[e-mid+2]-1)*f2)%mod;
	seg[id*2 + 1]%=mod; seg[id*2 + 1]+=mod; seg[id*2 + 1]%=mod;

	lazy[0][id] = lazy[1][id] = 0;
	return;
}

void UPDATE(int l,int r,int s=0,int e=n,int id=1,int f1=0,int f2=1)
{
	if(l >= e || r <= s)
		return;

	if(l <= s && r >= e) 
	{
		if(s == l) {
			lazy[0][id] = (lazy[0][id] + f1)%mod;
			lazy[1][id] = (lazy[1][id] + f2)%mod;
		}else {
			lazy[0][id] += (((fib[s-l-1])*f1)%mod + ((fib[s-l]*f2)%mod))%mod;
			lazy[1][id] += (((fib[s-l]*f1)%mod)+((fib[s-l+1]*f2)%mod))%mod;
		}

		seg[id] += ((fib[e-l+1]-fib[s-l+1])*f1)%mod;
		seg[id] += ((fib[e-l+2]-fib[s-l+2])*f2)%mod;
		seg[id] %=mod; seg[id]+=mod; seg[id]%=mod;

		return;
	}

	shift(s,e,id);
	
	int mid = (s+e)/2;

	UPDATE(l,r,s,mid,id*2);
	UPDATE(l,r,mid,e,id*2 + 1);

	seg[id] = (seg[id*2] + seg[id*2 + 1])%mod;
}

int SUM(int l,int r,int s=0,int e=n,int id=1)
{
	if(l >= e || r <= s)
		return 0;
	
	if(l <= s && r >= e)
		return seg[id];

	shift(s,e,id);

	int mid = (s+e)/2;

	return (SUM(l,r,s,mid,id*2)
		  +SUM(l,r,mid,e,id*2 + 1))%mod;
}

int32_t main()
{
	FAST;

	cin>>n>>q;
	for(int i=0;i<n;i++)
		cin>>a[i];

	preprocess();

	BUILD();

	while(q--)
	{
		int command,l,r;
		cin>>command>>l>>r;
		l--;

		if(command == 1)
			UPDATE(l,r);
		else 
			cout<<SUM(l,r)<<"\n";
	}
	
	return 0;
}
