#include<bits/stdc++.h>

using namespace std;

const int maxn = 3e5 + 7;

int mark[maxn],vis[maxn],par[maxn],max_path[maxn];
vector<int> adj[maxn];

int getpar(int v)
{
	return (par[v] == v) ? v : par[v] = getpar(par[v]);
}	


void merge(int u,int v,bool state)
{
	v = getpar(v);
	u = getpar(u);

	/*
	cout<<"par :"<<u<<" "<<v<<"\n";
	cout<<"u: "<<max_path[u]<<"\n";
	cout<<"v: "<<max_path[v]<<"\n\n";
	*/

	if(v == u)
		return;

	if(state)
		max_path[v] = max(((max_path[v]+1)/2 + (max_path[u]+1)/2) + 1 , max(max_path[u],max_path[v]));
	
	par[u] = v;
}

int max_dis,max_id,dis;
void dfs(int v)
{
	mark[v] = 1;
	vis[v] = 1;
	dis++;
	if(dis > max_dis)
	{
		max_dis = dis;
		max_id = v;
	}

	for(auto u : adj[v])
		if(!mark[u])
			dfs(u);

	dis--;
	mark[v] = 0;
}

int main()
{
	ios_base::sync_with_stdio(false), cin.tie(), cout.tie();
	
	int n,m,q;
	cin>>n>>m>>q;

	for(int i=1;i<=n;i++)
		par[i] = i;

	for(int i=0;i<m;i++)
	{
		int u,v;
		cin>>u>>v;

		adj[u].push_back(v);
		adj[v].push_back(u);

		merge(u,v,0);
	}
	
	for(int i=1;i<=n;i++)
	{	
		if(!vis[i])
		{
			max_dis = 0;
			dfs(i);
			
			max_dis = 0;
			dfs(max_id);

			max_path[getpar(i)] = max_dis - 1;
		}	
	}

	while(q--)
	{
		int command;
		cin>>command;
		
		if(command == 1)
		{
			int v;
			cin>>v;

			cout<<max_path[getpar(v)]<<"\n";
		}
		else 
		{
			int u,v;
			cin>>u>>v;
			
			merge(u,v,1);
		}
	}

	return 0;
}
