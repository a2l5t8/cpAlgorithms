#include<bits/stdc++.h>

using namespace std;

#define F first
#define S second

const int maxn = 7e2 + 7;

int a[maxn][maxn];
pair<int,int> q[maxn];

pair<int,int> par[maxn][maxn];
int ans[maxn];

vector<pair<int,pair<int,int>>> islands;

int n,m;
int comps;

bool cmp(pair<int,int> a,pair<int,int> b) {return a.first > b.first;}
bool cmp2(pair<int,pair<int,int>> a,pair<int,pair<int,int>> b) {return a.first > b.first;}

pair<int,int> getpar(pair<int,int> v)
{
	return (par[v.first][v.second] == v) ? v : par[v.first][v.second] = getpar(par[v.first][v.second]);
}

void merge(pair<int,int> v, pair<int,int> u)
{
	u = getpar(u);
	v = getpar(v);

	if(u.first !=  v.first || u.second != v.second)
	{
		comps++;
		par[u.first][u.second] = v;
	}
}

int pour(int h)
{
	int l=0,r = n*m -1;
	int ans =0;
	while(r >= l)
	{
		int mid = (l+r)/2;
		if(islands[mid].first >= h)	
			l = mid+1,ans = mid;
		else 	
			r = mid-1;
	}

	return ans;
}

void outOfwater(int t,int last_t)
{
	for(int i=last_t;i<t;i++)
		merge(islands[i].second,islands[i+1].second);
}

int main()
{
	cin>>n>>m;
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)
			cin>>a[i][j],islands.push_back({a[i][j],{i,j}});

	
	int query;
	cin>>query;
	for(int i=1;i<=query;i++)
		cin>>q[i].F,q[i].S = i;
	
	sort(q+1,q+query+1,cmp);
	sort(islands.begin(),islands.end(),cmp2);

//	for(int i=0;i<islands.size();i++)
//		cout<<"["<<islands[i].second.first<<"]"<<"["<<islands[i].second.second<<"] :"<<islands[i].first<<"\n";

	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)
			par[i][j] = {i,j};
	
	comps = 1;
	int last_water=0;
	for(int i=1;i<=query;i++)
	{
		int h = q[i].F;
//		cout<<h<<"<--\n";

		int underwater = pour(h);
		cout<<underwater<<"||||||\n";
		outOfwater(underwater,last_water);

		last_water = underwater;

		ans[q[i].S] = comps;
	}

	for(int i=1;i<=query;i++)
		cout<<ans[i]<<"\n";

	return 0;
}
