#include<bits/stdc++.h>

using namespace std;

#define int long long

const int maxn = 3e5 + 7;
const int maxp = 1e2 + 7;
const int INF = 1e16 + 7;

int dp[maxp][maxn];
int a[maxn];

int n,k,p;

vector<pair<int,int>> q;

int32_t main()
{
	cin>>n>>k>>p;
	p++;
	
	for(int i=1;i<=n;i++)
		cin>>a[i];

	for(int i=1;i<=n;i++)
	{
		int t = max(i-k,1ll);
		q.push_back({t,i});

//		cout<<q[q.size()-1].first<<" "<<q[q.size()-1].second<<"\n";
	}


	for(int i=1;i<=n;i++)
		for(int j=1;j<=(p+1);j++)
			dp[j][i] = -INF;
	
	dp[1][1] = a[1];

	for(int x=2;x<=p;x++)
	{
//		cout<<"P:"<<p<<"\n";

		deque<int> dq;
		int k=0;
		for(int i=1;i<=n;i++)
		{
			while(!dq.empty())
			{
				int j = dq.back();
				if(dp[x-1][j] < dp[x-1][i])
					dq.pop_back();
				else 
					break;
			}	
			dq.push_back(i);

			int R = q[k].second;
			if(i == R)
			{
				while(q[k].second == R)
				{
					int L = q[k].first;
					while(dq.front() < L)
						dq.pop_front();

					if(i == 1) {
						dp[x][i] = a[i];
						k++;
						continue;
					}
	//				cout<<i<<" "<<dq.front()<<"<-------\n";
					dp[x][i] = max(dp[x][i],dp[x-1][dq.front()] + a[i]);
					k++;

	//				cout<<x<<" "<<i<<" =>"<<dp[x][i]<<"\n";
				}		
			}
		}
	}

	cout<<dp[p][n]<<"\n";

	return 0;
}
