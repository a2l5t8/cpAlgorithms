#include<bits/stdc++.h>

using namespace std;

const int maxn = 20;
const int maxk = 1e6 + 7;

const int INF = 1e9 + 7;

//int maxfloor[maxn][maxk];

int process(int x,int n)
{
	int sum = 0,term = 1;
	for(int i=1;i<=n;++i) 
	{
		term *= x-i+1;
		term /= i;
		
		sum += term;
	}
	return sum;
}

int solve(int k,int n)
{
	int l = 0,r = k;
	
	while(l < r)
	{
		int mid = (l+r)/2;

		if(process(mid,n) < k)
			l = mid + 1;
		else 
			r = mid;
	}

	return r;
}


int main()
{
	int n,e;
	cin>>n>>e;

	n -= 2;
	n = max(n,0);	
	cout<<solve(n,e)<<"\n";
}

