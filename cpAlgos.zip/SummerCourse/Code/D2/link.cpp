#include<bits/stdc++.h>

using namespace std;

list<char> res;

int main()
{
	int q;
	cin>>q;

	list<char>::iterator it = res.begin();
	while(q--)
	{
		string s;
		cin>>s;

		if(s[0] == '+' && it != res.end())
			it++;
		else if(s[0] == '-' && it != res.begin())
			it--;
		else {
			char w;
			cin>>w;
			
			res.insert(it,w);
		}
	}

	for(auto u : res)
		cout<<u;
	cout<<"\n";
	
	return 0;
}
