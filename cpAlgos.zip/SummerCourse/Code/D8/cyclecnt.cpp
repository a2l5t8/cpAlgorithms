#include<bits/stdc++.h>

using namespace std;

#define pb push_back
#define F first
#define S second
#define debug(x) cour<<#x<<" :"<<x<<"\n"
#define all(x) x.begin(),x.end()
#define pii pair<int,int>
#define FAST ios_base::sync_with_stdio(false), cin.tie(), cout.tie()
#define int long long

typedef long long ll;
typedef long double ld;

const int maxn = 22;
const int mod = 1e9 + 7;
const int INF = 1e9 + 7;
const int mlog = 20;
const int SQ = 400;

int adj[maxn][maxn];
int dp[(1<<maxn)][maxn];


int32_t main()
{
	FAST;
    
	int n, m;
	cin>>n>>m;

	for(int i = 0; i < m;i++)
	{
	    int u,v;
		cin >> u >> v;
		u--; v--;

		adj[u][v] = 1;
		adj[v][u] = 1;
		int mx = max(u, v);
		int mn = min(u, v);

		dp[(1ll << mx) + (1ll << mn)][mn] = 1;
	}

	int ans = 0;
	for(int i = 0; i < (1ll << n); i++)
	{
		int bt = __builtin_popcountll(i);
		if(bt <= 2)
		    continue;

		int mx = 0;
		for(int j = 0; j < n;j++)
			if(i & (1ll << j))
			    mx = j;

		for(int j = 0; j < n;j++)
		{
			for(int k = 0; k < n ; k++)
			{
				if((1ll << (k + 1)) > i)
				    continue;

				if(adj[j][k] == 0)
				    continue;

				if((i & (1ll << j) )== 0)
				    continue;

				if(((1ll << k) & i) == 0)
				    continue;

				dp[i][j] += dp[(i - (1ll << j))][k];
			}

			if(adj[mx][j]){
				ans += dp[i][j];
			}
		}
	}

	cout << ans / 2 <<"\n";

	return 0;
}
