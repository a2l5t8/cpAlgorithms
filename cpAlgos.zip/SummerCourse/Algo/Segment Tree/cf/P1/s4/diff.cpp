#include<bits/stdc++.h>

using namespace std;

const int maxn = 1e5 + 7;
const int maxa = 41;

int seg[maxa][maxn*4];
int mark[maxa];

int n,q;
int a[maxn];

int segtree[maxn*4];

void update(int type,int index,int v,int s = 0,int e = n,int id = 1)
{
	if(index < s || index >= e)
		return;
	
	if(e - s < 2)
	{
		seg[type][id] = v;
		return;
	}

	int mid = (s+e)/2;

	update(type,index,v,s,mid,id*2);
	update(type,index,v,mid,e,id*2 +1);
	
	seg[type][id] = seg[type][id*2] + seg[type][id*2 + 1];
}

int sum(int type,int l,int r,int s =0,int e = n,int id = 1)
{
	if(l >= e || r <= s)
		return 0;

	if(l <= s && r >= e)
		return seg[type][id];

	int mid = (s+e)/2;

	return sum(type,l,r,s,mid,id*2)
		  +sum(type,l,r,mid,e,id*2 + 1);
}

void put(int index,int s = 0,int e = n,int id=1)
{
	if(index < s || index >= e)
		return;

	if(e - s < 2)
	{
		segtree[s]++;
		return;
	}

	int mid = (s+e)/2;

	put(index,s,mid,id*2);
	put(index,mid,e,id*2 + 1);

	segtree[id] = segtree[id*2] + segtree[id*2 +1];
}

int inv(int l,int r = n,int s = 0,int e = n,int id=1)
{
	if(l >= e || r <= s)
		return 0;
	
	if(l <= s && r >= e)
		return segtree[id];

	int mid = (s+e)/2;
	
	return inv(l,r,s,mid,id*2);
		  +inv(l,r,mid,e,id*2 + 1);
}

void preprocess()
{
	for(int i=0;i<n;i++)
	{
		int t = inv(a[i]);
		update(a[i],i,t-mark[a[i]]);

		put(a[i]);

		mark[a[i]]++;
	}
}

int diff(int l,int r)
{
	int ans = 0;
	for(int i=1;i<maxa;i++)
		ans += sum(i,l,r);

	return ans;
}

void setval(int index,int v)
{
	return;
}

int main()
{
	cin>>n>>q;

	for(int i=0;i<n;i++)
		cin>>a[i];

	preprocess();
	
	while(q--)
	{
		int command;
		cin>>command;

		if(command == 1)
		{
			int l,r;
			cin>>l>>r;

			cout<<diff(l,r)<<"\n";
		}else {
			int i,v;
			cin>>i>>v;

			setval(i,v);
		}
	}
	
	return 0;
}
