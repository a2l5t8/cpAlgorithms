#include<bits/stdc++.h>

using namespace std;

typedef long long ll;

const int maxn = 1e5 + 7;
const int INF = 1e9+ 7;

ll a[maxn];

ll n,k;

ll maxi;
bool split(ll v)
{
	ll g = 0ll;
	ll tmp = a[0];
	
	if(tmp > v)
		tmp = 0,g++;

	int i = 0;
	while(i<n-1)
	{
		if(tmp+a[i+1] > v)
			g++,tmp = 0ll;

		tmp += a[i+1];
		i++;
	}

//	cout<<v<<" :"<<g<<"\n";
	
	if(g < k)
		return true;
	return false;
}

void solve()
{
	ll l = maxi;
	ll r = 1e16 + 7;
	
	ll ans = 0;
	while(r >= l)
	{
		ll mid = (l+r)/2;
		if(split(mid))
			r = mid-1,ans = mid;
		else
			l = mid+1;
	}

	cout<<ans<<"\n";
}

int main()
{
	cin>>n>>k;
	
	maxi = -INF;
	for(int i=0;i<n;i++)
		cin>>a[i],maxi = max(maxi,a[i]);

	solve();
	
	return 0;
}
