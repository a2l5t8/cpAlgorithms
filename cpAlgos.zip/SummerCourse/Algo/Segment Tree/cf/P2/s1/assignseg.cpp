#include<bits/stdc++.h>

using namespace std;

const int maxn = 1e5 + 7;

int seg[maxn*4],lazy[maxn*4];

int n,q;

void shift(int s,int e,int id)
{
	if(lazy[id] == -1)
		return;
	
	seg[id] = lazy[id];
	if(e - s < 2)
	{
		lazy[id] = -1;
		return;
	}

	int mid = (s+e)/2;

	lazy[id*2] = lazy[id];
	lazy[id*2 + 1] = lazy[id];

	lazy[id] = -1;
}

void update(int l,int r,int v,int s=0,int e=n,int id=1)
{
	if(l >= e || r <= s )
		return;

	shift(s,e,id);
	
	if(l <= s && r >= e)
	{
		lazy[id] = v;
		return;
	}

	int mid = (s+e)/2;

	update(l,r,v,s,mid,id*2);
	update(l,r,v,mid,e,id*2 + 1);
}

int num=0;
void get(int index,int s=0,int e=n,int id=1)
{
	if(index < s || index >= e)
		return;

	shift(s,e,id);
	
	if(e - s < 2)
	{
		num = seg[id];
		return;
	}

	int mid = (s+e)/2;

	get(index,s,mid,id*2);
	get(index,mid,e,id*2 + 1);
}

int main()
{
	cin>>n>>q;

	for(int i=0;i<maxn*4;i++)
		lazy[i] = -1;

	while(q--)
	{
		int command;
		cin>>command;

		if(command == 1)
		{
			int l,r,v;
			cin>>l>>r>>v;

			update(l,r,v);
		}else {
			int i;
			cin>>i;

			get(i);

			cout<<num<<"\n";
		}
	}

	return 0;
}
