#include<bits/stdc++.h>

using namespace std;

const int maxn = 2*1e5 + 7;

int n,m;

vector<int> adj[maxn];
int hasPath[maxn],mark[maxn];

int cut_vert[maxn],h[maxn],dp[maxn];

int par[maxn],height[maxn];

bool cmp(int v,int u)
{
	return height[v] < height[u];
}

bool hasP = false;

void pre_dfs(int v,int par)
{
//	cout<<v<<" ";
	mark[v] = 1;
	if(v == n) {
		hasPath[v] = true;
		hasP = true;
		return;
	}

	for(auto u : adj[v])
	{
		if(!mark[u])
		{
			pre_dfs(u,v);

			if(hasPath[u]) 
				hasPath[v] = true;
		}else {
			if(hasPath[u] && u != par)
				hasPath[v] = true;
		}
	}

	if(!hasPath[v] && adj[v].size() > 1)
		hasPath[v] = true;
	
}

void dfs(int v,int par,int root)
{	
	dp[v] = h[v];
	mark[v] = 2;
	
	int cnt = 0;
//	cout<<v<<" ";
	
//	cout<<v<<" ";
	for(auto u : adj[v])
	{
		if(hasPath[u])
		{
			if(mark[u] != 2)
			{
				h[u] = h[v]+1;

				dfs(u,v,root);

				if(v!=root && dp[u] >= h[v])
					cut_vert[v] = true;

				dp[v] = min(dp[v],dp[u]);
				cnt++;
			}else {
				if(u!=par)
					dp[v] = min(dp[v],h[u]);
			}
		}
	}
	if(v==root && cnt > 1)
		cut_vert[v] = 1;
}

void bfs(int v)
{
	par[v] = -1;
	mark[v] = 3;
	
	queue<int> q;
	q.push(v);
	
	while(!q.empty())
	{
		int v = q.front();

		if(v==n)
			break;

		for(auto u : adj[v])
		{
			if(hasPath[u])
			{
				if(mark[u] != 3)
				{
					par[u] = v;
					mark[u] = 3;
					height[u] = height[v] + 1;

					q.push(u);
				}
			}
		}
		q.pop();
	}
}


int main()
{
	ios_base::sync_with_stdio(false), cin.tie(), cout.tie();

	cin>>n>>m;

	for(int i=0;i<m;i++)
	{
		int u,v;
		cin>>u>>v;
		
		adj[v].push_back(u);
		adj[u].push_back(v);
	}

	pre_dfs(1,-1);
//	cout<<"Has Path: ";
	dfs(1,-1,1);
	bfs(1);
	
	if(!hasP)
		return cout<< 0 <<"\n",0;

	vector<int> sp;
	int v = n;

	cut_vert[1] = cut_vert[n] = 1;
	while(v != -1)
	{
		if(cut_vert[v])
			sp.push_back(v);
		
		v = par[v];
	}
//	cout<<"\n";

	sort(sp.begin(),sp.end(),cmp);
	
	cout<<sp.size()<<"\n";
	for(int i=0;i<sp.size();i++)
		cout<<sp[i]<<" ";
	cout<<"\n";

	return 0;
}
/*
13 18
1 2
1 3
4 2
5 2
2 6
3 8
2 8
6 7
7 8
8 9
10 8
8 11
10 13
9 12
11 12
12 13
5 6
9 10




7 9
1 2
2 3
1 4
4 3
4 5
4 6
4 7
2 8
2 9
*/
