#include<bits/stdc++.h>

using namespace std;

struct Node 
{
	char data;
	struct Node *next;
	struct Node *prev;
};

struct Node *head = NULL;
struct Node *tail = NULL;

//Node* ptr = (struct Node*) malloc(sizeof(struct Node));

void insert(char new_data,Node *ptr)
{
	struct Node* new_node = (struct Node*) malloc(sizeof(struct Node));

	new_node->data = new_data;
	
	new_node->next = ptr->next;
	ptr->next = new_node;
	
//	new_node->next->prev = new_node;
//	new_node->next = new_node;

	
	new_node->prev = ptr;
	ptr = new_node;

	new_node = ptr->next;

//	new_node->prev = ptr;

}

int main()
{
	int q;
	cin>>q;

	cin.ignore();

	string s;

	struct Node* ptr;
	while(q--)
	{
		getline(cin,s);
	
		if(s == "+") 
			ptr = ptr->next;
		else if (s == "-")
			ptr = ptr->prev;
		else 
		{
			insert(s[s.size()-1],ptr);
			//cout<<"NO\n";
		}
	}

	
//	cout<<ptr->data;
	/*
	while(ptrr != NULL)
	{
		cout<<ptrr->data;
		ptrr = ptrr->next;
	}*/

	return 0;
}
