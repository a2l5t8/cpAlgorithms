#include<bits/stdc++.h>

using namespace std;

const int maxn = 2e5 + 7;

int seg[maxn*4];

int n;
int a[maxn],mark[maxn];

int intersect[maxn];

void update(int index,int v,int s = 0,int e = n,int id=1)
{
	if(index < s || index >= e)
		return;

	if(e - s < 2)
	{
		seg[id] = v;
		return;
	}

	int mid = (s+e)/2;

	update(index,v,s,mid,id*2);
	update(index,v,mid,e,id*2 + 1);

	seg[id] = seg[id*2] + seg[id*2 +1];
}

int sum(int l,int r,int s = 0,int e = n,int id = 1)
{
	if(l >= e || r <= s)
		return 0;
	
	if(l <= s && r >= e)
		return seg[id];
	
	int mid = (s+e)/2;

	return sum(l,r,s,mid,id*2)
		  +sum(l,r,mid,e,id*2+1);
}

int main()
{
	cin>>n;

	n = n*2;
	for(int i=0;i<n;i++)
		cin>>a[i],mark[i] = -1;

	for(int i=0;i<n;i++)
	{
		if(mark[a[i]] == -1)
		{
			mark[a[i]] = i;
			update(mark[a[i]],1);
		}else {
			intersect[a[i]] += sum(mark[a[i]],i);
			update(mark[a[i]],0);
		}
	}

	reverse(a,a+n);

	for(int i=0;i<n;i++)
		mark[a[i]] = -1;

	for(int i=0;i<n*4;i++)
		seg[i] = 0;

	for(int i=0;i<n;i++)
    {
        if(mark[a[i]] == -1)
        {
            mark[a[i]] = i;
            update(mark[a[i]],1);
        }else {
            intersect[a[i]] += sum(mark[a[i]],i);
            update(mark[a[i]],0);
        }
    }
	
	n /= 2;
	for(int i=1;i<=n;i++)
		cout<<intersect[i]-2<<" ";
	
	return 0;
}
