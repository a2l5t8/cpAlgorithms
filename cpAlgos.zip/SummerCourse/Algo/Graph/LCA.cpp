#include<bits/stdc++.h>

using namespace std;

const int maxn = 1e5 + 7,mlog = 20;

int par[mlog][maxn];
int mark[maxn],h[maxn];

vector<int> adj[maxn];

int getpar(int v,int l)
{
	for(int i=0;i<mlog;i++)
		if(l&(1<<i))
			v = par[i][v];
	
	return v;
}

int LCA(int u,int v)
{
	if(h[u] < h[v])
		swap(u,v);

	u = getpar(u,h[u]-h[v]);
	if(u==v)
		return u;

	for(int j=mlog-1;j>=0;j--)
	{
		int p1 = par[j][u];
		int p2 = par[j][v];
		
		if(p1 != p2)
			u = p1,v = p2;
	}
	return par[0][v];
}

void dfs(int v)
{
	mark[v] = true;
	for(auto u : adj[v])
		if(!mark[u])
			par[0][u] = v,h[u] = h[v] + 1,dfs(u);

}

int main()
{
	int n,m;
	cin>>n>>m;

	for(int i=0;i<m;i++)
	{
		int u,v;
		cin>>u>>v;

		adj[v].push_back(u);
		adj[u].push_back(v);
	}

	dfs(1);

	for(int j=1;j<mlog;j++)
		for(int i=1;i<=n;i++)
			par[j][i] = par[j-1][par[j-1][i]];

	int q;
	cin>>q;

	while(q--)
	{
		int u,v;
		cin>>u>>v;
		
		cout<<LCA(u,v)<<"\n";
	}

	return 0;
}
