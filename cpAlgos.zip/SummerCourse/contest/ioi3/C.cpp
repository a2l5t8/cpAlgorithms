#include<bits/stdc++.h>

using namespace std;

#define pb push_back
#define int long long

typedef long long ll;
typedef long double ld;

const int maxn = 1e5 + 7;
const int mod = 1e9 + 7;
const int INF = 1e9 + 7;
const int mlog = 30;
const int SQ = 400;

int n;
int a[maxn],b[maxn];

int mark[maxn],vis[maxn],compsSize[maxn],fact[maxn];
vector<int> adj[maxn];

vector<int> stud;

/* ----------------------------------------- */
int cnt = 0;
bool check()
{
	for(int i=0;i<stud.size();i++)
	{
		int v = stud[i];
		int j=a[v];
		while(true)
		{
			if(!mark[j]) {
				mark[j] = 1;
				if(b[v] != j)
					return false;
				break;
			}
			j++;
			if(j == n+1)
				j = 1;
		}
	}

	return true;
}
/* ----------------------------------------- */

vector<int> tp;
void topsort(int v)
{
    vis[v] = true;
    for(auto u : adj[v])
        if(!vis[u])
            topsort(u);
    tp.pb(v);
}

bool hasCycle = false;


int cntt = 0;
void dfs(int v)
{
	cntt++;
	mark[v] = 1;
	for(int u : adj[v])
	{
		if(!mark[u]) {
			dfs(u);
		}else if(mark[u] == 1 && u != v) {
			hasCycle = true;
		}
	}
	mark[v] = 2;
}

int power(int a,int b)
{
	if(b==0)
		return 1;

	int x = (power(a,b/2ll))%mod;
	x = (x*x)%mod;
	if(b%2ll == 1ll)
		x  = (x*a)%mod;
	
	return x;
}

int calc(int cm)
{
	fact[0] = 1;
	for(int i=1;i<maxn;i++)
		fact[i] = (fact[i-1]*i)%mod;

	int makhraj = 1;
	for(int i=1;i<=cm;i++) {
//		cout<<compsSize[i]<<" :"<<makhraj<<"\n";
		 makhraj = (makhraj*(fact[compsSize[i]]))%mod;
	}

	int ans  = (fact[n] * ( power(makhraj,mod-2)))%mod;

	return ans;
}

int32_t main()
{
	cin>>n;
	for(int i=1;i<=n;i++) {
		cin>>a[i]>>b[i];
		
		adj[a[i]].pb(b[i]);
	}

		if(n <= 10)
	{
		for(int i=1;i<=n;i++)
			stud.pb(i);

		do {
			for(int i=0;i<=n;i++)
				mark[i] = 0;

			if(check())
				cnt = (cnt + 1)%mod;

		}while(next_permutation(stud.begin(),stud.end()));


		return cout<<cnt<<"\n",0;
	}

	for(int i=1;i<=n;i++)
		if(!vis[i])
			topsort(i);
		
	int comps = 0;
	for(int i=n-1;i>=0;i--) {
		if(!mark[tp[i]]) {
			cntt = 0;
			dfs(tp[i]);
			comps++;
			compsSize[comps] = cntt;
		}
	}

	if(hasCycle)
		return cout<<0<<"\n",0;

	cout<<calc(comps)<<"\n";

	return 0;
}












