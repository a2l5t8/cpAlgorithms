#include<bits/stdc++.h>

using namespace std;

#define pb push_back
#define F first
#define S second
#define debug(x) cour<<#x<<" :"<<x<<"\n"
#define all(x) x.begin(),x.end()
#define pii pair<int,int>
#define FAST ios_base::sync_with_stdio(false), cin.tie(), cout.tie()
#define int long long

typedef long long ll;
typedef long double ld;

const int maxn = 2e5 + 7;
const int mod = 1e9 + 7;
const int INF = 1e9 + 7;
const int mlog = 20;
const int SQ = 400;

int n,m,q;
vector<pii> adj[maxn];

int32_t main()
{
	FAST;

	cin>>n>>m;
	for(int i=0;i<m;i++)
	{
		int u,v,l;
		cin>>u>>v>>l;
		
		adj[u].pb({v,l});
		adj[v].pb({u,l});
	}

	cin>>q;
	while(q--)
	{
		int v,k;
		cin>>v>>k;
		
//		solve(v,k);
	}

	return 0;
}
