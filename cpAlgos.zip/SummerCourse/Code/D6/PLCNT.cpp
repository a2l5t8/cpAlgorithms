#include<bits/stdc++.h>

using namespace std;

const int maxn = 3e3 + 10;
const int mod = 1e9 + 7;

int n,ans;
int component[maxn],maxi[maxn<<1];

vector<int> adj[maxn];

long long power(long long a,int b)
{
	if(b==0)
		return 1ll;

	long long p1 = power((a*a)%mod,b>>1);

	if(b % 2 == 1)
		return (p1*a) % mod;
	
	return p1;
}

void merge(int l,int r)
{
	if(component[l] == component[r])
		return;
	
	ans--;
	l = component[l];
	r = component[r];

	if(adj[r].size() < adj[l].size())
	{
		for(auto u : adj[r])
		{
			component[u] = l; 
			adj[l].push_back(u);
		}
	}else {
		for(auto u : adj[l])
		{
			component[u] = r;
			adj[r].push_back(u);
		}	
	}
}

int main()
{
	int q;
	scanf("%d %d",&n,&q);
	
	ans = n;
	for(int i=1;i<=n;i++)
	{

		adj[i].push_back(i);
		component[i] = i;
		maxi[i*2] = maxi[i*2-1] = i;
	}

	while(q--)
	{
		int l,r;
		scanf("%d%d", &l, &r);
		
		for(int i=0;i<maxi[l+r] - l;i++)
			merge(l+i,r-i);
		
		maxi[l+r] = min(maxi[l+r],l);
		printf("%lld\n", power(26, ans));
	}

	return 0;
}
