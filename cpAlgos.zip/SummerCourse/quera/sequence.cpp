#include<bits/stdc++.h>

using namespace std;

const int maxn = 1e5 + 7;

int a[maxn];

int n,q;

int main()
{
	cin>>n;
	for(int i=0;i<n;i++)
		cin>>a[i];
	
	cin>>q;
	while(q--)
	{
		int s,k;
		cin>>s>>k;

		
	}

	return 0;
}
