#include<bits/stdc++.h>

using namespace std;

const int maxn = 1e3 + 7;

char grid[maxn][maxn];
int h[maxn],l[maxn],r[maxn],larger_l[maxn],larger_r[maxn];

int main()
{
	int n;
	cin>>n;

	for(int i=0;i<n;i++)
		for(int j=0;j<n;j++)
			cin>>grid[i][j];
	
	int ans = 0;
	int cnt = 1;
	int last_i = -1;
	int last_j = -1;
	int last_r = -1;
	for(int i=0;i<n;i++)
	{
		for(int j=0;j<n;j++)
		{
			if(grid[i][j] == 'b')
				h[j] = 0;
			else 
				h[j] ++;
		}

//		memset(larger_l, -1, sizeof(larger_l));
//		memset(larger_r, -1, sizeof(larger_r));
	
		// l -> L
		stack<int> st;
		for(int j=0;j<n;j++)
		{
			while(!st.empty())
			{
				if(h[st.top()] > h[j])
				{
/*
					if(larger_l[j] == -1)
						larger_l[j] = st.top();
*/
					st.pop();
				}else if (h[st.top()] == h[j])
					st.pop();
				else 
					break;
			}
			if(!st.empty())
				l[j] = st.top();
			else 
				l[j] = -1;

			st.push(j);
		}
		
		// r -> R
		stack<int> st2; 
		for(int j=n-1;j>=0;j--)
		{
			while(!st2.empty())
			{
				if(h[st2.top()] > h[j])
				{	
/*
					if(larger_r[j] == -1)
						larger_r[j] = st2.top();
*/
					st2.pop();
				}else if(h[st2.top()] == h[j])
					st2.pop();
				else
					break;
			}

			if(!st2.empty())
				r[j] = st2.top();
			else 
				r[j] = n;

/*
			if(larger_r[j] == -1)
				larger_r[j] = n;
*/
			st2.push(j);
		}

		for(int j=0;j<n;j++) 
		{
			int tmp =  (r[j] - l[j] - 1) * h[j];
		//	cout<<i<<" :"<<j<<" =>"<<h[j]<<" ["<<larger_l[j]<<", "<<larger_r[j]<<"]\n";
			if(ans < tmp)
			{
				ans = tmp;
				cnt = 1;

				last_i = i;
				last_j = l[j];
				last_r = r[j];

				/*
				if(ans == 3)
					cout<<i<<" "<<j<<" =>"<<l[j]<<":"<<r[j]<<"\n";
				*/
			}else if(ans == tmp)
			{
				if(l[j] ==  last_j && last_i == i && r[j] == last_r)
					continue;
				
				cnt++;
				last_j = l[j];
				last_i = i;
				last_r = r[j];
				
				/*
				if(ans == 3)
					cout<<i<<" "<<j<<" =>"<<l[j]<<":"<<r[j]<<"\n";
				*/

			}
		}

//		cout<<"\n";
	}


	if(ans == 0)
		cnt = 1;
	cout<<ans<<" "<<cnt<<"\n";

	return 0;
}

/*
5
bwbww
wwwwb
wwbbw
bwwwb
wbbww
*/

/*
5
wwbww
wbwbw
bwwwb
wbwbw
wwbww
*/
