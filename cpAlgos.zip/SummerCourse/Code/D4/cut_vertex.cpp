#include<bits/stdc++.h>

using namespace std;

const int maxn=1000000+10;

int mark[maxn];
int dp[maxn];
int h[maxn];
int res[maxn];

vector<int> graph[maxn];

int cnt = 0;

void dfs(int v,int parent,int root){
    dp[v]=h[v];
    mark[v]=1;

    int num=0;
    for(int u : graph[v]){
        if(!mark[u]){
            h[u]=h[v]+1;

            dfs(u,v,root);
			
            if(v!=root && dp[u]>=h[v])
                res[v] = 1;

            dp[v]=min(dp[v],dp[u]);
            num++;
        }
        else{
            if(u!=parent){
                dp[v]=min(dp[v],h[u]);
            }
        }
    }
    if(v==root && num>1)
   		res[v] = 1;
}

int main(){
    int n,m;
    cin>>n>>m;
    for(int i=0;i<m;i++){
        int u,v;
        cin>>u>>v;

        graph[u].push_back(v);
        graph[v].push_back(u);
    }

	for(int i=1;i<=n;i++)
		if(!mark[i])
		    dfs(i,0,i);
	
    for(int i=1;i<=n;i++){
        if(res[i]){
            cnt++;
        }
    }
	
	cout<<cnt<<"\n";
	for(int i=1;i<=n;i++)
		if(res[i])
			cout<<i<<" ";
    return 0;
}

