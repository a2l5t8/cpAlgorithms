#include<bits/stdc++.h>

using namespace std;

const int maxn = 1e5 + 10;

void merge(int (&a)[maxn],int l,int p,int q,int r)
{
	int i=l,j=q,k=l;
	int tmp[maxn];
	while( (i<p) || (j < r))
	{
		if( ((a[i] < a[j]) && (i < p)) || (j >= r))
		{
			tmp[k] = a[i];
			i++;
		}else {
			tmp[k] = a[j];
			j++;
		}
		k++;
	}

	for(int i=l;i<r;i++)
		a[i] = tmp[i];
}

void merge_sort(int (&a)[maxn],int l,int r)
{
	if(r - l > 1)
	{
		int mid = (l+r)/2;

		merge_sort(a,l,mid);
		merge_sort(a,mid,r);

		merge(a,l,mid,mid,r);
	}

}

void show(int a[maxn],int l,int r)
{
	for(int i=l;i<r;i++)
		cout<<a[i]<<" ";
	cout<<"\n";
}

int main()
{
	while(true)
	{
		int n;
		cin>>n;

		if(n == -1)
			break;

		int a[maxn];
		for(int i=0;i<n;i++)
			cin>>a[i];
		
		merge_sort(a,0,n);
		show(a,0,n);
	}

	return 0;
}
