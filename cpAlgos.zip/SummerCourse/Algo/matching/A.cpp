#include<bits/stdc++.h>

using namespace std;

const int maxn = 1e3 + 7;

vector<int> adj[maxn];
int mark[maxn],match[maxn];

int n1,n2,m;

bool dfs(int v)
{
	mark[v] = true;
	for(auto u : adj[v])
	{
		if(match[u] == -1 || (!mark[match[u]] && dfs(match[u])))
		{
			match[u] = v;
			match[v] = u;
			
			return true;
		}
	}

	return false;
}

int ans = 0;
void matching()
{
	for(int i=1;i<=(n1 + n2);i++)
			match[i] = -1;
	
	while(true)
	{
		bool canFind = false;
		memset(mark,0,sizeof(mark));
		
		for(int u = 1;u<=n1;u++) {
			if(!mark[u] && match[u] == -1) {
				bool res = dfs(u);
				canFind |=res;
				ans+=res;
			}
		}
		if(!canFind)
			break;
	}
	

	/*
	for(int i=1;i<=n1;i++) {
		memset(mark,0,sizeof(mark));
		if(dfs(i))
			ans++;
	}
	*/
}

int main()
{
	cin>>n1>>n2>>m;

	for(int i=0;i<m;i++)
	{
		int u,v;
		cin>>u>>v;
		
		adj[v].push_back(u);
		adj[u].push_back(v);
	}

	matching();

	for(int i=1;i<=n1;i++)
		if(match[i] != -1)
			cout<<i<<" ";
	
	cout<<"\n";
	cout<<ans<<"\n";	

	return 0;
}
