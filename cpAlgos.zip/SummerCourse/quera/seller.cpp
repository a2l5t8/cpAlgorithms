#include<bits/stdc++.h>

using namespace std;

const int maxk = 1e5 + 7;

int n;

priority_queue<pair<int,int>, vector<pair<int,int>>, greater<pair<int,int>>> heads;

queue<int> q[maxk];


int cnt = 0;
int timer = 0;
bool show()
{
    if(heads.empty() || timer > heads.top().first) {
		cout<<heads.top().first<<"\n";
        return false;
	}
	
	cnt++;
	timer++;
    int bread = heads.top().second;

    heads.pop();
    q[bread].pop();

    if(!q[bread].empty())
        heads.push({q[bread].front(),bread});

    return true;
}

int main()
{
    ios_base::sync_with_stdio(0), cin.tie(0), cout.tie(0);

    cin>>n;

   	for(int i=0;i<n;i++)
    {
        int l;
		cin>>l;

		int group = l;
		for(int j=0;j<l;j++)
		{
			int cult;
			cin>>cult;

    	    q[group].push(cult);
			if(q[group].size() == 1)
				heads.push({cult,group});
		}
    }

	while(true)
	{
		if(!show())
			break;
	}

	cout<<cnt<<"\n";

    return 0;
}
