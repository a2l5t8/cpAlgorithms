#include <bits/stdc++.h>

using namespace std;

const int maxn = 1e5 + 5;
const int SQRT = 315 + 5;

int n;
int a[maxn], c[maxn], mx[SQRT];

deque<int> d[SQRT];

void update(int pos, int x) 
{
	int id = pos / SQRT;
	mx[id] = max(mx[id], a[x]);
	d[id].insert(d[id].begin() + pos % SQRT, x);
	for (int i = id + 1; d[i - 1].size() > SQRT; i++) 
	{
		d[i].push_front(d[i - 1].back());
		mx[i] = max(mx[i], a[d[i][0]]);
		d[i - 1].pop_back();
	}
}

void change(int x) 
{
	for (int i = x / SQRT; i >= 0; i--)
		if (mx[i] < a[x]) {
			c[x] -= d[i].size();
			if (c[x] <= 0)
				return update(i * SQRT - c[x], x);
		}
		else
			for (int j = d[i].size() - 1; j >= 0; c[x]--, j--)
				if (!c[x] || a[d[i][j]] > a[x])
					return update(i * SQRT + j + 1, x);
	update(0, x);
}

int main() 
{
	ios_base :: sync_with_stdio(false), cin.tie(0), cout.tie(0);

	cin>>n;
	for(int i=0;i<n;i++)
	{
		cin>>a[i]>>c[i];
		change(i);
	}

	for(int i=0;i<n;i++)
		cout<<d[i/ SQRT][i%SQRT] + 1 << ' ';

	return 0;
}











