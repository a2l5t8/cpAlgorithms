#include<bits/stdc++.h>

using namespace std;

#define pb push_back
#define F first
#define S second
#define debug(x) cour<<#x<<" :"<<x<<"\n"
#define all(x) x.begin(),x.end()
#define pii pair<int,int>
#define FAST ios_base::sync_with_stdio(false), cin.tie(), cout.tie()
#define int long long

typedef long long ll;
typedef long double ld;

const int maxn = 1e5 + 7;
const int mod = 1e9 + 7;
const int INF = 1e9 + 7;
const int mlog = 20;
const int SQ = 400;

vector<pii>adj[maxn];

int d[maxn], a[maxn];
bool mark[maxn], flag[maxn];

void dfs(int v) {
	mark[v] = true;
	for (int i = 0; i < adj[v].size(); i++) {
		int u = adj[v][i].F, w = adj[v][i].S;
		if (!mark[u]) {
			d[u] = max(1LL * w, d[v] + w);
			if (a[u] < d[u] || flag[v])
				flag[u] = true;
			dfs(u);
		}
	}
}


int32_t main()
{
	int n;
	cin >> n;
	for (int i = 0; i < n; i++)
		cin >> a[i];
	for (int i = 1; i < n; i++) {
		int p, w;
		cin >> p >> w, p--;
		adj[p].push_back({i, w});
		adj[i].push_back({p, w});
	}
	dfs(0);
	
	int cnt = 0;
	for (int i = 0; i < n; i++)
		if (flag[i])
			cnt++;
 
	cout << cnt << endl;

	return 0;
}
