#include<bits/stdc++.h>

using namespace std;

const int maxn = 500 + 7;

queue<int> guest[maxn];
int match[maxn][maxn];
int pos[maxn];

int main()
{
	int n,T;
	cin>>n>>T;

	if(T)
	{
		for(int i=1;i<=n;i++)
			pos[i] = i;

		int k = 0;
		int days = 0;
		for(int i=1;i<=n;i++)
		{
			for(int j=1;j<=i;j++)
			{
				if(guest[pos[j]].empty() && pos[j] < n)
				{
					pos[j]++;

					k++;
					guest[j+1].push(j);
/*
					int t = guest[j+1].front();
					match[t][j+1] = 1;

					guest[j+1].pop();
					k++;
*/
				}
			}

			for(int j=1;j<=n;j++)
			{
				if(!guest[j].empty())
				{	
					int t = guest[j].front();
					match[t][j] = true;

					guest[j].pop();
					k++;
				}
			}
			days++;
		}
	}

	return 0;
}
