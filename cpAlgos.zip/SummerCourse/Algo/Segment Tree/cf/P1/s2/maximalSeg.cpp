#include<bits/stdc++.h>

using namespace std;

const int maxn = 1e5 + 7;

#define int long long

struct segment
{
	int val;
	int pref;
	int suf;
	int sum;
};

segment seg[maxn*4];

int a[maxn];
int n;

// [s,e)
// [l,r)

void build(int s=0,int e=n,int id=1)
{
	if(e - s < 2)
	{
		seg[id].val = a[s];
		seg[id].pref = a[s];
		seg[id].suf = a[s];
		seg[id].sum = a[s];

		return;
	}

	int mid = (s+e)/2;

	build(s,mid,id*2);
	build(mid,e,id*2+1);

	seg[id].pref = max(seg[id*2].pref,seg[id*2].sum + seg[id*2+1].pref);
	seg[id].suf = max(seg[id*2+1].suf,seg[id*2+1].sum + seg[id*2].suf);
	seg[id].sum = seg[id*2].sum + seg[id*2+1].sum;
	seg[id].val = max(seg[id*2].val,max(seg[id*2+1].val,seg[id*2].suf + seg[id*2+1].pref));
}

void update(int index,int v,int s=0,int e=n,int id=1)
{
	if(index >= e || index < s)
		return;

	if(e - s < 2)
	{
		seg[id] = {v,v,v,v};
		return;
	}

	int mid = (s+e)/2;

	update(index,v,s,mid,id*2);
	update(index,v,mid,e,id*2+1);

	seg[id].pref = max(seg[id*2].pref,seg[id*2].sum + seg[id*2+1].pref);
    seg[id].suf = max(seg[id*2+1].suf,seg[id*2+1].sum + seg[id*2].suf);
    seg[id].sum = seg[id*2].sum + seg[id*2+1].sum;
    seg[id].val = max(seg[id*2].val,max(seg[id*2+1].val,seg[id*2].suf + seg[id*2+1].pref));
}

int max_segment(int l,int r,int s=0,int e=n,int id=1)
{
	return seg[id].val;
}

int32_t main()
{
	int q;
	
	cin>>n>>q;
	for(int i=0;i<n;i++)
		cin>>a[i];

	build(0ll,n);
	

	cout<<max(0ll,max_segment(0ll,n))<<"\n";
	while(q--)
	{
		int command = 1;
//		cin>>command;

		if(command == 1)
		{
			int i,v;
			cin>>i>>v;
			
			update(i,v);

			cout<<max(0ll,max_segment(0ll,n))<<"\n";
		}else 
		{
			int l=0,r=n;
			cin>>l>>r;

			cout<<max(0ll,max_segment(l,r))<<"\n";
		}
	}

	return 0;
}
	
