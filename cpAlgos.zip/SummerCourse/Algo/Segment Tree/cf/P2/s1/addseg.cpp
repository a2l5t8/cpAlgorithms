#include<bits/stdc++.h>

using namespace std;

#define int long long

const int maxn = 1e5 + 7;

int seg[maxn*4];
int lazy[maxn*4];

int n,q;
int a[maxn];

void shift(int s,int e,int id)
{
	if(lazy[id] == 0)
		return;
	
	seg[id] += (e - s) * lazy[id];
	if(e - s < 2)
	{
		lazy[id] = 0;
		return;
	}

	int mid = (s+e)/2;

	lazy[id*2] += lazy[id];
	lazy[id*2 + 1] += lazy[id];

	lazy[id] = 0;
}

void update(int l,int r,int v,int s=0,int e=n,int id=1)
{
	if(l >= e || r <= s)
		return;

	shift(s,e,r);
	
	if(l <= s && r >= e)
	{
		lazy[id] += v;
		return;
	}

	int mid = (s+e)/2;

	update(l,r,v,s,mid,id*2);
	update(l,r,v,mid,e,id*2 + 1);

	seg[id] = seg[id*2] + seg[id*2 + 1];
}

int num=0;
void get(int index,int s=0,int e=n,int id=1)
{
	if(index < s || index >= e)
		return;
	
	shift(s,e,id);

	if(e - s < 2)
	{
		num = seg[id];
		return;
	}

	int mid = (s+e)/2;
	
	get(index,s,mid,id*2);
	get(index,mid,e,id*2+1);
}

int32_t main()
{
	cin>>n>>q;
	
//	for(int i=0;i<maxn*4;i++)
//		lazy[i] = -1;

	while(q--)
	{
		int command;
		cin>>command;

		if(command == 1)
		{
			int l,r,v;
			cin>>l>>r>>v;

			update(l,r,v);
		}else {
			int i;
			cin>>i;
			
			get(i);

			cout<<num<<"\n";
		}
	}
	
	return 0;
}
/*

20 20
1 7 17 15
1 0 2 14
1 11 18 13
2 3
1 8 17 17
1 5 18 6
1 7 9 19
2 18
1 1 14 7
2 14
2 1
2 3
1 10 18 19
2 19
1 0 4 4
1 0 14 0
2 1
1 12 17 9
1 7 8 3
1 16 19 11

*/
