#include<bits/stdc++.h>

using namespace std;

const int maxn = 1e5 + 7;

struct assist
{
	int t;
	int z;
	int y;
};

assist a[maxn];
int b[maxn];

int m,n;

bool balloon(int time)
{	
	int balls = 0;
	for(int i=0;i<n;i++)
	{
		int iball = 0;
		iball += a[i].z*(time/(a[i].t*a[i].z + a[i].y));

		int rem = time%(a[i].t*a[i].z + a[i].y);
		int cnt = 0;
		while(rem > a[i].t-1)
		{
			if(cnt == a[i].z)
			{
				cnt = 0;
				rem -= a[i].y;
				continue;
			}
			
			cnt++;
			iball++;
			rem -= a[i].t;
		}

		balls += iball;
		b[i] = iball;

//		cout<<i<<" => "<<iball<<"\n";
	}
	

	return (balls >= m);
}

void solve()
{
	int l = 0;
	int r = 2e7 + 7;

	int ans=0;
	while(r >= l)
	{
		int mid = (l+r)/2;
		if(balloon(mid))
			r = mid-1,ans = mid;
		else 
			l = mid+1;
	}

	balloon(ans);
	int sm = 0;
	for(int i=0;i<n;i++)
		sm += b[i];
	
	int diff = sm-m;
	int i = 0;
	while(diff > 0)
	{
		if(b[i] > 0)
			b[i]--,diff--;
		else
			i++;
	}

	cout<<ans<<"\n";
	for(int i=0;i<n;i++)
		cout<<b[i]<<" ";
	cout<<"\n";
}

int main()
{
	cin>>m>>n;

	for(int i=0;i<n;i++)
		cin>>a[i].t>>a[i].z>>a[i].y;

	solve();

	return 0;
}
