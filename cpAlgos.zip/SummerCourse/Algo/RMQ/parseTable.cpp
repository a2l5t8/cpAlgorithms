#include<bits/stdc++.h>

using namespace std;

#define pb push_back
#define F first
#define S second
#define debug(x) cour<<#x<<" :"<<x<<"\n"
#define all(x) x.begin(),x.end()
#define pii pair<int,int>

typedef long long ll;
typedef long double ld;

const int maxn = 1e5 + 7;
const int mod = 1e9 + 7;
const int INF = 1e9 + 7;
const int mlog = 30;
const int SQ = 400;

int n,q;
int a[maxn];

int rk[mlog][maxn];
int lg[maxn];

void pre_process()
{
	lg[1] = 0;
	for(int i=2;i<maxn;i++)
		lg[i] = lg[i/2] + 1;

	for(int i=0;i<n;i++)
		rk[0][i] = a[i];
	
	for(int i=1;i<mlog;i++)
		for(int j=0;j + (1<<i) <= n;j++)
			rk[i][j] = min(rk[i-1][j],rk[i-1][j + (1<<(i-1))]);
}

int MIN(int l,int r)
{
	int LOG = lg[r-l];
	return min(rk[LOG][l],rk[LOG][r-(1<<LOG)]);
}

int main()
{
	ios_base::sync_with_stdio(false), cin.tie(), cout.tie();

	cin>>n;
	for(int i=0;i<n;i++)
		cin>>a[i];

	pre_process();
	
	cin>>q;
	while(q--)
	{
		int l,r;
		cin>>l>>r;
		r++;
		
		cout<<MIN(l,r)<<"\n";
	}

	return 0;
}
