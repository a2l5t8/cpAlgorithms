#include<bits/stdc++.h>

using namespace std;

const int maxn = 1e5+10;

int a[maxn];

void merge(int l,int p,int q,int r)
{
	int i=l,j=q;
	int tmp[maxn];
	
	int k = l;
	while( (i<p) || (j < r) )
	{
		if( ((a[i] < a[j]) && (i<p)) || (j >= r))
		{
			tmp[k] = a[i];
			i++;
		}else {
			tmp[k] = a[j];
			j++;
		}
		k++;
	}

	for(int q=l;q<r;q++)
		a[q] = tmp[q];
}

void merge_sort(int l,int r)
{
    if(r - l > 1)
    {
        int mid = (l+r)/2;

        merge_sort(l,mid);
        merge_sort(mid,r);

        merge(l,mid,mid,r);
    }
}

void show(int s,int n)
{
	for(int i=s;i<n;i++)
		cout<<a[i]<<" ";
	cout<<"\n";
}

int main()
{
	while(true)
	{
		int n;
		cin>>n;

		if(n == -1)
			break;

		for(int i=0;i<n;i++)
			cin>>a[i];

		merge_sort(0,n);
		show(0,n);
	}
	
	return 0;
}
