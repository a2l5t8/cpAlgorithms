#include<bits/stdc++.h>

using namespace std;

const int maxn = 2e5 + 7;
const int SQRT = 315 + 7;

int a[maxn],d[SQRT];

void build()
{
	for(int i=0;i<SQRT;i++)
		for(int j=i*SQRT;j<(i+1)*SQRT;j++)
			d[i] += a[j];
}

void update(int l,int r,int x)
{
	int posl = l/SQRT;
	int posr = r/SQRT;
	
	if(posl == posr) {
		for(int i=l;i<=r;i++)
			a[i] += x;
		return;
	}

	for(int i=posl + 1;i<posr;i++)
		d[i] += x;


	for(int i=l;i<(posl+1)*SQRT;i++)
 		a[i] += x;

    for(int i=posr*SQRT;i<=r;i++)
        a[i] += x;

	d[posl] += (SQRT-l) * x;
	d[posr] += (r-(SQRT*posr) + 1)*x;
}

int sum(int l,int r)
{
    int posl  = l/SQRT;
    int posr = r/SQRT;

    int sm = 0;

    if(posl == posr)
    {
        for(int i=l;i<=r;i++)
            sm+=a[i];

        return sm;
    }

    for(int i=posl+1;i<posr;i++)
        sm += d[i];

    for(int i=l;i<(posl+1)*SQRT;i++)
        sm += a[i];

    for(int i=posr*SQRT;i<=r;i++)
        sm += a[i];

    return sm;
}


int main()
{
	int n;
	cin>>n;

	for(int i=0;i<n;i++)
		cin>>a[i];

	build();

	int q;
	cin>>q;
	while(q--)
	{
		int command;
		cin>>command;

		if(command == 1)
		{
			int l,r,x;
			cin>>l>>r>>x;

			update(l,r,x);
		}else {
			int l,r;
			cin>>l>>r;

			cout<<sum(l,r)<<"\n";
		}
	}
	
	return 0;
}
