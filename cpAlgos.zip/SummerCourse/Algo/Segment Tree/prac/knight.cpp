#include<bits/stdc++.h>

using namespace std;

const int maxn = 3e5 + 7;

int ans[maxn];

int main()
{
	int n,m;
	cin>>n>>m;

	set<int> s;
	for(int i=1;i<=n;i++)
		s.insert(i);

	for(int i=1;i<=m;i++)
	{
		int l,r,x;
		cin>>l>>r>>x;
		
		auto it1 = s.lower_bound(l);
		auto it2 = s.upper_bound(r);
		for(auto it = it1;it != it2;it++)
			ans[*it] = x;
		s.erase(it1,it2);
		s.insert(x);
	}

	ans[*s.begin()]=0;
	for(int i=1;i<=n;i++)
		cout<<ans[i]<<" ";
	
	return 0;
}
