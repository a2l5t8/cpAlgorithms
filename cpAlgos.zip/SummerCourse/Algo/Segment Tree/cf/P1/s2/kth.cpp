#include<bits/stdc++.h>

using namespace std;

const int maxn = 1e5 + 7;

int seg[maxn*4];

int n,q;
string st;

void build(int s=0,int e=n,int id=1)
{
	if(e - s < 2)
	{
		if(st[s] == '0')
			seg[id] = 0;
		else 
			seg[id] = 1;
		return;
	}

	int mid = (s+e)/2;
	
	build(s,mid,id*2);
	build(mid,e,id*2+1);

	seg[id] = seg[id*2] + seg[id*2+1];
}

void setVal(int index,int v,int s=0,int e = n,int id = 1)
{
	if(index >= e || index < s)
		return;

	if(e - s < 2)
	{
		seg[id] = v;
		return;
	}

	int mid = (e+s)/2;
	
	setVal(index,v,s,mid,id*2);
	setVal(index,v,mid,e,id*2+1);

	seg[id] = seg[id*2] + seg[id*2+1];
}

int find(int k,int s=0,int e=n,int id=1)
{
	if(e - s < 2)
		return s;
	
	int mid = (s+e)/2;
	if(seg[id*2] < k)
		return find(k-seg[id*2],mid,e,id*2+1);
	else 
		return find(k,s,mid,id*2);
}


int main()
{
	cin>>n>>q;

	cin>>st;
	
	build(0,n);

	while(q--)
	{
		int command;
		cin>>command;

		if(command == 1)
		{
			int i,v;
			cin>>i>>v;

			i--;

			setVal(i,v);
		}else {
			int k;
			cin>>k;

			if(k > seg[1]) {
				cout<< -1 << "\n";
				continue;
			}

			cout<<find(k) + 1<<"\n";
		}
	}

	return 0;
}

