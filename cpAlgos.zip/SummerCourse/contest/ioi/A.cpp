#include<bits/stdc++.h>

using namespace std;

#define pb push_back

typedef long long ll;
typedef long double ld;

const int maxn = 5e5 + 7;
const int mod = 1e9 + 7;
const int INF = 1e9 + 7;
const int mlog = 30;
const int SQ = 400;

ll a[maxn];

ll power(ll a,ll b)
{
    if(b==0ll)
        return 1ll;

    ll x = (power(a,b/2))%mod;

    x = (x*x)%mod;
    if(b%2==1)
    {
        x = (x*a)%mod;
    }

    return x;
}


int n;

int main()
{
	cin>>n;

	for(int i=1;i<=n;i++)
		cin>>a[i];
	
	vector<pair<ll,ll>> segs;

	ll l = 1;
	ll mini = a[1];
	for(int i=1;i<n;i++)
	{
		if(a[i] <= a[i+1])
			l++,mini = min(mini,a[i+1]);
		else 
			segs.pb({l,mini}),l=1,mini=a[i+1];
	}
	segs.push_back({l,mini});

	for(int i=0;i<segs.size();i++)
		cout<<segs[i].first<<" :"<<segs[i].second<<"\n";

	ll ans = 0ll;
	for(int i=0;i<segs.size();i++)
		ans += (power(2ll,segs[i].first)-1ll)%mod;

	cout<<ans<<"\n";

	return 0;
}
