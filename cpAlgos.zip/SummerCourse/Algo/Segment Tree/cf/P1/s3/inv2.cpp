#include<bits/stdc++.h>

using namespace std;

const int maxn = 1e5 + 7;

int seg[maxn*4];

int n;
int a[maxn];

int perm[maxn];

void build(int s=1,int e = n+1,int id = 1)
{
	if(e - s < 2)
	{
		seg[id] = 1;
		return;
	}

	int mid = (s+e)/2;
	
	build(s,mid,id*2);
	build(mid,e,id*2+1);

	seg[id] = seg[id*2] + seg[id*2 + 1];
}

void update(int index,int s = 1,int e = n+1,int id = 1)
{
	if(index < s || index >= e)
		return;
	
	if(e - s < 2)
	{
		seg[id] = 0;
		return;
	}

	int mid = (s+e)/2;

	update(index,s,mid,id*2);
	update(index,mid,e,id*2 + 1);

	seg[id] = seg[id*2] + seg[id*2 + 1];
}

int find(int k,int s=1,int e=n+1,int id=1)
{
    if(e - s < 2)
        return s;


    int mid = (s+e)/2;

    if(seg[id*2+1] < k)
        return find(k-seg[id*2+1],s,mid,id*2);
    else
        return find(k,mid,e,id*2+1);
}

int main()
{
	cin>>n;
	for(int i=1;i<=n;i++)
		cin>>a[i];
	
	build();
	

	for(int i=n;i>0;i--)
	{
		int k = find(a[i]+1);
		update(k);

		perm[i] = k;
	}

	for(int i=1;i<=n;i++)
		cout<<perm[i]<<" ";

	return 0;
}
