#include<bits/stdc++.h>

using namespace std;

#define int long long

const int maxn = 2e5 + 7;
const int mod = 1e9 + 7;

int seg[maxn*4];
pair<int,int> lazy[maxn*4];
int intervals[maxn*4];

int a[maxn];

int n,q;


void build(int s=1,int e=n+1,int id=1)
{
	if(e - s < 2)
	{
		seg[id] = a[s];
		return;
	}

	int mid = (s+e)/2;

	build(s,mid,id*2);
	build(mid,e,id*2 + 1);

	seg[id] = (seg[id*2] + seg[id*2 + 1])%mod;
}


void shift(int s,int e,int id)
{
	if(lazy[id].first == 0 && lazy[id].second == 0)
		return;

	seg[id] = (seg[id] +  (((lazy[id].first + lazy[id].second)*(e-s))/2)%mod)%mod;

//	cout<<seg[id]<<"\n";

	if(e - s < 2)
	{
		lazy[id].first = lazy[id].second = 0;
		return;
	}

	int mid = (s+e)/2;

	lazy[id*2].first = (lazy[id*2].first + lazy[id].first)%mod;
	lazy[id*2].second = (lazy[id*2].second + (mid-s-1) + lazy[id].first)%mod;
	intervals[id*2]++;

	lazy[id*2 + 1].first = (lazy[id*2 + 1].first + (mid-s-1) + lazy[id].first + intervals[id])%mod;
	lazy[id*2 + 1].second = (lazy[id*2 + 1].second + lazy[id].second)%mod;
	intervals[id*2 + 1]++;	

	lazy[id].first = lazy[id].second = intervals[id] = 0;
}

void update(int l,int r,int s=1,int e=n+1,int id=1)
{
	shift(s,e,id);

	if(l >= e || r <= s)
		return;

	if(l <= s && r >= e)
	{
		lazy[id].first = (lazy[id].first + (s-l+1))%mod;
		lazy[id].second = (lazy[id].second + (e-l))%mod;
		intervals[id]++;

		shift(s,e,id);

		return;
	}

	int mid = (s+e)/2;

	update(l,r,s,mid,id*2);
	update(l,r,mid,e,id*2 + 1);
	
//	cout<<"["<<s<<", "<<e<<") "<<lazy[id].first<<" "<<lazy[id*2].first<<" "<<lazy[id*2 + 1].first<<"\n";

	seg[id] = (seg[id * 2] + seg[id * 2 + 1])%mod;
}

int sm = 0;
void sum(int l,int r,int s=1,int e=n+1,int id=1)
{
	shift(s,e,id);

	if(l >= e || r <= s)
		return;
	
	if(l <= s && r >= e) {
		sm = (sm + seg[id])%mod;
		return;
	}
	
	int mid = (s+e)/2;

	sum(l,r,s,mid,id*2);
	sum(l,r,mid,e,id*2 + 1);
}

int32_t main()
{
	cin>>n>>q;

	for(int i=1;i<=n;i++)
		cin>>a[i];

	build();

	while(q--)
	{
		string command;
		cin>>command;

		if(command == "add")
		{
			int l,r;
			cin>>l>>r;
			
			r++;

			update(l,r);
		}else {
			int l,r;
			cin>>l>>r;

			r++;

			sm = 0;
			sum(l,r);

			cout<<sm<<"\n";
		}
	}
}
