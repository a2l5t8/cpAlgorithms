#include<bits/stdc++.h>

using namespace std;

#define L first
#define R second

const int maxn = 1e5+ 7;

int a[maxn];
pair<int,int> q[maxn];
int ans[maxn];

int main()
{
	int n;
	cin>>n;

	for(int i=0;i<n;i++)
		cin>>a[i];

	int qu;
	cin>>qu;
	
	int k = 0;
	for(int i=0;i<qu;i++)
		cin>>q[i].L>>q[i].R;

	deque<int> dq;
	for(int i=0;i<n;i++)
	{
		if(k == qu)
			break;

		while(!dq.empty())
		{
			int j = dq.back();
			if(a[j] <= a[i])
				dq.pop_back();
			else 
				break;
		}
		dq.push_back(i);
	
		int R = q[k].R;
		if(i == R)
		{
			while(q[k].R == R)
			{	
				int L = q[k].L;
				while(dq.front() < L)
					dq.pop_front();
				ans[k] = a[dq.front()],k++;
			}
		}
	}	

	for(int i=0;i<qu;i++)
		cout<<ans[i]<<" ";

	return 0;
}
