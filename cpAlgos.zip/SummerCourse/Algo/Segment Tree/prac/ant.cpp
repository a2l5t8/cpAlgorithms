#include<bits/stdc++.h>

using namespace std;

#define pb push_back
#define F first
#define S second
#define debug(x) cour<<#x<<" :"<<x<<"\n"
#define all(x) x.begin(),x.end()
#define pii pair<int,int>
#define FAST ios_base::sync_with_stdio(false), cin.tie(), cout.tie()
#define int long long

typedef long long ll;
typedef long double ld;

const int maxn = 1e5 + 7;
const int mod = 1e9 + 7;
const int INF = 1e9 + 7;
const int mlog = 20;
const int SQ = 400;
	
int n,q;
int a[maxn];

pii seg_min[maxn*4];
int seg_gcd[maxn*4];

void BUILD_MIN(int s=0,int e=n,int id=1)
{
	if(e - s < 2)
	{
		seg_min[id] = {a[s],1};
		return;
	}

	int mid = (s+e)/2;
	BUILD_MIN(s,mid,id*2);
	BUILD_MIN(mid,e,id*2  +1);
	
	if(seg_min[id*2].first < seg_min[id*2 + 1].first)
		seg_min[id] = seg_min[id*2];
	else if(seg_min[id*2].first > seg_min[id*2 + 1].first)
		seg_min[id] = seg_min[id*2 + 1];
	else 
		seg_min[id] = {seg_min[id*2].first, seg_min[id*2].second + seg_min[id*2 + 1].second};
}

void BUILD_GCD(int s=0,int e=n,int id=1)
{
	if(e - s < 2)
	{
		seg_gcd[id] = a[s];
		return;
	}

	int mid = (s+e)/2;
	BUILD_GCD(s,mid,id*2);
	BUILD_GCD(mid,e,id*2 + 1);

	seg_gcd[id] = __gcd(seg_gcd[id*2], seg_gcd[id*2 + 1]);
}

pii MIN(int l,int r,int s=0,int e=n,int id=1)
{
	if(l >= e || r <= s)
		return {INF,0};		
	
	if(l <= s && r >= e)
		return seg_min[id];

	int mid = (s+e)/2;
	pii p1 = MIN(l,r,s,mid,id*2);
	pii p2 = MIN(l,r,mid,e,id*2 + 1);

	if(p1.first < p2.first)
		return p1;
	else if(p1.first > p2.first)
		return p2;
	else
		return {p1.first,p1.second + p2.second};
}

int GCD(int l,int r,int s=0,int e=n,int id=1)
{
	if(l >= e || r <= s)
		return INF;
	
	if(l <= s && r >= e)
		return seg_gcd[id];
	
	int mid = (s+e)/2;

	if(l < mid && r <= mid)
		return GCD(l,r,s,mid,id*2);
	else if(l >= mid && r > mid)
		return GCD(l,r,mid,e,id*2 + 1);
	
	return __gcd(GCD(l,r,s,mid,id*2), GCD(l,r,mid,e,id*2 + 1));
}

int32_t main()
{
	cin>>n;
	for(int i=0;i<n;i++)
		cin>>a[i];

	BUILD_MIN();
	BUILD_GCD();

	cin>>q;
	while(q--)
	{
		int l,r;
		cin>>l>>r;
		l--;
		
		pii p = MIN(l,r);
		int g = GCD(l,r);

		cout<<r-l-((g==p.first)?p.second:0)<<"\n";
	}
	

	return 0;
}
