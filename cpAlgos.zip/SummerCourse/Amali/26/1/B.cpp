#include<bits/stdc++.h>

using namespace std;

#define ll long long 
#define f first
#define se second
#define pb push_back
#define debug(x) cout<<#x<<" "<<x<<"\n"

const int maxn = 1e5 + 7;
const int mod = 1e9 + 7;
const int INF = 1e9 + 7;
const int mlog = 25;
const int SQ = 400;

int n,m,b,r;

int mark[maxn];
int bh[maxn],rh[maxn];
int c[maxn];

vector<int> adj[maxn];

int ans = 0;

bool bValid(int x)
{
	queue<int> q;
	q.push(b);

	if(mark[b] == 0)
		return false;

	mark[b] = 1;
	while(!q.empty())
	{
		int v = q.front();
		if(v == x)
			return true;

		for(auto u : adj[v])
		{
			if(mark[u] == -1)
			{
				mark[u] = 1;
				q.push(u);
			}else if(mark[u] == 0)
				return false;
		}

		q.pop();
	}

	return false;
}

bool isValid()
{
	queue<int> q;
	q.push(r);
	

	if(c[r] != mark[r]) {
		return false;
	}
	mark[r] = 0;

	while(!q.empty())
	{
		int v = q.front();
		if(mark[v] != c[v])
			return false;

		for(auto u : adj[v])
		{
			if(mark[u] == -1)
			{
				cout<<u<<" "<<c[u]<<"<=\n";
				if(c[u] == 0)	
				{
					mark[u] = 0;
					q.push(u);
				}else if(c[u] == 1)
				{
					if(!bValid(u))
						return false;
				}
			}else if(mark[u] == 1)
				return false;
		}
		q.pop();
	}

	return true;
}

int main()
{
	cin>>n>>m>>b>>r;
	b--,r--;

	for(int i=0;i<m;i++)
	{	
		int u,v;
		cin>>u>>v;

		u--,v--;
		
		adj[u].push_back(v);
		adj[v].push_back(u);
	}
	

	for(int mask=0;mask<(1<<n);mask++)
	{
		for(int i=0;i<n;i++)
			mark[i] = -1;

		for(int i=0;i<n;i++)
		{
			if( (mask & (1<<i) ) > 0)
				c[i] = 1;
			else 
				c[i] = 0;

//			cout<<i<<" "<<c[i]<<"<---- \n";
		}

		mark[r] = 0;
		mark[b] = 1;
		if(isValid()) {
			ans = (ans + 1)%mod;
			for(int i=0;i<n;i++)
				cout<<i<<" :"<<mark[i]<<" | "<<c[i]<<"\n";
			cout<<"\n";
		}
		cout<<"\n";
	}

	cout<<ans<<"\n";

	return 0;
}
