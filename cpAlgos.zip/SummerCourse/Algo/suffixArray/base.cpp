#include<bits/stdc++.h>

using namespace std;

#define pb push_back
#define F first
#define S second
#define debug(x) cour<<#x<<" :"<<x<<"\n"
#define all(x) x.begin(),x.end()
#define pii pair<int,int>

typedef long long ll;
typedef long double ld;

const int maxn = 5e5 + 7;
const int mod = 1e9 + 7;
const int INF = 1e9 + 7;
const int mlog = 20;
const int SQ = 400;

int rk[mlog][maxn];

int n;
string s;

struct seg {
	int first;
	int second;
	int index;
};

bool cmp(seg a,seg b)
{
	if(a.first == b.first) {
		if(a.second == b.second)
			return a.index > b.index;
		return a.second < b.second;
	}
	return a.first < b.first;
}

seg tmp[maxn];

int sa[maxn];
void SA()
{	
	for(int i=0;i<n;i++)
		rk[0][i] = s[i]-'a';
		
	for(int j=1;j<mlog;j++) {
		for(int i=0;i<n;i++) {
			if(i + (1<<(j)) <= n)
				tmp[i] = {rk[j-1][i], rk[j-1][i + (1<<(j-1))],i};
			else
				tmp[i] = {rk[j-1][i], -1,i};
		}

		sort(tmp,tmp + n,cmp);
/*
		for(int i=0;i<n;i++)
            cout<<tmp[i].first<<" "<<tmp[i].second<<" "<<tmp[i].index<<"\n";
        cout<<"\n";
*/
		
		int ind = 0;

		rk[j][tmp[0].index] = ind;
		for(int i=1;i<n;i++)
		{
			if(tmp[i].first == tmp[i-1].first && tmp[i].second == tmp[i-1].second)
				rk[j][tmp[i].index] = ind;
			else 
				ind++,rk[j][tmp[i].index] = ind;
		}
	}

	for(int i=0;i<n;i++)
		sa[i] = tmp[i].index;
}

int main()
{
//	ios_base::sync_with_stdio(false), cin.tie(), cout.tie();

	cin>>s;
	n = s.size();
	
	SA();
	
	for(int i=0;i<n;i++)
		cout<<sa[i]<<" ";

	return 0;
}

