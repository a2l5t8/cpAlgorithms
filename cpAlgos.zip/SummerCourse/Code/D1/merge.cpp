#include<bits/stdc++.h>

using namespace std;

const int maxn = 1e6 + 7;

long long ans[maxn];

long long n;
string s;
long long dp[maxn];

int cnt = n;
int k = s.size()-1;

void merge_sort(long long start,long long end) 
{
	if(end - start < 2)
		return;
	
    for(int i=0;i<1;i++)
    {
        long long  l = start;
        long long r = end;
        
        long long p1,p2;
        p1 = (l+r)/2 -1;
        
        long long  mid = p1;
        p2 = r-1;
        for(int j=l;j<r;j++)
        {
            if(s[k] == '0')
            {
                //cout<<k<<" 0\n";
                if(cnt > 0)
                {
                    ans[p1] = cnt;
                    cnt--;
                    p1--;
                }else {
                    if(p1 >= l && p2 > mid  && ans[p2] > ans[p1]);
                    {
                        swap(ans[p1],ans[p2]);
                //      cout<<"sdf";
                    }
                    p1--;
                }
            }else {
//              cout<<k<<" 1\n";
                if(cnt > 0)
                {
                    ans[p2] = cnt;
                    cnt--;
                    p2--;
                }else {
                    if(p1 >= l && p2 > mid && ans[p1] > ans[p2])
                    {
                        swap(ans[p1],ans[p2]);
                    }
                    p2--;
                }
            }
            //cout<<s[k]<<"\n";
            k--;
        //  cout<<k<<"\n";
        }
    }

	
	merge_sort((start + end)/2,end);
	merge_sort(start,(start+end)/2);
}

int main()
{
	ios_base::sync_with_stdio(0), cin.tie(0), cout.tie(0);


	cin>>s;

	dp[2] = 2;
	for(long long i=3;i<maxn;i++)
		dp[i] = dp[i/2] + dp[i - i/2] + i;
	
	dp[1] = 1;
	for(int i=1;i<maxn;i++)
	{
		if(dp[i] == s.size())
		{
			n = i;
			break;
		}
	}

	cnt = n;
	k = s.size()-1;
	merge_sort(1ll*0,n);

	if(s.size() == 1)
		ans[0] = 1;
	for(int i=0;i<n;i++)
	{
		if(i == n-1)
		{
			cout<<ans[i];
			continue;
		}
		cout<<ans[i]<<" ";
	}
//	cout<<"\n";
	
	return 0;
}
