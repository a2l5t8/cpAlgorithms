#include<bits/stdc++.h>

using namespace std;

typedef long long ll;

const int maxn = 1e6 + 7;
const ll SQ = 400 + 7;

ll a[maxn];
pair<ll,ll> par[maxn];

ll n,q;

void build(ll v)
{
	ll l = v*SQ;
	ll r = min(n,(1+v)*SQ-1);

	for(ll i = r; i>=l;i--)
	{	
		if(i+a[i] > r)
			par[i] = {1,i};
		else 
			par[i] = {par[i+a[i]].first + 1,par[i+a[i]].second};
	}
}

int main()
{
	cin>>n>>q;

	for(int i=0;i<n;i++)
		cin>>a[i];

	for(int i=0;i<(n+SQ-1)/SQ;i++)
		build(i);
	
	while(q--)
	{
		int command;
		cin>>command;


		if(command == 0)
		{
			ll x,y;
			cin>>x>>y;

			x--;
			a[x] = y;
			build(x/SQ);
		}else {
			ll x;
			cin>>x;
			x--;

			ll res = 0,last;
			while(x < n)
			{
				res += par[x].first;
				last = par[x].second;
				
				x = par[x].second+a[par[x].second];
			}

			cout<<last+1<<" "<<res<<"\n";
		}
	}
	return 0;
}











