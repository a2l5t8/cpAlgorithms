#include<bits/stdc++.h>

using namespace std;

typedef long long ll;

const int maxn = 1e3 + 10;
const ll INF = 1e16 + 7;

vector<pair<ll,ll>> adj[maxn];
ll par[maxn];
ll d[maxn];

ll maxi = 0;

void dijkstra(ll x,ll y)
{
	par[1] = -1;
	d[1] = 0;

	set<pair<ll,ll>> st;
	st.insert({d[1],1});
	while(!st.empty())
	{
		ll v = st.begin()->second;
		st.erase({d[v],v});
		for(auto u : adj[v])
		{
			if( (x == u.first && y == v) || (x==v && y == u.first))
			{
				if(d[u.first] > (d[v] + (u.second*2)))
				{
					st.erase({d[u.first],u.first});
        	        d[u.first] = d[v] + (u.second*2);
    	            par[u.first] = v;
	                st.insert({d[u.first],u.first});
				}
			}
			else {
				if(d[u.first] > (d[v] + u.second))
				{
					st.erase({d[u.first],u.first});
					d[u.first] = d[v] + u.second;
					par[u.first] = v;
					st.insert({d[u.first],u.first});
				}
			}
		}
	}
}

int main()
{
	ll n,m;
	cin>>n>>m;

	for(int i=0;i<m;i++)
	{
		ll u,v,w;
		cin>>u>>v>>w;

		adj[v].push_back({u,w});
		adj[u].push_back({v,w});
	}

	for(int i=1;i<=n;i++)
		d[i] = INF;

	dijkstra(0,0);
	
	if(d[n] == INF)
		return cout<< 0 <<"\n",0;

	ll dis = d[n];
	
	vector<ll> path;

	if(1 == n)
		return cout<<0<<"\n",0;

	ll v = n;
	while(v != -1)
	{
		path.push_back(v);
		v = par[v];
	}
	
	maxi = dis;
	for(int i=0;i<path.size()-1;i++)
	{
		for(int j=1;j<=n;j++)
			d[j] = INF;
		
		dijkstra(path[i],path[i+1]);
		maxi = max(maxi,d[n]);
	}

	cout<<maxi - dis<<"\n";

	return 0;
}
