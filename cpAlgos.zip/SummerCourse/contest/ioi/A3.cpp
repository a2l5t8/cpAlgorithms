#include<bits/stdc++.h>

using namespace std;

#define pb push_back
#define int long long

typedef long long ll;
typedef long double ld;

const int maxn = 5e5 + 7;
const int mod = 1e9 + 7;
const int INF = 1e9 + 7;
const int mlog = 30;
const int SQ = 400;

int a[maxn];
int n;

int32_t ib:
