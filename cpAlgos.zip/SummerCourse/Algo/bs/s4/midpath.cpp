#include<bits/stdc++.h>

using namespace std;

const int maxn = 1e5 + 7;
const int INF = 1e9 + 7;

int n,m,d;

int mark[maxn],h[maxn],dis[maxn];
vector<pair<int,int>> adj[maxn];


int main()
{
	cin>>n>>m;

	for(int i=0;i<m;i++)
	{
		int u,v,w;
		cin>>u>>v>>w;
		
		adj[u].push_back({v,w});
	}
	
	return 0;
}
