#include<bits/stdc++.h>

using namespace std;

#define x first
#define y second


const int maxn = 3*1e3 + 7;
const int INF = 1e9 + 7;
const int maxk = 2*1e6 + 7;

pair<int,int> a[maxn];
int n;

int calc(pair<int,int> a,pair<int,int>b)
{
	return (abs(a.first-b.first) + abs(a.second - b.second));
}

int cnt = 1;
int dis[maxn][maxn];
int mark[maxn];

bool flag = true;
int par_type,type;
void dfs(int v,int mdis,int par)
{
	if(!flag)
		return;
	par_type = mark[par];
	type = 4*cnt- 1 - par_type;

	mark[v] = type;

	for(int i=1;i<=n;i++)
	{
		if(dis[v][i] > mdis)
		{
			int u = i;
			if(mark[u] != (2*cnt) && mark[u] != (2*cnt-1))
			{
			//	cout<<v<<" :"<<u<<"\n";
				
				dfs(u,mdis,v);
			}else if(mark[u] == mark[v] && par != u)
			{
//				cout<<v<<" :"<<u<<" => "<<mark[v]<< " :"<<mark[u]<<" ||| "<<mdis<<" par<<"<<par[v]<<" "<<par[u]<<"\n";
				flag = false;
				return;
			}
		}	
	}

	if(!flag)
		return;
}

int main()
{
	cin>>n;
	
	for(int i=1;i<=n;i++)
		cin>>a[i].x>>a[i].y;
	

	for(int i=1;i<=n;i++) {
		for(int j=1;j<=n;j++) {
			dis[i][j] = calc(a[i],a[j]);
//			cout<<"dis["<<i<<"]["<<j<<"] : "<<dis[i][j]<<"\n";
		}	
	}
	
	int l = 0,r = 2*1e6 + 7;
	int mid;
	int ans;
	while(r >= l )
	{
//		cout<<l<<" "<<r<<"\n";
		mid = (l+r)/2;

		flag = true;

		mark[0] = 2*cnt;
		for(int i=1;i<=n;i++)
			if(mark[i] != cnt*2 && mark[i] != cnt*2 - 1)
				dfs(i,mid,0);
		cnt++;

		if(flag)
		{
			r = mid-1;
			ans = mid;
//			cout<<ans<<" <--- \n";
		}
		else 
			l = mid+1;
	}

	cout<<ans<<"\n";

	return 0;
}
