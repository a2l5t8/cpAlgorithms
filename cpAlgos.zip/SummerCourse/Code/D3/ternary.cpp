#include<bits/stdc++.h>

using namespace std;

typedef long long ll;

const int maxn = 50 + 7;

int n,T;
vector<ll> a,t;

void read(string s,vector<ll> &vec)
{
	int i=0;
	string num;
	while(i < s.size())
	{
		if(isdigit(s[i]))
		{
			int j=i;
			num = " ";
			while(isdigit(s[j]))
			{
				num += s[j];	
				j++;
			}

			vec.push_back(stoi(num));
			i = j;
		}
		i++;
	}
}

bool check(double R)
{
	int time,debi;
	double cont = (double)T;

//	cout<<R<<" \n";
	for(int i=0;i<n;i++)
	{
		time = t[i];
		debi = a[i];

		cont -= (((double)debi - (double)R) * (double)time);
		if(cont > double(T))
			cont = double(T);
		
//		cout<<cont<<" \t";
		if(cont < (double)0)
			return false;
	}
	return true;
}

int main()
{
	string st,sa;

	getline(cin,st);
	getline(cin,sa);
	
	read(st,t);
	read(sa,a);

	cin>>T;

	n = t.size();

	// ternary search
	double l,r,mid;
	l = 0,r = 1e6 + 7;
	while(r - l > 0.000001)
	{
		mid = (l+r)/(double)2;
		if(check(mid))
			 r = mid;
		else 
			l = mid;
	}

	cout<<setprecision(3) << fixed << r;

	return 0;
}
