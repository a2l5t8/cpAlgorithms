#include<bits/stdc++.h>

using namespace std;

#define int long long

const int maxn = 1e5 + 7;

int add[maxn*4];

int n,q;

void update(int l,int r,int v,int s=0,int e=n,int id=1)
{
	if(l >= e || r <= s)
		return;

	if(l <= s && r >= e)
	{
		add[id] += v;
		return;
	}

	int mid = (s+e)/2;

	update(l,r,v,s,mid,id*2);
	update(l,r,v,mid,e,id*2+1);
}	

int sm = 0;
void get(int index,int s=0,int e=n,int id=1)
{
	if(index < s || index >= e )
		return;

	if(index >= s && index < e)
		sm += add[id];

	if(e - s < 2)
		return;

	int mid = (s+e)/2;

	get(index,s,mid,id*2);
	get(index,mid,e,id*2 + 1);
}

int32_t main()
{
	cin>>n>>q;

	while(q--)
	{
		int command;
		cin>>command;

		if(command == 1)
		{
			int l,r,v;
			cin>>l>>r>>v;

			update(l,r,v);
		}else {
			int i;
			cin>>i;
			
			sm = 0;
			get(i);

			cout<<sm<<"\n";
		}
	}
	
	return 0;
}
