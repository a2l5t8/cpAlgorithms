#include<bits/stdc++.h>

using namespace std;

const int maxn = 1e5 + 7;

int mark[maxn],h[maxn],par[maxn];
vector<pair<int,int>> adj[maxn];

int n,m,d;

bool bfs(int v,int weight)
{
	for(int i=0;i<=n;i++)
		par[i] = h[i] = mark[i] = 0;
	
	par[v] = -1;
	mark[v] = 1;
	queue<int> q;

	q.push(v);
	while(!q.empty())
	{
		int v = q.front();
		for(auto u : adj[v])
		{
			if(!mark[u.first] && u.second <= weight)
			{
				mark[u.first] = 1;
				par[u.first] = v;
				h[u.first] = h[v] + 1;

				q.push(u.first);
			}
		}

		q.pop();
	}
	
	if(mark[n] && h[n] <= d)
		return true;
	return false;
}

void solve()
{
	int l = 0;
	int r = 1e9  + 7;

	int ans = -1;
	while(r >= l)
	{
		int mid = (l+r)/2;

		if(bfs(1,mid))
			r = mid-1,ans = mid;
		else 
			l = mid+1;
	}
	
	if(ans == -1) {
		cout<<-1<<"\n";
		return;
	}

	bfs(1,ans);
	
	cout<<h[n]<<"\n";
	vector<int> path;

	int x = n;
	while(x != -1)
	{
		path.push_back(x);
		x = par[x];
	}

	for(int i=path.size()-1;i>=0;i--)
		cout<<path[i]<<" ";
	cout<<"\n";
}

int main()
{
	cin>>n>>m>>d;

	for(int i=0;i<m;i++)
	{
		int u,v,w;
		cin>>u>>v>>w;
		
		adj[u].push_back({v,w});
	}

	solve();

	return 0;
}
