#include<bits/stdc++.h>

using namespace std;

const int maxn = 2e5 + 7;

int seg[maxn*4];

int n;
int a[maxn],mark[maxn];

int nest[maxn];

void update(int index,int s = 0,int e = n,int id = 1)
{
	if(index < s || index >= e)
		return;
	
	if(e - s < 2)
	{
		seg[id] = 1;
		return;
	}

	int mid = (s+e)/2;

	update(index,s,mid,id*2);
	update(index,mid,e,id*2 + 1);

	seg[id] = seg[id*2] + seg[id*2 + 1];
}

int sum(int l,int r,int s=0,int e = n,int id = 1)
{
	if( l >= e || r <= s)
		return 0;

	if(l <= s && r >= e)
		return seg[id];
	
	int mid = (s+e)/2;

	return sum(l,r,s,mid,id*2) 
		  +sum(l,r,mid,e,id*2 + 1);
}

int main()
{
	cin>>n;

	n = n*2;
	for(int i=0;i<n;i++)
		cin>>a[i],mark[i] = -1;

		
	for(int i=0;i<n;i++)
	{
		if(mark[a[i]] == -1)
			mark[a[i]] = i;
		else {
			nest[a[i]] = sum(mark[a[i]],i);
			update(mark[a[i]]);
		}
	}
	
	n = n/2;
	for(int i=1;i<=n;i++)
		cout<<nest[i]<<" ";
	
	return 0;
}
