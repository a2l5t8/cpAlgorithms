#include<bits/stdc++.h>

using namespace std;

#define pb push_back
#define F first
#define S second
#define debug(x) cour<<#x<<" :"<<x<<"\n"
#define all(x) x.begin(),x.end()
#define pii pair<int,int>

typedef long long ll;
typedef long double ld;

const int maxn = 1e5 + 7;
const int mod = 1e9 + 7;
const int INF = 1e9 + 7;
const int mlog = 33;
const int SQ = 400;

int n;
int a[maxn];

vector<int> seg[mlog][maxn*4];

void merge(int s1,int e1,int s2,int e2,int d,int id)
{
    int i=0,j=0;
    int tmp[maxn];

	int len1 = e1-s1;
	int len2 = e2-s2;

    int k = 0;
    while( (i<len1) || (j < len2) )
    {
        if( ((seg[d+1][id*2][i] < seg[d+1][id*2 + 1][j]) && (i<len1)) || (j >= len2))
        {
            tmp[k] = seg[d+1][id*2][i];
            i++;
        }else {
            tmp[k] = seg[d+1][id*2 + 1][j];
            j++;
        }
        k++;
    }

    for(int q=0;q<len1+len2;q++)
        seg[d][id].pb(tmp[q]);
}


void build(int s=0,int e=n,int d=1,int id=1)
{
	if(e - s < 2)
	{
		seg[d][id].pb(a[s]);
		return;
	}
	
	int mid = (s+e)/2;
	build(s,mid,d+1,id*2);
	build(mid,e,d+1,id*2 + 1);

	merge(s,mid,mid,e,d,id);
}


int cnt = 0;

// [l,r); O(log2n)
void get(int l,int r,int k,int s=0,int e=n,int d=1,int id=1)
{
	if(l >= e || r <= s)
		return;
	
	if(l <= s && r >= e) {
		int ind = lower_bound(seg[d][id].begin(),seg[d][id].end(),k) - seg[d][id].begin();
		cnt+= ind;

		return;
	}
	
	int mid = (s+e)/2;

	get(l,r,k,s,mid,d+1,id*2);
	get(l,r,k,mid,e,d+1,id*2 + 1);
}

int main()
{
	cin>>n;

	for(int i=0;i<n;i++)
		cin>>a[i];
	
	build();

	int q;
	cin>>q;
	while(q--)
	{
		int l,r,k;
		cin>>l>>r>>k;
		
		cnt = 0;
		get(l,r,k);
		cout<<cnt<<"\n";
	}

// O(nlogn +  qlog2n);

	return 0;
}
