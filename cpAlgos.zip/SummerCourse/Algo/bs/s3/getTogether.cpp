#include<bits/stdc++.h>

using namespace std;

#define v second
#define x first
#define int double

const long long maxn = 1e5 + 7;
const int INF = 1e9 + 7;

pair<int,int> a[maxn];

long long n;

bool minimax(int t)
{
	int ls = -INF,re = INF;
	for(long long i=0;i<n;i++)
	{
		ls = max(ls,a[i].x - t*a[i].v);
		re = min(re,a[i].x + t*a[i].v);
	}

	if(re - ls > 0)
		return true;
	return false;
}	

void solve()
{
	int l = -INF;
	int r = INF;

	int ans=0.0;
	while(r - l > 0.000001)
	{
		int mid = (l+r)/2;

		if(minimax(mid))
			r = mid,ans = mid;
		else 
			l = mid;
	}

	cout<<setprecision(8)<<fixed<<ans<<"\n";
}

int32_t main()
{
	cin>>n;

	for(long long i=0;i<n;i++)
		cin>>a[i].x>>a[i].v;
	
	solve();

	return 0;
}
