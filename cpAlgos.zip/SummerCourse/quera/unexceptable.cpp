#include<bits/stdc++.h>

using namespace std;

const int maxn = 3e5 + 7;
const int SQ = 400;

int c[maxn],val[maxn];

int n,m;

vector<int> adj[maxn];
vector<pair<pair<int,int>,int>> q;

int stime[maxn],ftime[maxn];

bool cmp(pair<pair<int,int>,int> a,pair<pair<int,int>,int> b)
{
	if(a.first.first/SQ != b.first.first/SQ)
		return a.first.first < b.first.first;

	return a.first.second < b.first.second;
}

int timer = 0;
void pre_dfs(int v,int par=0)
{
	stime[v] = timer++;
	
	for(int u : adj[v])
		if(u != par)
			pre_dfs(u,v);

	ftime[v] = timer;
}

void dfs(int v,int par=0)
{
	for(auto u : adj[v])
		if(u != par)
			q.push_back({{stime[u],ftime[u]},v}),dfs(u,v);
}

void Mo()
{
	int l=1,r=1;
	for(int i=0;i<q.size();i++)
	{
		int L = q[i].first.first;
		int R = q[i].first.second;

		
	}
}

int main()
{
	cin>>n;
	for(int i=1;i<=n;i++)
		cin>>c[i];

	m = n-1;
	for(int i=0;i<m;i++)
	{
		int u,v;
		cin>>u>>v;

		adj[v].push_back(u);
		adj[u].push_back(v);
	}

	pre_dfs(1);
	dfs(1);

	sort(q.begin(),q.end(),cmp);

	Mo();

	return 0;
}
