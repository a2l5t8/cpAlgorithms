#include <bits/stdc++.h>

using namespace std;

const int maxn = 3e3+10;
const int mod = 1e9+7;

int n, q, com[maxn], ans, mx[maxn<<1];
vector<int> vec[maxn];

long long power(long long a, int p)
{
	if (p == 0)
		return 1;
	long long t = power(a*a%mod, p>>1);
	if (p & 1)
		return t * a % mod;
	return t;
}

void merge(int v, int u)
{
	if (com[v] == com[u])
		return ;
	
	ans--;
	v = com[v];
	u = com[u];
	if(vec[v].size() > vec[u].size())
	{
		for (int x: vec[u]){
			com[x] = v;
			vec[v].push_back(x);
		}
	}else {
		for(int x: vec[v]){
			com[x] = u;
			vec[u].push_back(x);
		}	
	}
}

int main()
{
	scanf("%d %d",&n,&q);
	ans = n;
	for (int i = 1; i <= n; i++)
	{
		vec[i].push_back(i);
		com[i] = i;
		mx[2*i] = mx[2*i-1] = i;
	}
	while (q--)
	{
		int l, r;
		scanf("%d%d", &l, &r);
		for (int i = 0; i < mx[r+l] - l; i++)
			merge(l+i, r-i);
		
		mx[r+l] = min(mx[r+l], l);
		printf("%lld\n", power(26, ans));
	}
	return 0;
}
