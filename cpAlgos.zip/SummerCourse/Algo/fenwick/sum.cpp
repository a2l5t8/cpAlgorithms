#include<bits/stdc++.h>

using namespace std;

#define pb push_back
#define F first
#define S second
#define debug(x) cour<<#x<<" :"<<x<<"\n"
#define all(x) x.begin(),x.end()
#define pii pair<int,int>

typedef long long ll;
typedef long double ld;

const int maxn = 1e5 + 7;
const int mod = 1e9 + 7;
const int INF = 1e9 + 7;
const int mlog = 33;
const int SQ = 400;

int fen[maxn];

int n;
int a[maxn];

int sum(int ind) {
	ind++;
	int sm = 0;
	for(;ind>0;ind -= (ind & (-ind))) sm += fen[ind];
	return sm;
}

int sum(int l,int r){
	return sum(r) - sum(l-1);
}

void update(int ind,int val) {
	ind++;
	for(; ind <= n;ind += (ind & (-ind))) fen[ind] += val;
}

void build() {
	for(int i=0;i<n;i++) update(i,a[i]);
}

int main()
{
	cin>>n;
	for(int i=0;i<n;i++)
		cin>>a[i];

	build();

	int q;
	cin>>q;
	while(q--)
	{
		int l,r;
		cin>>l>>r;
	
		cout<<sum(l,r)<<"\n";
	}

	return 0;
}
