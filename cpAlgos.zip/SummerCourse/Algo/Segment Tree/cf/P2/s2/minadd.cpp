#include<bits/stdc++.h>

using namespace std;

#define int long long

const int maxn = 1e5 + 7;
const int INF = 1e16 + 7;

int seg[maxn*4],lazy[maxn*4];

int n,q;

void shift(int s,int e,int id)
{
	if(lazy[id] == 0)
		return;
	
	seg[id] += lazy[id];
	if(e - s < 2)
	{
		lazy[id] = 0;
		return;
	}

	lazy[id*2] += lazy[id];
	lazy[id*2 + 1] += lazy[id];

	lazy[id] = 0;
}

void update(int l,int r,int v,int s=0,int e=n,int id=1)
{
	if(l >= e || r <= s)
		return;
	
	shift(s,e,id);
	
	if(l <= s && r >= e)
	{
		lazy[id] += v;
		return;
	}

	int mid = (s+e)/2;

	update(l,r,v,s,mid,id*2);
	update(l,r,v,mid,e,id*2+1);

	seg[id] = min(seg[id*2] + lazy[id*2], seg[id*2 + 1] + lazy[id*2 + 1]);
}

int ans = INF;
void mini(int l,int r,int s=0,int e=n,int id=1)
{
	if(l >= e || r <= s)
		return;
	
	shift(s,e,id);

	if(l <= s && r >= e) 
	{
		ans = min(ans,seg[id]);
		return;
	}
	
	int mid = (s+e)/2;

	mini(l,r,s,mid,id*2);
	mini(l,r,mid,e,id*2 + 1);
}

int32_t main()
{
	cin>>n>>q;

	while(q--)
	{
		int command;
		cin>>command;

		if(command == 1)
		{
			int l,r,v;
			cin>>l>>r>>v;
			
			update(l,r,v);
		}else {
			int l,r;
			cin>>l>>r;

			ans = INF;
			mini(l,r);

			cout<<ans<<"\n";
		}
	}

	return 0;
}


/*

4 5
1 0 4 0
1 0 4 4
1 1 2 5
2 2 3
2 0 4

*/
