#include<bits/stdc++.h>

using namespace std;

#define pb push_back
#define F first
#define S second
#define debug(x) cerr<<#x<<" :"<<x<<"\n"
#define debug_seg(s,e) cerr<<"["<<s<<", "<<e<<"]\n"
#define all(x) x.begin(),x.end()
#define pii pair<int,int>
#define FAST ios_base::sync_with_stdio(false), cin.tie(), cout.tie()
#define int long long

typedef long long ll;
typedef long double ld;

const int maxn = 1e6 + 7;
const int mod = 1e9 + 7;
const int INF = 1e9 + 7;
const int mlog = 22;
const int SQ = 400;

int n,q;
int a[maxn];
int d[maxn];

int fen[maxn];
set<int> s;

void pre_process()
{	
	for(int i=1;i<maxn;i++)
		for(int j=i;j<maxn;j+=i)
			d[j]++;
}

void ADD(int ind,int val)
{
	for(;ind<=n;ind += (ind & (-ind))) fen[ind] += val;
}

int GET(int ind)
{
	int sum = 0;
	for(;ind > 0;ind -= (ind & (-ind))) sum += fen[ind];
	return sum;
}

void BUILD()
{
	for(int i=1;i<=n;i++)
		ADD(i,a[i]);
}

void SUM(int l,int r)
{
	cout<<GET(r) - GET(l-1)<<"\n";
	return;
}

void REPLACE(int l,int r)
{
	while(true)
	{
		auto it = s.lower_bound(l);
		if(it==s.end() || *it > r)
			break;
		
		l = *it;
		ADD(l, d[a[l]] - a[l]);
		a[l] = d[a[l]];

		if (a[l] <= 2)	
			s.erase(l);
		l++;
	}
}

int32_t main()
{
	FAST;

	cin>>n>>q;
	for(int i=1;i<=n;i++) {
		cin>>a[i];
		if(a[i] > 2)
			s.insert(i);
	}
	
	pre_process();

	BUILD();

	while(q--)
	{
		int t,l,r;
		cin>>t>>l>>r;
		
		if(t==1) REPLACE(l,r);
		else SUM(l,r);
	}

	return 0;
}
