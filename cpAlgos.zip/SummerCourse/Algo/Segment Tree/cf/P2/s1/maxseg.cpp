#include<bits/stdc++.h>

using namespace std;

const int maxn = 1e5 + 7;

int seg[maxn*4];
int lazy[maxn*4];

int n,q;

void shift(int s,int e,int id)
{
	if(lazy[id] == 0)
		return;
	
	seg[id] = max(seg[id],lazy[id]);
	if(e - s < 2)
	{
		lazy[id] = 0;
		return;
	}

	int mid = (s+e)/2;

	lazy[id*2] = max(lazy[id*2],lazy[id]);
	lazy[id*2 + 1] = max(lazy[id*2 + 1],lazy[id]);

	lazy[id] = 0;
}

void update(int l,int r,int v,int s=0,int e=n,int id=1)
{
	if(l >= e || r <= s)
		return;

	shift(s,e,id);

	if(l <= s && r >= e)
	{
		lazy[id] = max(lazy[id],v);
		return;
	}

	int mid = (s+e)/2;

	update(l,r,v,s,mid,id*2);
	update(l,r,v,mid,e,id*2 + 1);

	seg[id] = max(seg[id*2], seg[id*2 + 1]);
}

int num =0;
void get(int index,int s=0,int e=n,int id=1)
{
	if(index < s || index >= e)
		return;

	shift(s,e,id);
	
	if(e - s < 2)
	{
		num = seg[id];
		return;
	}

	int mid = (s+e)/2;

	get(index,s,mid,id*2);
	get(index,mid,e,id*2+1);
}

int main()
{
	cin>>n>>q;

	while(q--)
	{
		int command;
		cin>>command;
	
		if(command == 1)
		{
			int l,r,v;
			cin>>l>>r>>v;

			update(l,r,v);
		}else {
			int i;
			cin>>i;

			get(i);

			cout<<num<<"\n";
		}
	}

	return 0;
}

/*

40 7
1 12 21 33
1 4 24 36
1 30 36 28
2 2
2 20
1 3 37 16
2 24

*/
