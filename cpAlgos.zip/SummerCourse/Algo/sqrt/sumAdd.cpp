#include<bits/stdc++.h>

using namespace std;

const int maxn = 2e5 + 7;
const int SQRT = 5;

int a[maxn];
int d[SQRT];

void update(int i,int x)
{
	int pos = i/SQRT;
	int diff = x - a[i];
	a[i] = x;
	d[pos] += diff;
}

// [l,r]
int sum(int l,int r)
{
	int posl  = l/SQRT;
	int posr = r/SQRT;

	int sm = 0;

	if(posl == posr)
	{
		for(int i=l;i<=r;i++)
			sm+=a[i];

		return sm;
	}	
		
	for(int i=posl+1;i<posr;i++)
		sm += d[i];
	
	cout<<sm<<" <--1 \n";
	for(int i=l;i<(posl+1)*SQRT;i++)
		sm += a[i];
	
	cout<<sm<<" <--2 \n";
	for(int i=posr*SQRT;i<=r;i++)
		sm += a[i];

	cout<<sm<<" <--3 \n";

	return sm;
}

void build()
{
	for(int i=0;i<SQRT;i++)
		for(int j=i*SQRT;j<(i+1)*SQRT;j++)
			d[i] += a[j];
}

int main()
{
	int n;
	cin>>n;

	for(int i=0;i<n;i++)
		cin>>a[i];
	
	build();

	int q;
	cin>>q;
	while(q--)
	{
		int command;
		cin>>command;
		
		if(command == 1)
		{
			int i,x;
			cin>>i>>x;

			update(i,x);
		}else {
			int l,r;
			cin>>l>>r;

			cout<<sum(l,r)<<"\n";
		}	
	}

	return 0;
}
