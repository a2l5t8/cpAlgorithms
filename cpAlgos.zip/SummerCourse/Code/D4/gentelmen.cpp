#include<bits/stdc++.h>

using namespace std;

const int maxn = 1e5 + 7;

int a[maxn];

int main()
{
	int n;
	cin>>n;
	
	for(int i=1;i<=n;i++)
		cin>>a[i];
	

	return 0;
}
