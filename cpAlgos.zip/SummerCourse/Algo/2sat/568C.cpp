#include<bits/stdc++.h>

using namespace std;

#define ll long long
#define ull unsigned ll
#define uint unsigned
#define pii pair<int,int>
#define pll pair<ll,ll>
#define PB push_back
#define fi first
#define se second

#define For(i,j,k) for (int i=(int)(j);i<=(int)(k);i++)
#define Rep(i,j,k) for (int i=(int)(j);i>=(int)(k);i--)

const int N=405;
bitset<N> e[N];
int n,m,chr,vis[5];

char t[N],s[N],ans[N];

void dfs(int x,int y)
{
	if (x>n){
		cout<<ans+1<<"\n";
		exit(0);
	}

	int V=1,C=1;
	for(int i=1;i<x;i++)
	{
		V&=!e[i*2+t[ans[i]-'a']][x*2];
		V&=!e[x*2+1][i*2+1-t[ans[i]-'a']];

		C&=!e[i*2+t[ans[i]-'a']][x*2+1];
		C&=!e[x*2][i*2+1-t[ans[i]-'a']];
	}

	for(int i=(y?'a':s[x]);i<('a'+chr);i++) {
		if ((t[i-'a']&&V)||(!t[i-'a']&&C)) {
			ans[x]=i;
			dfs(x+1,y|(i>s[x]));
		}
	}
}
int main(){
	scanf("%s%d%d",t,&n,&m);
	chr=strlen(t);

	for(int i=0;i<chr;i++) 
		t[i]=(t[i]=='V');

	for(int i=0;i<chr;i++) 
		vis[t[i]]=1;

	for(int i=1;i<=n;i++)
	{
		if (!vis[0]) 
			e[i*2][i*2+1]=1;

		if (!vis[1]) 
			e[i*2+1][i*2]=1;
	}
	for(int i=1;i<=m;i++)
	{
		int x,y;
		char s1[5],s2[5];
		scanf("%d%s%d%s",&x,s1,&y,s2);

		x=x*2+(s1[0]=='V');
		y=y*2+(s2[0]=='V');

		e[x][y]=e[y^1][x^1]=1;
	}
	for(int k=2;k<=2*n+1;k++) 
		for(int i=2;i<=2*n+1;i++)
			if(e[i][k]) 
				e[i]|=e[k];

	for(int i=1;i<=n;i++)
		if (e[i*2][i*2+1] && e[i*2+1][i*2])
			return puts("-1"),0;

	scanf("%s",s+1);
	dfs(1,0);
	puts("-1");

	return 0;
}

