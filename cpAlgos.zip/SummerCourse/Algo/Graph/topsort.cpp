#include<bits/stdc++.h>

using namespace std;

const int maxn = 1e5 + 7;

vector<int> adj[maxn];
bool mark[maxn];

int n,m;

stack<int> tp;

void topsort(int v)
{	
	mark[v] = true;
	for(auto u : adj[v])
		if(!mark[u])
			topsort(u);
	tp.push(v);
}

int main()
{
	cin>>n>>m;

	for(int i=0;i<m;i++)
	{
		int u,v;
		cin>>u>>v;
		
		adj[u].push_back(v);
	}
	
	for(int i=1;i<=n;i++)
		if(!mark[i])
			topsort(i);

	while(!tp.empty())
	{
		cout<<tp.top()<<" ";
		tp.pop();
	}

	return 0;
}
