#include<bits/stdc++.h>

using namespace std;

#define pb push_back
#define F first
#define S second
#define debug(x) cour<<#x<<" :"<<x<<"\n"
#define all(x) x.begin(),x.end()
#define pii pair<int,int>

typedef long long ll;
typedef long double ld;

const int maxn = 1e5 + 7;
const int mod = 1e9 + 7;
const int INF = 1e9 + 7;
const int mlog = 30;
const int SQ = 400;

int n,m,q;
int a[maxn];

int rk[mlog][maxn];
int lg[maxn];

vector<int> adj[maxn];
vector<int> euler;

int stime[maxn],vtime[maxn];
void dfs(int v,int par=0) 
{	
	stime[v] = euler.size();
	vtime[euler.size()] = v;

	euler.pb(stime[v]);
	for(int u : adj[v]) {
		if(u != par) {
			dfs(u,v);
			euler.pb(stime[v]);
		}
	}

}

void pre_process()
{
	lg[1] = 0;
	for(int i=2;i<maxn;i++)
		lg[i] = lg[i/2] + 1;

	for(int i=0;i<euler.size();i++)
		rk[0][i] = euler[i];
	
	for(int i=1;i<mlog;i++)
		for(int j=0;j + (1<<i) <= euler.size();j++)
			rk[i][j] = min(rk[i-1][j],rk[i-1][j + (1<<(i-1))]);
}

int rmq(int l,int r)
{
	int LOG = lg[r-l];
	return min(rk[LOG][l],rk[LOG][r-(1<<LOG)]);
}

int LCA(int u,int v)
{
	if(stime[u] > stime[v])
		swap(u,v);
	
	return vtime[rmq(stime[u],stime[v]+1)];
}

int main()
{
	cin>>n;
	m = n-1;

	for(int i=0;i<m;i++)
	{
		int u,v;
		cin>>u>>v;

		adj[u].pb(v);
		adj[v].pb(u);
	}

	dfs(1);

	pre_process();

	cin>>q;
	while(q--)
	{
		int u,v;
		cin>>u>>v;

		cout<<LCA(u,v)<<"\n";
	}

	return 0;
}
