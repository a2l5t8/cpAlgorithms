#include<bits/stdc++.h>

using namespace std;

#define pb push_back
#define F first
#define S second
#define debug(x) cerr<<#x<<" :"<<x<<"\n"
#define debug_seg(s,e) cerr<<"["<<s<<", "<<e<<"]\n"
#define all(x) x.begin(),x.end()
#define pii pair<int,int>
#define FAST ios_base::sync_with_stdio(false), cin.tie(), cout.tie()
#define int long long

typedef long long ll;
typedef long double ld;

const int maxn = 1e5 + 7;
const int mod = 1e9 + 7;
const int INF = 1e9 + 7;
const int mlog = 22;
const int SQ = 400;

int n,q;
int x[maxn],y[maxn];
pii points[maxn];

int seg[mlog][maxn];

void merge(int s1,int e1,int s2,int e2,int d)
{	
    int i=s1,j=s2;

    int len1 = e1;
    int len2 = e2;

    int k = s1;
    while( (i<len1) || (j < len2) )
    {
        if( ((seg[d+1][i] < seg[d+1][j]) && (i<len1)) || (j >= len2))
        {
            seg[d][k] = seg[d+1][i];
            i++;
        }else {
            seg[d][k] = seg[d+1][j];
            j++;
        }
        k++;
    }
}


void build(int s=0,int e=n,int d=1)
{
    if(e - s < 2)
    {
        seg[d][s] = y[s];
        return;
    }

    int mid = (s+e)/2;
    build(s,mid,d+1);
    build(mid,e,d+1);

    merge(s,mid,mid,e,d);
}


int cnt = 0;

// [l,r);
void get(int l,int r,int k,int s=0,int e=n,int d=1)
{
    if(l >= e || r <= s)
        return;

    if(l <= s && r >= e) {
        int ind = upper_bound( (seg[d]+ s) ,(seg[d]+e) ,k) - seg[d] - s;
        cnt+= ind;

        return;
    }

    int mid = (s+e)/2;

    get(l,r,k,s,mid,d+1);
    get(l,r,k,mid,e,d+1);
}


int32_t main()
{
	FAST;

//  cin>>n>>q;
	scanf("%lld %lld",&n,&q);

	int w1,w2;
    for(int i=0;i<n;i++)
	{
		scanf("%lld %lld",&w1,&w2);
		points[i].F = w1;
		points[i].S = w2;
//        cin>>points[i].F>>points[i].S;
	}

    sort(points,points+n);

    for(int i=0;i<n;i++)
        x[i] = points[i].F,y[i] = points[i].S;

    build();

    int x1,y1,x2,y2,l,r,p1,p2;
    while(q--)
    {
//      cin>>x1>>y1>>x2>>y2;
		scanf("%lld %lld %lld %lld",&x1,&y1,&x2,&y2);

        l = lower_bound(x,x+n,x1) - x;
        r = upper_bound(x,x+n,x2) - x;

//      cout<<l<<" "<<r<<"<------------------\n";


        cnt = 0;
        get(l,r,y2);
        p1 = cnt;

//      cout<<p1<<"((((****)))) \n";

        cnt = 0;
        get(l,r,y1-1);
        p2 = cnt;
		
		printf("%lld\n",p1-p2);
//        cout<<p1-p2<<"\n";
    }

		

    return 0;
}

