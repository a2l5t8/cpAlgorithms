// O(klogk)

#include<bits/stdc++.h>

#define int long long

using namespace std;

const int maxn = 2e6 + 7;
const int INF = 1e9 + 7;

int a[maxn];
int mark[maxn];

int ans[maxn];

int n,k;

set<int> cands;

int32_t main()
{
	scanf("%lld %lld",&k,&n);
	
	for(int i=1;i<=k;i++)
	{
		scanf("%lld",a+i);
		if(a[i] < maxn)
			mark[a[i]]++;
	}
	
	int cnt=0;
	for(int i=1;i<=2*k + 1;i++)
	{
		if(!mark[i])
		{
			cands.insert(i);
			cnt++;
		}

		if(cnt >= k+1)
			break;
	}
	
	ans[1] = *cands.begin();
	mark[ans[1]]++;
	cands.erase(cands.begin());

	for(int i=2;i<=k+1;i++)
	{
		if(a[i-1] < maxn)
		{
			mark[a[i-1]]--;
			if(mark[a[i-1]] == 0)
				cands.insert(a[i-1]);
		}

		ans[i] = *cands.begin();
		mark[ans[i]] ++;
	    cands.erase(cands.begin());
	}
	ans[0] = ans[k+1];

	int rem = n-k;

	printf("%lld\n",ans[rem%(k+1)]);

		

	return 0;
}	
