#include<bits/stdc++.h>

using namespace std;

const int maxn = 1e5 + 7;

vector<pair<int,int>> adj[maxn];
int mark[maxn];

int n,m;

int cnt;
void dfs(int v,int type)
{
	cnt++;
	mark[v] = true;
	for(auto u : adj[v])
	{
		if(u.second == type && !mark[u.first])
		{
			dfs(u.first,type);
		}	
	}
}

bool isSCC()
{	
	cnt = 0;
	dfs(1,1);
	
	// whether a vertex can reach all other vertexies
	if(cnt != n)
		return false;

	for(int i=1;i<=n;i++)
		mark[i] = 0;
	

	cnt = 0;
	dfs(1,-1);

	// whether all other vertexies can reach a vertex
	if(cnt != n)
		return false;
	
	return true;
}

int main()
{
	cin>>n>>m;

	for(int i=0;i<m;i++) 
	{
		int u,v;
		cin>>u>>v;
		
		// directed edge from u -> v;
		adj[u].push_back({v,1});
		// directed reversed edge from v->u;
		adj[v].push_back({u,-1});
	}	
	
	if(isSCC())
		cout<<"Yes\n";
	else 
		cout<<"No\n";

	return 0;
}
