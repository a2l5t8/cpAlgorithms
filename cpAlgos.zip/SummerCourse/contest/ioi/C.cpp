#include<bits/stdc++.h>

using namespace std;

#define pb push_back

typedef long long ll;
typedef long double ld;

const int maxn = 5e5 + 7;
const int mod = 1e9 + 7;
const int INF = 1e9 + 7;
const int mlog = 30;
const int SQ = 400;

int n,k;

int a[maxn],dp[maxn],last_pos[maxn],pos[maxn];

int main()
{	
	cin>>n>>k;

	for(int i=1;i<=n;i++)
		cin>>a[i],pos[a[i]] = i;
	
	if(k == 0)
	{
		dp[0] = 0;
		dp[1] = pos[1];
		last_pos[1] = pos[1];

		for(int i=2;i<=n;i++)
		{
			if(last_pos[i-1] < pos[i]) {
				if(pos[i-1] >= last_pos[i-1] || abs(pos[i-1] - last_pos[i-1]) < abs(pos[i] - last_pos[i-1]))
					dp[i] = dp[i-1] + abs(pos[i] - last_pos[i-1]);
				else 
					dp[i] = dp[i-1] + abs(pos[i] - pos[i-1])/2 + 1 + (abs( (pos[i-1] + abs(pos[i] - pos[i-1])/2) - last_pos[i-1]));
			}else {
				
			}
		
		}


	}else if(k==n)
	{

	}

	return 0;
}
