#include<bits/stdc++.h>

using namespace std;

const int maxn = 1e5 + 7;

int n;
int a[maxn];

int fen1[maxn],fen2[maxn];

int SUM2(int ind) {
	ind++;
    int sum = 0;
    for(;ind>0;ind -= (ind & (-ind))) sum += fen2[ind];
    return sum;
}

int SUM1(int ind) {
	ind++;
	int sum = 0;
	for(;ind>0;ind -= (ind & (-ind))) sum += fen1[ind];
	return sum;
}

int GET(int ind) {
	return SUM1(ind)*ind - SUM2(ind);
}

int GET(int l,int r) {
	return GET(r)-GET(l-1);
}

void ADD(int ind,int val) {
	ind++;
	for(;ind <=n;ind += (ind & (-ind))) fen1[ind] += val;
}

void ADDR(int ind,int val) {
	ind++;
	for(;ind <=n;ind += (ind & (-ind))) fen2[ind] += val;
}

void ADD(int l,int r,int val) {
	ADD(l,val);
	ADD(r+1,-val);
	
	ADDR(l,val*(l-1));
	ADDR(r+1,-val*r);
}

void BUILD() {
	for(int i=0;i<n;i++) ADD(i,i,a[i]);
}

int main()
{
	cin>>n;
	for(int i=0;i<n;i++)
		cin>>a[i];
	
	BUILD();

	int q;
	cin>>q;
	while(q--)
	{
		int command;
		cin>>command;

		if(command == 1) {
			int l,r,v;
			cin>>l>>r>>v;

			ADD(l,r,v);
		}else {
			int l,r;
			cin>>l>>r;

			cout<<GET(l,r)<<"\n";
		}
	}

	return 0;
}
