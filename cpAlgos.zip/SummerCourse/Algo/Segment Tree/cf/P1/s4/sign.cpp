#include<bits/stdc++.h>

using namespace std;

const int maxn = 1e5 + 7;

int seg[maxn*4];

int n,q;
int a[maxn];

void build(int s=0,int e=n,int id=1)
{
	if(e - s < 2)
	{
		seg[id] = a[s];

		if(s % 2 == 1)
			seg[id] *= -1;

		return;
	}

	int mid = (s+e)/2;
	
	build(s,mid,id*2);
	build(mid,e,id*2+1);

	seg[id] = seg[id*2] + seg[id*2+1];
}

void update(int index,int v,int s=0,int e=n,int id=1)
{
	if( index < s || index >= e)
		return;
	
	if(e - s < 2)
	{
		seg[id] = v;
		
		if(s % 2 == 1)
			seg[id] *= -1;

		return;
	}

	int mid = (s+e)/2;

	update(index,v,s,mid,id*2);
	update(index,v,mid,e,id*2+1);

	seg[id] = seg[id*2] + seg[id*2 + 1];
}

int sum(int l,int r,int s=0,int e=n,int id=1)
{
	if(r <= s || l >= e)
		return 0;
	
	if(l <= s && r >= e)
		return seg[id];

	int mid = (s+e)/2;

	return sum(l,r,s,mid,id*2)
		  +sum(l,r,mid,e,id*2+1);
}


int main()
{
	cin>>n;
	for(int i=0;i<n;i++)
		cin>>a[i];

	build();
	
	cin>>q;
	while(q--)
	{
		int command;
		cin>>command;

		if(command == 0)
		{
			int i,j;
			cin>>i>>j;

			i--;

			update(i,j);
		}else {
			int l,r;
			cin>>l>>r;

			l--;

			int sm = sum(l,r);

			if(l % 2 == 1)
				sm *= -1;

			cout<<sm<<"\n";
		}
	}

	return 0;
}
