#include <bits/stdc++.h>
using namespace std;

const int maxn = 1e5;

int n;
bool mark[maxn];
string s, down[maxn];
vector<string> adj[maxn];

map<string, int> up;

bool dfs(int v) 
{
	mark[v] = true;
	for (string s: adj[v])
		if(up[s] == -1 || (mark[up[s]] == false && dfs(up[s]))) 
		{
			up[s] = v, 
			down[v] = s;
			return true;
		}
	return false;
}

int main() 
{
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
	
	cin >> n;
	for (int i = 0; i < n; i++) 
	{
		cin >> s;
		int l = s.length();
		for (int mask = 1; mask < (1 << l); mask++)
			if(__builtin_popcount(mask) <= 4) 
			{
				string t;
				for (int j = 0; j < l; j++)
					if(mask & (1 << j))
						t.push_back(s[j]);

				adj[i].push_back(t);
				up[t] = -1;
			}
	}

	while(true) 
	{
		bool canFind = false;

		memset(mark, false, sizeof mark);
		for (int i = 0; i < n; i++)
			if(down[i] == "" && mark[i] == false)
				canFind |= dfs(i);

		if(!canFind)
			break;
	}

	for (int i = 0; i < n; i++)
		if(down[i] == "") {
			cout << -1;
			return 0;
		}

	for (int i = 0; i < n; i++)
		cout << down[i] << '\n';
	return 0;
}

