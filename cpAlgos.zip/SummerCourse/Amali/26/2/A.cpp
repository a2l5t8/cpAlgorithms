#include<bits/stdc++.h>

using namespace std;

#define pb push_back
#define F first
#define S second
#define debug(x) cerr<<#x<<" :"<<x<<"\n"
#define all(a) a.begin(),a.end()

typedef long long ll;
typedef long double ld;

const int maxn = 3e5 + 7;
const int mod = 1e9 + 7;
const int INF = 1e9 + 7;
const int mlog = 30;
const int SQ = 400;

int n,m,k;

vector<int> adj[maxn];
int L[maxn],R[maxn],mark[maxn],c[maxn];
int psR[maxn],psL[maxn];

int nroot = 0;
vector<int> verts;

void pre_dfs(int v,int par=0)
{	
	verts.pb(v);
	for(auto u : adj[v])
		if(u != par)
			pre_dfs(u,v);
}	

int main()
{
	cin>>n>>k;

	for(int i=1;i<=n;i++)
		cin>>c[i];
	
	m = n-1;
	for(int i=0;i<m;i++)
	{
		int u,v;
		cin>>u>>v;

		adj[u].pb(v);
		adj[v].pb(u);
	}
	
	int root = 1;
	for(int i=1;i<=n;i++)
		if(adj[i].size() == 1)
			root = i;

	pre_dfs(root);

	for(int i=0;i<verts.size()-1;i++)
	{
		mark[c[verts[i]]]++;
		if(mark[c[verts[i]]] == 1)
			L[verts[i+1]]++;
	}
	
	for(int i=1;i<=k;i++)
		mark[i] = 0;

	for(int i=verts.size()-1;i>0;i--)
	{
		mark[c[verts[i]]]++;
		if(mark[c[verts[i]]] == 1)
			R[verts[i-1]]++;
	}
	
	psL[verts[0]] = L[verts[0]];
	for(int i=1;i<verts.size();i++)
		psL[verts[i]] = psL[verts[i-1]] + L[verts[i]];
	
	psR[verts[verts.size()-1]] = R[verts[verts.size()-1]];
	for(int i=verts.size()-2;i>=0;i--)
		psR[verts[i]] = psR[verts[i+1]] + R[verts[i]];

	for(int v=1;v<=n;v++)
		cout<<psR[v] + psL[v]<<" ";
	cout<<"\n";
	
	return 0;
}
