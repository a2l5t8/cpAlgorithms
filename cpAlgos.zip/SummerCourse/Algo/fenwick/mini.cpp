#include<bits/stdc++.h>

using namespace std;

const int maxn = 1e5 + 7;
const int INF = 1e9 + 7;

int n;
int a[maxn];

int fen[maxn];

int GET(int ind) {
	ind++;
	int mini = INF;
	for(;ind > 0;ind -= (ind & (-ind))) mini = min(mini,fen[ind]);
	return mini;
}

void UPDATE(int ind,int val) {
	ind++;
	for(;ind<=n;ind += (ind & (-ind))) fen[ind] = min(fen[ind],val);
}

void BUILD() {
	for(int i=0;i<=n;i++) fen[i] = INF;
	for(int i=0;i<n;i++) UPDATE(i,a[i]);
}

int main()
{
	cin>>n;
	for(int i=0;i<n;i++)
		cin>>a[i];

	BUILD();

	int q;
	cin>>q;
	while(q--)
	{
		int command;
		cin>>command;

		if(command == 1) {
			int ind,v;
			cin>>ind>>v;

			UPDATE(ind,v);
		}else {
			int ind;
			cin>>ind;

			cout<<GET(ind)<<"\n";
		}
	}

	return 0;
}
