#include<bits/stdc++.h>

using namespace std;

const int maxn = 1e5 + 7;

set<int> adj[maxn];
int mark[maxn],par[maxn];

//stack<int> path;
//int ans[maxn];

vector<int> ans;

int n,m,s,e;
bool flag = false;

void dfs(int v)
{
	if(flag)
		return;

	mark[v] = 1;
//	path.push(v);

	if(v == e && flag == false)
	{
		flag = true;
		return;
	}
	
//	cout<<"v :"<<v<<" =>";
	for(auto u : adj[v])
	{
		if(!mark[u])
		{
//			cout<<u<<" ";
			par[u] = v;
			dfs(u);
			if(flag)
				return;
			mark[u] = 0;
//			path.pop();
		}	
	}
//	cout<<"\n";
}

int main()
{
	ios_base::sync_with_stdio(0), cin.tie(0), cout.tie(0);

	cin>>n>>m>>s>>e;

	for(int i=0;i<m;i++)
	{
		int u,v;
		cin>>u>>v;
		
		adj[v].insert(u);
		adj[u].insert(v);
	}
	
	/*
	for(int i=1;i<=n;i++)
	{
		int v = i;
		cout<<v<<" =>";
		for(auto u : adj[v])
		{
			cout<<u<<" ";
		}
		cout<<"\n";
	}*/
	
	par[s] = -1;
	dfs(s);
	/*
	int k = path.size()-1;
	int kk = k;
	if(!flag)
	{
		cout<<"-1\n";
		return 0;
	}
	else {
		while(!path.empty())
		{
			ans[kk] = path.top();
			path.pop();
			kk--;
		}
	}*/

	if(!flag)
	{
		cout<<"-1\n";
		return 0;
	}

	int v = e;
	while(v != -1)
	{
		ans.push_back(v);
		v = par[v];
	}
	
	for(int i=ans.size()-1;i>=0;i--)
		cout<<ans[i]<<" ";
	cout<<"\n";

	return 0;
}

