#include <bits/stdc++.h>

using namespace std;

const int N =501*1000;

int n,q,strt[N],fnsh[N],now,seg1[4*N],seg2[4*N],max1,max2;
vector <int> adj[N];

void dfs(int v,int par=0)
{
	strt[v]=now++;
	for(auto u : adj[v])
		if(u!=par)
			dfs(u,v);

	fnsh[v]=now-1;
}

void build1(int L,int R,int s,int e,int id,int v)
{
	if (L>e || R<s)
		return;
	
    if(L==s && R==e){
		seg1[id]=v;
		return;
	}

    int l=id*2, r=l+1, mid=(e+s)/2;

    build1(L,min(mid,R),s,mid,l,v);
	build1(max(L,mid+1),R,mid+1,e,r,v);
}

void build2(int i,int s,int e,int id,int v)
{
	seg2[id]=v;
	
	if(s==e)
		return;

	int l=id*2 , r=l+1, mid=(e+s)/2;

    if(i<=mid)
		build2(i,s,mid,l,v);
	else 
		build2(i,mid+1,e,r,v);
}

void query1(int i,int s,int e,int id)
{
	max1=max(max1,seg1[id]);

	if(s==e)
		return;

	int l=id*2, r=l+1,mid=(e+s)/2;

    if(i<=mid)
		query1(i,s,mid,l);
	else
		query1(i,mid+1,e,r);
}


void query2(int L,int R,int s,int e,int id)
{
	if (L>e || R<s)
		return;

    if(L==s && R==e){
		max2=max(max2,seg2[id]);
		return;
	}

    int l=id*2,r=l+1,mid=(e+s)/2;

    query2(L,min(mid,R),s,mid,l);
	query2(max(L,mid+1),R,mid+1,e,r);
}

int main() 
{
	cin>>n;
	for(int i=0;i<n-1;i++)
	{
		int v,u;
		cin>>v>>u;

		adj[v].push_back(u);
		adj[u].push_back(v);
	}
	dfs(1,0);

	cin>>q;
	for(int i=1;i<=q;i++)
	{
		int c,v;
		cin>>c>>v;

		if(c==1)
			build1(strt[v],fnsh[v],0,n-1,1,i);
		if(c==2)
			build2(strt[v],0,n-1,1,i);
		if(c==3)
		{
			max1=0,max2=0;
			query1(strt[v],0,n-1,1);
			query2(strt[v],fnsh[v],0,n-1,1);
			

			cout<<(max1 > max2)<<"\n";
		}
	}
	
	return 0;
}
