#include<bits/stdc++.h>

using namespace std;

#define pb push_back

const int maxn = 1e5 + 7;

vector<pair<int,int>> adj[maxn];
int mark[maxn],component[maxn];

int n,m;

stack<int> tp;

void topsort(int v,int type)
{
	mark[v] = 1;
	for(auto u : adj[v])
		if(!mark[u.first] && type == u.second)
			topsort(u.first,type);

	tp.push(v);
}

void dfs(int v,int type,int comID)
{
	mark[v] = true;
	component[v] = comID;
	
	for(auto u : adj[v])
		if(!mark[u.first] && u.second == type)
			dfs(u.first,type,comID);
}

int comID = 1;
void SCC()
{	
	while(!tp.empty())
	{
		int v = tp.top();

		if(!mark[v]) 
		{
			dfs(v,-1,comID);
			comID++;
		}

		tp.pop();
	}
}	

int main()
{
	cin>>n>>m;

	for(int i=0;i<m;i++)
	{
		int u,v;
		cin>>u>>v;

		adj[u].pb({v,1});
		adj[v].pb({u,-1});
	}
	
	// topsort
	for(int i=1;i<=n;i++)
		if(!mark[i])
			topsort(i,1);

	for(int i=1;i<=n;i++)
		mark[i] = false;

	// Divide to Strongly Connected Components
	SCC();
	
	// printing each component
	for(int i=1;i<comID;i++) 
	{	
		cout<<"Component :"<<i<<"\n";
		for(int v=1;v<=n;v++)
			if(component[v] == i)
				cout<<v<<" ";
		cout<<"\n";
	}

	return 0;
}
