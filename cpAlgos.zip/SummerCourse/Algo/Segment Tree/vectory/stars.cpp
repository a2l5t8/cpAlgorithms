#include<bits/stdc++.h>

using namespace std;

#define pb push_back
#define xx first
#define yy second
#define debug(x) cour<<#x<<" :"<<x<<"\n"
#define all(x) x.begin(),x.end()
#define pii pair<int,int>

typedef long long ll;
typedef long double ld;

const int maxn = 1e5 + 7;
const int mlog = 33;

int n,q;
int x[maxn],y[maxn];
pii points[maxn];

int seg[mlog][maxn*4];

int tmp[maxn];
void merge(int s1,int e1,int s2,int e2,int d,int id)
{
    int i=0,j=0;

    int len1 = e1-s1;
    int len2 = e2-s2;

    int k = 0;
    while( (i<len1) || (j < len2) )
    {
        if( ((seg[d+1][id*2][i] < seg[d+1][id*2 + 1][j]) && (i<len1)) || (j >= len2))
        {
            tmp[k] = seg[d+1][id*2][i];
            i++;
        }else {
            tmp[k] = seg[d+1][id*2 + 1][j];
            j++;
        }
        k++;
    }

    for(int q=0;q<len1+len2;q++)
        seg[d][id].pb(tmp[q]);
}


void build(int s=0,int e=n,int d=1,int id=1)
{
    if(e - s < 2)
    {
        seg[d][id].pb(y[s]);
        return;
    }

    int mid = (s+e)/2;
    build(s,mid,d+1,id*2);
    build(mid,e,d+1,id*2 + 1);

    merge(s,mid,mid,e,d,id);
}


int cnt = 0;

// [l,r);
void get(int l,int r,int k,int s=0,int e=n,int d=1,int id=1)
{
    if(l >= e || r <= s)
        return;

    if(l <= s && r >= e) {
        int ind = lower_bound(seg[d][id].begin(),seg[d][id].end(),k) - seg[d][id].begin();
        cnt+= ind;

        return;
    }

    int mid = (s+e)/2;

    get(l,r,k,s,mid,d+1,id*2);
    get(l,r,k,mid,e,d+1,id*2 + 1);
}


int main()
{
	cin>>n>>q;

	for(int i=0;i<n;i++)
		cin>>points[i].xx>>points[i].yy;

	sort(points,points+n);
	for(int i=0;i<n;i++)
		x[i] = points[i].xx,y[i] = points[i].yy;

	build();

	int x1,y1,x2,y2,l,r,p1,p2;
	while(q--)
	{
		cin>>x1>>y1>>x2>>y2;

		l = lower_bound(x,x+n,x1) - x;
		r = upper_bound(x,x+n,x2) - x;

//		cout<<l<<" "<<r<<"<------------------\n";
			

		cnt = 0;
		get(l,r,y2);
		p1 = cnt;

//		cout<<p1<<"((((****)))) \n";

		cnt = 0;
		get(l,r,y1);
		p2 = cnt;
		
		cout<<p1-p2<<"\n";
	}

	return 0;
}
