#include <bits/stdc++.h>

using namespace std;

#define ll int

const int maxn =  1e6 + 7;
const int SQ = 400 + 7;

ll n,q,a[maxn];
pair <ll,ll> par[maxn];

void build(ll x)
{
	ll l=x*SQ;
	ll r=min(n,(x+1)*SQ)-1;

	for(int i=r;i>=l;i--)
	{
		if(i+a[i]>r)
			par[i]={1,i};
		else 
			par[i]={par[i+a[i]].first+1,par[i+a[i]].second};
	}
}

int main()
{
    ios_base::sync_with_stdio(0);cin.tie(0);cout.tie(0);
    cin>>n>>q;

	for(int i=0;i<n;i++)
		cin>>a[i];

	for(int i=0;i<(n+SQ-1)/SQ;i++)
		build(i);

	while(q--)
	{
		ll t;
		cin>>t;

		if(t==0)
		{
			ll x,y;
			cin>>x>>y;
			x--;

			a[x]=y;
			build(x/SQ);
		}
		else
		{
			ll x,res=0,last;

			cin>>x;
			x--;

			while(x<n)
			{
				res+=par[x].first;
				last=par[x].second;
				x=par[x].second+a[par[x].second];
			}
			cout<<last+1<<" "<<res<<"\n";
		}
	}
	return 0;
}
