#include<bits/stdc++.h>

using namespace std;

const int maxn = (1<<19);
const int INF = 1e9 + 7;

int segtree1[4*maxn],segtree2[4*maxn];

vector<int> adj[maxn];
int stime[maxn],etime[maxn];

int timer = 0;
void dfs(int v,int par)
{
	stime[v] = timer++;
	for(auto u : adj[v])
		if(u != par)
			dfs(u,v);
	etime[v] = timer-1;
}

int build1(int L,int R,int s,int e,int id,int v)
{
	if(L >= e || R <= s)
		return segtree1[id];
	
	if(L <= s && R >= e) {
		segtree1[id] = v;
		return segtree1[id];
	}

	int mid = (e+s)/2;
	segtree1[id] = max(build1(L,R,s,mid,id*2+1,v),
					   build1(L,R,mid,e,id*2+2,v));
	
	return segtree1[id];
}

int build2(int s,int e,int index,int id,int v)
{	
	if(index < s || index >=e)
		return segtree2[id];

	if(e - s < 2) {
		segtree2[id] = v;
		return segtree2[id];
	}
	
	
	int mid = (e+s)/2;
	segtree2[id] = max(build2(s,mid,index,id*2+1,v),
					   build2(mid,e,index,id*2+2,v));

	return segtree2[id];
}

int mm = 0;
int query1(int s,int e,int index,int id)
{	
//	if(index < s || index >= e)
//		return segtree1[id];

	if(e - s < 2) 
		return segtree1[id];

	int mid = (s+e)/2;
	if(index < mid)
		return max(segtree1[id],query1(s,mid,index,id*2+1));
	else 
		return max(segtree1[id],query1(mid,e,index,id*2+2));
}

int mm2 = 0;
int query2(int L,int R,int s,int e,int id)
{	
    if(e <= L || s >= R)
        return (-INF);
	
	if(L <= s && R >= e)
		return segtree2[id];

	int mid = (s+e)/2;
	return max(segtree2[id],
		   max(query2(L,R,s,mid,id*2+1),
			   query2(L,R,mid,e,id*2+2)));
}

int main()
{
	int n,m;
	cin>>n;

	m = n-1;
	for(int i=0;i<m;i++)
	{
		int u,v;
		cin>>u>>v;
		
		adj[u].push_back(v);
		adj[v].push_back(u);
	}

	dfs(1,0);

	int q;
	cin>>q;

	for(int i=1;i<=q;i++)
	{
		int c,v;
		cin>>c>>v;

		if(c==1) {
			build1(stime[v],etime[v]+1,0,n,0,i);
		}
		else if(c==2) {
			build2(0,n,stime[v],0,i);
		}
		else {
			int max1 = query1(0,n,stime[v],0);
			int max2 = query2(stime[v],etime[v]+1,0,n,0);

			cout<<max1<<" "<<max2<<" <--\n";
			
			cout<<(max1 > max2)<<"\n";
		}
			
	}

	return 0;
}
/*
10
2 1
3 2
4 3
5 4
4 6
3 7
4 8
9 4
10 2
10
1 3
1 1
3 10


1 3
2 6
2 10
3 4
2 10
1 2
3 1

*/
