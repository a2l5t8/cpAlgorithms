#include<bits/stdc++.h>

using namespace std;

const int maxn = 1e5 + 7;

long double a[maxn];

int n,k;

bool cut(long double v)
{
	int cnt = 0;
	for(int i=0;i<n;i++)
		cnt += (int)floor(a[i]/v);

	if(cnt >= k)
		return true;
	return false;
}	

void solve()
{
	long double l = 0;
	long double r = 1e16 + 7;
	
	long double ans=0;
	while(r - l > 0.000001)
	{
		long double mid = (l+r)/2;

		if(cut(mid))
			l = mid,ans = l;
		else 
			r = mid;
	}

	cout<<setprecision(6)<<fixed<<ans<<"\n";
}

int main()
{
	cin>>n>>k;

	for(int i=0;i<n;i++)
		cin>>a[i];

	solve();

	return 0;
}
