#include <bits/stdc++.h> 
  
using namespace std; 

const int maxn = 2*1e6 + 7;

int arr[maxn];

long long cnt = 0;
  
void heapify(int n, int i) 
{ 
    int smallest = i;
    int l = 2*i + 1; 
    int r = 2*i + 2; 
 
    if (l < n && arr[l] < arr[smallest]) 
        smallest = l; 
  
    if (r < n && arr[r] < arr[smallest])
        smallest = r;
  
    if (smallest != i) 
    { 
        swap(arr[i], arr[smallest]);
		cnt++;
  
        heapify(n, smallest); 
    } 
}

void heapSort(int n)
{
	for(int i=n-1;i>=0;i--)
		heapify(n,i);

    for (int i=n-1;i>=0; i--)
    {
        swap(arr[0], arr[i]);
		cnt++;


        heapify(i, 0);
    }
}

int main()
{
	int n;
	cin>>n;
	
	for(int i=0;i<n;i++)
		cin>>arr[i];

	heapSort(n);
	
	/*
	for(int i=0;i<n;i++)
		cout<<arr[i]<<" ";
	cout<<"\n"<<cnt;
	*/
	
	cout<<cnt<<"\n";
	return 0;
}
