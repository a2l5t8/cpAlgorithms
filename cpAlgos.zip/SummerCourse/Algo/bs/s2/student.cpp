#include<bits/stdc++.h>

using namespace std;

typedef long long ll;

const int maxn = 50 + 7;

ll a[maxn];

ll k,n;

bool cmp(ll a,ll b)
{
	return a > b;
}

bool council(ll v)
{	
	ll ab[maxn];
	for(int i=0;i<n;i++)
		ab[i] = a[i];
	
	ll g = v;

	sort(ab,ab+n,cmp);
	while(ab[k-1] > 0)
	{	
		cout<<ab[k-1]<<"\n";

		ll mn = ab[k-1];
		for(int i=0;i<k;i++)	
			ab[i] -= mn;

		g-=mn;
		sort(ab,ab+n,cmp);
	}

	if(g > 0ll)
		return false;
	return true;
}

void solve()
{
	ll l = 0;
	ll r = 1e10 + 7;
	
	ll ans=0;
	while(r >= l)
	{	
		ll mid = (l+r)/2;
		if(council(mid))
			l = mid+1ll,ans = mid;
		else 
			r = mid-1ll;
	}

	cout<<ans<<"\n";
}

int main()
{
	cin>>k>>n;

	for(int i=0;i<n;i++)
		cin>>a[i];
	
	solve();

	return 0;
}
