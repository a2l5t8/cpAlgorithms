#include<bits/stdc++.h>

using namespace std;

#define x first
#define y second

const int maxn = 1e3 + 7;

char a[maxn][maxn];
int h[maxn][maxn];

int hc[maxn*maxn];

int dx4[4] = {0,0,-1,1};
int dy4[4] = {1,-1,0,0};

int n,m,cows;
int outx,outy;

bool check(int x,int y)
{
	if(x <= n && x >= 1 && y <= m && y >= 1 && h[x][y] == 0 && a[x][y] != '#')
		return true;
	return false;
}

int main()
{
	cin>>n>>m;

	for(int i=1;i<=n;i++) { 
		for(int j=1;j<=m;j++) {
			cin>>a[i][j];
			if(a[i][j] == 'C')
				cows++;
		
			if((i==n && a[i][j]=='.')||(i==1 && a[i][j] == '.')||(j==1 && a[i][j] == '.')||(j==m && a[i][j] == '.'))
				outx = i,outy = j;
		}
	}
	
	h[outx][outy] = 1;

	queue<pair<int,int>> q;
	q.push({outx,outy});
	
	int seenc = 0;
	int maxh = 1;
	while(!q.empty())
	{
		auto v = q.front();
		for(int i=0;i<4;i++)
		{
			int nx = v.x+dx4[i];
			int ny = v.y+dy4[i];
			
			if(check(nx,ny))
			{
				h[nx][ny] = h[v.x][v.y] + 1;
				
				if(a[nx][ny] == 'C') {
					seenc++;
//					cout<<nx<<" "<<ny<<"\n";
					hc[h[nx][ny]]++;
					maxh = max(maxh,h[nx][ny]);
				}

				q.push({nx,ny});
			}
		}
		q.pop();
	}

	if(seenc != cows)
		return cout<< -1 <<"\n",0;

	int total = 0;
	for(int i=2;i<=m*n;i++)
		if(hc[i] != 0)
			total += hc[i]-1;
	
	total += maxh;
	if(cows == 0)
		total = 0;

	cout<<total<<"\n";

	return 0;
}
