#include<bits/stdc++.h>

using namespace std;

const int maxn = 700 + 7;
const int INF = 1e8 + 7;

vector<int> adj[maxn];
int mark[maxn],height[maxn],par[maxn];

int n,m;
int g = INF;

int bfs(int v,int max_h)
{
	queue<int> q;
	q.push(v);

	memset(height, -1, sizeof(height));
    memset(mark, 0, sizeof(mark));
	memset(par,0,sizeof(par));

	mark[v] = 1;
	height[v] = 0;

	while(!q.empty())
	{
		int v = q.front();

		for(auto u : adj[v])
		{
			if(!mark[u])
			{	
				par[u] = v;
				q.push(u);
				height[u] = height[v] + 1;
				mark[u] = 1;
			}else if(u != par[v]){
				g = min(g, (height[v] + 1) + height[u]);
			}
		}
		q.pop();
	}

	return INF;
}

int girth()
{
	for(int i=1;i<=n;i++)
		g = min(g,bfs(i,g));		
	
	return g;
}

int main()
{
	cin>>n>>m;
	
	int u,v;
	for(int i=0;i<m;i++)
	{
		cin>>u>>v;
		
		adj[v].push_back(u);
		adj[u].push_back(v);
	}

	int res = girth();

	if(res == INF)
		res = -1;

	cout<<res<<"\n";

	return 0;
}
