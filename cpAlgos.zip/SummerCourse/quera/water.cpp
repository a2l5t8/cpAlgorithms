#include<bits/stdc++.h>

using namespace std;

const int maxn = 1e6 + 7;
const int INF = 1e9 + 7;

int a[maxn];

int L[maxn],R[maxn];

int n;

int main()
{
	cin>>n;
	for(int i=0;i<n;i++)
		cin>>a[i];

	L[0] = INF;
	int maxL = a[0];

	for(int i=1;i<n;i++)
	{
		if(a[i] > maxL)
		{
			maxL = a[i];
			L[i] = INF;
			continue;
		}	

		L[i] = maxL;
	}

	R[n-1] = INF;
	int maxR = a[n-1];
	for(int i=n-2;i>=0;i--)
	{
		if(a[i] > maxR)
		{
			maxR = a[i];
			R[i] = INF;
			continue;
		}
		
		R[i] = maxR;
	}

	int ans =0;
	for(int i=0;i<n;i++)
		if(R[i] != INF && L[i] != INF)
			ans += min(R[i],L[i]) - a[i];

	cout<<ans<<"\n";

	return 0;	
}
