#include<bits/stdc++.h>

using namespace std;

#define pb push_back
#define FAST ios_base::sync_with_stdio(false), cin.tie(), cout.tie()

typedef long long ll;
typedef long double ld;

const int maxn = 2e5 + 7;
const int mod = 1e9 + 7;
const int INF = 1e9 + 7;

int NO = 1e9;

vector<pair<int,int>> adj[maxn];

int N,D,U,Q;
int h[maxn];

bool cmp(pair<int,int> v,pair<int,int> u)
{
	if(h[v.first] == h[u.first])
		return v.second < u.second;
	return h[v.first] < h[u.first];
}

int lower(int v,int u,int d)
{
	int l = 0;
	int r = adj[v].size() - 1;

	int ans = -1;
	while(r >= l)
	{
		int mid = (l+r)/2;
		if(adj[v][mid].first >= u && adj[v][mid].second <= d)
			r = mid-1,ans = mid;
		else 
			l = mid+1;
	}

	return ans;
}

int upper(int v,int u,int d)
{
	int l = 0;
	int r = adj[v].size()-1;
	
	int ans = -1;
	while(r >= l)
	{
		int mid = (l+r)/2;
		if(adj[v][mid].first > mid  && adj[v][mid].second <= d)
			r = mid-1,ans = mid;
		else 
			l = mid+1;
	}

	return ans;
}

bool isFriend(int v,int u,int d)
{
	int low = lower(v,u,d);
	int up = upper(v,u,d);

	if(up == -1 || low == -1)
		return false;

	if((up - low) % 2 == 1)
		return true;
	return false;
}


int minDis(int x,int y,int d)
{
	int res = NO;

	int p1,p2;
	p1 = p2 = 0;

	while(p1 < adj[x].size() || p2 < adj[y].size())
	{
		if(!isFriend(x,adj[x][p1].first,d))
		{
			p1++;
			p1 = min((int)adj[x].size(),p1);
			continue;
		}

		if(!isFriend(y,adj[y][p2].first,d))
		{
			p2++;
			p2 = min((int)adj[y].size(),p2);
			continue;
		}
		
		res = min(res, abs(h[p1]-h[p2]));
		if((h[p1] < h[p2] && p1 < adj[x].size()) || (p2 >= adj[y].size()))
			p1++;
		else 
			p2++;
	}

	return res;
}

int main()
{
	FAST;
	
	cin>>N>>D>>U>>Q;
	
	for(int i=0;i<N;i++)
		cin>>h[i];

	for(int i=1;i<=U;i++)
	{
		int a,b;
		cin>>a>>b;

		adj[a].push_back({b,i});
		adj[b].push_back({a,i});
	}
	
	for(int i=0;i<N;i++)
		sort(adj[i].begin(),adj[i].end(),cmp);

	while(Q--)
	{
		int x,y,v;
		cin>>x>>y>>v;

		cout<<minDis(x,y,v)<<endl;						
	}

	return 0;
}
