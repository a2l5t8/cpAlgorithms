#include<bits/stdc++.h>

using namespace std;

const int maxn = 1e5 + 7;

vector<int> adj[maxn];

int mark[maxn],ptr[maxn];

int from[maxn],to[maxn];

int n,m;

stack<int> euler;

void dfs(int v)
{
	while(ptr[v] < adj[v].size())
	{
		int id = adj[v][ptr[v]++];
		if(mark[id])
			continue;

		int u = from[id] + to[id] - v;
		mark[id] = true;
		dfs(u);
	}

	euler.push(v);
}

int main()
{
	cin>>n>>m;

	for(int i=1;i<=m;i++)
	{
		int v,u;
		cin>>v>>u;

		adj[v].push_back(i);
		adj[u].push_back(i);
  
		from[i] = v;
		to[i] = u;
	}

	dfs(1);

	while(!euler.empty())
	{
		cout<<euler.top()<<" ";
		euler.pop();
	}

	return 0;
}
