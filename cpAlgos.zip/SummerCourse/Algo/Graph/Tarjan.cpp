#include<bits/stdc++.h>

using namespace std;

const int maxn = 1e5 + 7;

vector<int> adj[maxn];
int component[maxn];

stack<int> st;

int dfs_time[maxn],low[maxn],in_stack[maxn];
int compID = 1;
int timer = 0;

int n,m;

void dfs(int v)
{
	dfs_time[v] = low[v] = ++timer;

	st.push(v);
	in_stack[v] = true;

	for(auto u : adj[v])
	{
		if(!dfs_time[u])
		{
			dfs(u);
			low[v] = min(low[v],low[u]);
		}else if(in_stack[u]) {
			low[v] = min(low[v],low[u]);
		}
	}

	if(low[v] == dfs_time[v])
	{
		while(st.top() != v)
		{
			component[st.top()] = compID;
			in_stack[st.top()] = false;

			st.pop();
		}
		component[st.top()] = compID;
		in_stack[st.top()] = false;

		st.pop();

		compID++;
	}
}


int main()
{
	cin>>n>>m;

	for(int i=0;i<m;i++)
	{
		int u,v;
		cin>>u>>v;

		adj[u].push_back(v);
	}
	
	for(int i=1;i<=n;i++)
		if(!dfs_time[i])
			dfs(i);

	for(int i=1;i<compID;i++)
	{	
		cout<<"component :"<<i<<"\n";
		for(int v = 1;v<=n;v++)
			if(component[v] == i)
				cout<<v<<" ";
		cout<<"\n";
	}
	return 0;
}
