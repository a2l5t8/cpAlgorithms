#include <bits/stdc++.h>

using namespace std;

const int maxn = 2 * 1e6 + 7;

int dp[maxn];
string s;

int f(int x)
{
	if (x == 1)
		return 0;

	if (dp[x])
		return dp[x];
	
	dp[x] = f(x / 2) + f((x + 1) / 2) + x;
	return dp[x];
}

int ans[maxn];
int sec1[maxn], sec2[maxn];

void merge_sort(int sl, int sr, int ansl, int ansr)
{
	int len = ansr-ansl+1;
	
	if (len == 1)
	{
		ans[ansl] = 1;
		return;
	}
	if (len == 2)
	{
		ans[ansl] = s[sl] - '0' + 1;
		ans[ansr] = s[sr] - '0' + 1;
		return;
	}
	
	int mid1 = len/ 2;
	int mid2 = (len+ 1) / 2;
	
	merge_sort(sl, sl + f(mid1) - 1, ansl, ansl + mid1 - 1);
	merge_sort(sl + f(mid1), sl + f(mid1) + f(mid2) - 1, ansl + mid1, ansr);
	

	for(int i=0;i<mid1 + 7;i++)
		sec1[i] = 0;
	for(int i=0;i<mid2 + 7;i++)
		sec2[i] = 0;

	int cnt = 1;
	int p1 = 0, p2 = 0;
	for(int i=sl + f(mid1) + f(mid2);i<=sr;i++)
	{
		if (s[i] == '0')
			sec1[p1++] = cnt++;
		else
			sec2[p2++] = cnt++;
	}
	
	for(int i=ansl;i<ansl + mid1;i++)
		ans[i] = sec1[ans[i] - 1];

	for(int i=ansl + mid1;i<=ansr;i++)
		ans[i] = sec2[ans[i] - 1];
}

int main()
{
	ios::sync_with_stdio(false); cin.tie(0); cout.tie(0);

	cin >> s;
	int n = s.size();

	int l = 0, r = n + 1;
	while (r - l > 1)
	{
		int mid = (r + l) / 2;
		if (f(mid) >= n)
		{
			r = mid;
		}
		else
		{
			l = mid;
		}
	}
	
	merge_sort(0, n - 1, 0, r - 1);

	for(int i=0;i<r;i++)
		cout<<ans[i]<<" ";

	return 0;
}
