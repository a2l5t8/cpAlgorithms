#include<bits/stdc++.h>

using namespace std;

const int maxn = 1e5 + 7;

int a[maxn],lm[maxn];


// given an array of integers 
// the objective is to fill the array "lm" such that :"
// "lm[i]" => max(j) -> j<i && a[j] < a[i];
int main()
{
	int n;
	cin>>n;

	for(int i=0;i<n;i++)
	{
		cin>>a[i];
		lm[i] = -1;
	}

	stack<int> st;
	
	for(int i=0;i<n;i++)
	{
		while(!st.empty())
		{
			int j = st.top();
			if(a[j] < a[i])
			{
				lm[i] = j;
				break;
			}else {
				st.pop();
			}
		}
		st.push(i);
	}

	for(int i=0;i<n;i++)
		cout<<lm[i]<<" ";

	return 0;
}
