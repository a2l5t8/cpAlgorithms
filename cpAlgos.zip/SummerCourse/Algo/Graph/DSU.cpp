#include<bits/stdc++.h>

using namespace std;

const int maxn = 1e5 + 7;

pair<int,int> edges[maxn];

int par[maxn];

int find(int v)
{
	if(par[v] == -1)
		return v;
	
	return find(par[v]);
}

void merge(int v,int u)
{
	int comV = find(v);
	int comU = find(u);
	
	if(comV != comU)
		par[u] = v;
}

int n,m;

int main()
{
	cin>>n>>m;
	
	for(int i=0;i<m;i++)
	{
		int u,v;
		cin>>u>>v;

		edges[i] = {u,v};
	}
	
	for(int i=0;i<=n;i++)
		par[i] = -1;
	
	bool hasCycle = false;
	for(int i=0;i<m;i++)
	{
		auto edge = edges[i];

		int x = find(edge.first);
		int y = find(edge.second);

		if(x == y)
			hasCycle = true;

		merge(x,y);
	}

	if(hasCycle)
		cout<<"Yes\n";
	else 
		cout<<"No\n";
}
