#include<bits/stdc++.h>

using namespace std;

const int maxn = 1e6 + 7;

int n;
string s;

int f[maxn];
bool isPrefix[maxn];

void kmp()
{
	int curr=0;
	for(int i=1;i<n;i++)
	{
		while(curr > 0  && s[curr] != s[i])
			curr = f[curr];

		if(s[curr] == s[i])
			curr++;

		f[i+1] = curr;
	}

}

int main()
{
	cin>>s;

	n = s.size();

	kmp();

//	for(int i=0;i<n;i++)
//		cout<<f[i]<<" ";
//	cout<<"\n";
	
	int curr = n-1;
	while(curr > 0)
	{
//	while(curr > 0 && s[curr] != 0)
		if(s[f[curr]] == s[n-1])
			isPrefix[f[curr]] = true;
		curr = f[curr];
	}

	if(s[0] != s[n-1])
		isPrefix[0] = false;
	
	isPrefix[n-1] = true;
	for(int i=0;i<n;i++)
	{
		if(isPrefix[i])
			cout<<1;
		else
			cout<<0;
	}
//	cout<<"\n";

	return 0;
}	
