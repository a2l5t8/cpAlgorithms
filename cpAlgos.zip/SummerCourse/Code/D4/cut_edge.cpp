#include<bits/stdc++.h>

using namespace std;

#define pb push_back

const int maxn = 100000 + 7;

vector<pair<int,int>> graph[maxn];

int mark[maxn],par[maxn],hig[maxn];
int dp[maxn];

pair<int,int> edge[maxn];
set<int> res;

void dfs(int v,int index,int root)
{
    mark[v] = 1;
    dp[v] = hig[v];
    for(int i=0;i<graph[v].size();i++)
    {
        int u=graph[v][i].first;
        int inde=graph[v][i].second;

        if(!mark[u])
        {
            hig[u] = hig[v]+1;
            par[u] = v;
            dfs(u,inde,root);
            dp[v] = min(dp[v],dp[u]);
        }else {
            if(u != par[v] && hig[u] < hig[v])
            {
                dp[v] = min(dp[v],hig[u]);
            }
        }
    }
	if(v!=root)
        if(dp[v] >= hig[v])
            res.insert(index);
	return;
}

int main()
{
    int n,m;
    cin>>n>>m;

    for(int i=1;i<=m;i++)
    {
        int u,v;
        cin>>u>>v;

        edge[i]=make_pair(u,v);
        graph[u].pb(make_pair(v,i));
        graph[v].pb(make_pair(u,i));
    }
	
	for(int i=1;i<=n;i++)
		if(!mark[i])
		    dfs(i,0,i);

	cout<<res.size()<<"\n";
   	for(auto u : res)
		cout<<u<<" ";

    return 0;
}

