#include<bits/stdc++.h>

using namespace std;

#define pb push_back
#define F first
#define S second
#define debug(x) cerr<<#x<<" :"<<x<<"\n"
#define debug_seg(s,e) cerr<<"["<<s<<", "<<e<<"]\n"
#define all(x) x.begin(),x.end()
#define pii pair<int,int>
#define FAST ios_base::sync_with_stdio(false), cin.tie(), cout.tie()
#define int long long

typedef long long ll;
typedef long double ld;

const int maxn = 3e5 + 7;
const int mod = 1e9 + 7;
const int INF = 1e9 + 7;
const int mlog = 22;
const int SQ = 400;

int n,q;
int a[maxn];

int seg[mlog][maxn];

void merge(int s1, int e1,int s2, int e2, int d)
{
	int i=s1,j=s2;
	int k=s1;
	
	while(i < e1 || j < e2)
	{
		if( (seg[d+1][i] < seg[d+1][j] && (i<e1)) || (j>=e2) )
		{
			seg[d][k] = seg[d+1][i];
			i++;
		}else {
			seg[d][k] = seg[d+1][j];
			j++;
		}
		
		k++;
	}
}

void BUILD(int s=0,int e=n,int d=0)
{
	if(e - s < 2)
	{
		seg[d][s] = a[s];
		return;
	}

	int mid = (s+e)/2;
	BUILD(s,mid,d+1);
	BUILD(mid,e,d+1);

	merge(s,mid,mid,e,d);
}

int cnt = 0;
void SOLVE(int l,int r,int k,int s=0,int e=n,int d=0)
{
	if(l >= e || r <= s)
		return;
	
	if(l <= s && r >= e)
	{
		int x = upper_bound( (seg[d]+s), (seg[d]+e), k) - seg[d] - s;
		cnt += (e-s)-x;
		return;
	}
	
	int mid = (s+e)/2;
	SOLVE(l,r,k,s,mid,d+1);
	SOLVE(l,r,k,mid,e,d+1);
}

int32_t main()
{
	FAST;

	cin>>n;
	for(int i=0;i<n;i++)
		cin>>a[i];

	BUILD();
	
	cin>>q;
	while(q--)
	{
		int l,r,k;
		cin>>l>>r>>k;
		l--;

		cnt = 0;
		SOLVE(l,r,k);

		cout<<cnt<<"\n";
	}

	return 0;
}
