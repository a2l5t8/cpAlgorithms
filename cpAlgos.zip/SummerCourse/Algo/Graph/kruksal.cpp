#include<bits/stdc++.h>

using namespace std;

const int maxn = 1e5 + 7;

int par[maxn];

int find(int v)
{
	if(par[v] == -1)
		return v;
	
	return find(par[v]);
}

void merge(int u,int v)
{
	int uroot = find(u);
	int vroot = find(v);
	
	if(uroot != vroot)
		par[uroot] = vroot;
}

struct Edge
{
	int from;
	int to;
	int weight;
};

Edge edges[maxn];

int n,m;

bool cmp(Edge a,Edge b)
{
	return a.weight < b.weight;
}

int mst()
{	
	for(int i=1;i<=n;i++)	
		par[i] = -1;
	
	int ans = 0;
	sort(edges,edges+m,cmp);

	int e = 0;
	for(int i=0;i<m;i++)
	{
		int u = find(edges[i].from);
		int v = find(edges[i].to);

		if(u != v)
		{
			ans += edges[i].weight;
			merge(u,v);
			e++;
		}

		if(e == n-1)
			break;
	}

	return ans;
}


int main()
{
	cin>>n>>m;

	for(int i=0;i<m;i++)
	{
		int u,v,w;
		cin>>u>>v>>w;

		edges[i] = {u,v,w};
	}

	cout<<mst()<<"\n";
	
	
}
