#include<bits/stdc++.h>

using namespace std;

const int maxn = 1e5 + 7;
const int INF = 2*1e9 + 7;

int a[maxn];

int n,k;

int bs(int v)
{
	int l = 1;
	int r = n+1;
	
	int mid,ans=0;
	while(r>=l)
	{
		mid = (l+r)/2;

		if(a[mid] < v)
			l = mid + 1;
		else 
			r = mid-1,ans = mid;
	}

	return ans;
}

int main()
{
	cin>>n>>k;

	for(int i=1;i<=n;i++)
		cin>>a[i];
	a[n+1] = INF;
	while(k--)
	{
		int c;
		cin>>c;
		
		cout<<bs(c)<<"\n";
	}

	return 0;
}
