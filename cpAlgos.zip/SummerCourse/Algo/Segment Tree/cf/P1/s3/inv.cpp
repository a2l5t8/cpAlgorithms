#include<bits/stdc++.h>

using namespace std;

const int maxn = 1e5 + 7;

int seg[maxn*4];

int n;
int a[maxn];

void update(int index,int s=1,int e = n+1,int id=1)
{
	if(index < s || index >= e)
		return;

	if(e - s < 2)
	{
		seg[id] = 1;
		return;
	}

	int mid = (s+e)/2;
	update(index,s,mid,id*2);
	update(index,mid,e,id*2+1);

	seg[id] = seg[id*2] + seg[id*2+1];
}

int sumSeg(int l,int r = n+1,int s=1,int e = n+1,int id=1)
{
	if(l >= e || r <= s)
		return 0;

	if(l <= s && r >= e)
		return seg[id];

	int mid = (s+e)/2;
	
	return sumSeg(l,r,s,mid,id*2)
		  +sumSeg(l,r,mid,e,id*2+1);
}

int main()
{
	cin>>n;
	for(int i=1;i<=n;i++)
		cin>>a[i];
	
	for(int i=1;i<=n;i++)
	{
		cout<<sumSeg(a[i])<<" ";
		update(a[i]);
	}

	cout<<"\n";
	
	return 0;
}
