#include<bits/stdc++.h>

using namespace std;

typedef long long ll;

const ll INF = 31623000000000 + 1;

ll n,w,h;

bool build(ll len)
{
	return ( ((len/w)*(len/h)) >= n);
}

void solve()
{	
	ll l = 1;
	ll r = INF;
	
	ll ans;
	while(r >= l)
	{
		ll mid = (l+r)/2;
		cout<<mid<<"\n";
		if(build(mid))
			r = mid-1,ans = mid;
		else 
			l = mid+1;
	}

	cout<<ans<<"\n";
}

int main()
{
	cin>>w>>h>>n;

//	if(min(w,h) < 1e9 )
//		INF = 1e9 + 7;

	solve();

	return 0;
}
