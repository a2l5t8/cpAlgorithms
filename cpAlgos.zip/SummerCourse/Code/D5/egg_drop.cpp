#include<bits/stdc++.h>

using namespace std;

const int maxn = 21;
const int maxk = 1e6 + 7;

const int INF = 1e9 + 7;

int maxfloor[maxk][maxn];
int mf[maxk][maxn];

void process(int n,int k)
{
	for(int i=0;i<=n;i++)
	{
		for(int j=0; j<=k;j++)
		{
			if(j==0 || i==j) {
				maxfloor[i][j] = 1;
				mf[i][j];
			}
			else {
				maxfloor[i][j] = maxfloor[i-1][j-1] + maxfloor[i-1][j] + 1;
			}
		}
	}
}

int main()
{
	int n,e;
	cin>>n>>e;
	
	n -= 1;

	int cntlog = 0;
	int tmp = n;

	bool p2 = true;
	while(tmp > 0)
	{

		if(tmp%2==1 && tmp != 1)
			p2 = false;

		cntlog++;
		tmp /= 2;

	}

	if(p2)
		cntlog--;

	process(n,min(e+1,21));
	
	cntlog = max(cntlog,0);
	if(n==1)
		return cout<< 0 <<"\n",0;
	
	if(e >= cntlog && e>20) 
		return cout<<cntlog<<"\n",0;

	if(e==2)
		return cout<<ceil((-1.0 + sqrt(1 + 8*n))/2.0)<<"\n",0;
	
	
	int l = 0,r = n;

//	cout<<maxfloor[4][e]<<"\n";
	while(l < r)
	{
		int mid = (l+r)/2;
		if(maxfloor[mid][e] < n)
		{
			l = mid+1;
		}else {
			r = mid;
		}
	}
	
	cout<<r<<"\n";
}
