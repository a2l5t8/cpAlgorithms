#include<bits/stdc++.h>

using namespace std;

const int maxn = 1e5 + 7;

set<int> adj[maxn];
int par[maxn],mark[maxn];

vector<int> ans;
bool flag = false;

int n,m,s,e;

void bfs(int s)
{
	queue<int> q;
	mark[s] = 1;
	
	q.push(s);
	while(!q.empty())
	{
		int v = q.front();
		for(auto u : adj[v])
		{
			if(!mark[u])
			{
				par[u] = v;
				mark[u] = 1;
				q.push(u);
				if(u == e)
				{
//					cout<<par[u]<<"sdf";
					flag = true;
					return;
				}
			}
		}
		q.pop();
	}
}

int main()
{
	ios_base::sync_with_stdio(0), cin.tie(0), cout.tie(0);

	cin>>n>>m>>s>>e;

	for(int i=0;i<m;i++)
	{
		int u,v;
		cin>>u>>v;
		
		adj[v].insert(u);
		adj[u].insert(v);
	}
	
	par[s] = -1;
	bfs(s);

	if(!flag)
	{
		cout<<"-1\n";
		return 0;
	}else {
		int	v = e;
		while(v != -1)
		{
			ans.push_back(v);
			v = par[v];
		}

		for(int i=ans.size()-1;i>=0;i--)
			cout<<ans[i]<<" ";
		cout<<"\n";
	}

	return 0;
}
