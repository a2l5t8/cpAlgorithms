#include<bits/stdc++.h>

using namespace std;

const int maxn = 1e5 + 7;

int n;
int a[maxn];

int fen[maxn];

int GET(int ind) {
	ind++;
	int sm = 0;
	for(;ind > 0;ind -= (ind & (-ind))) sm += fen[ind];
	return sm;
}

void ADD_RANGE(int ind,int val) {
	ind++;
	for(;ind <= n;ind+=(ind & (-ind))) fen[ind] += val;
}

void ADD(int l,int r,int v) {
	ADD_RANGE(l,v);
	ADD_RANGE(r+1,-v);
}

void BUILD() {
	for(int id=0;id<n;id++) ADD(id,id,a[id]);
}

int main()
{
	cin>>n;
	for(int i=0;i<n;i++)
		cin>>a[i];

	BUILD();

	int q;
	cin>>q;

	while(q--)
	{
		int command;
		cin>>command;

		if(command == 1) {
			int l,r,v;
			cin>>l>>r>>v;

			ADD(l,r,v);
		}else {
			int ind;
			cin>>ind;

			cout<<GET(ind)<<"\n";
		}
	}

	return 0;
}
