#include<bits/stdc++.h>

using namespace std;

const int maxn = 1e5 + 7;
const int INF = 1e9 + 7;

int n,m;

int start_time[maxn],finish_time[maxn],ps[maxn];

vector<pair<int,int>> adj[maxn];
int mark[maxn],comps[maxn],comSize[maxn];

vector<int> com_adj[maxn];

stack<int> tp;

void topsort(int v,int type)
{
	mark[v] = true;
	for(auto u : adj[v])
		if(!mark[u.first] && u.second == type)
			topsort(u.first,type);
	
	tp.push(v);
}

int compID = 1;
void dfs(int v,int type,int cmpID)
{
	mark[v] = true;
	comps[v] = cmpID;
	comSize[cmpID]++;
	
	for(auto u : adj[v])
		if(!mark[u.first] && u.second == type)
			dfs(u.first, type, cmpID);
}

void SCC()
{
	while(!tp.empty())
	{
		int v = tp.top();

		if(!mark[v])
		{
			dfs(v, -1, compID);
			compID++;
		}

		tp.pop();
	}
}

void dag(int v)
{
	mark[v] = true;
	for(auto u : adj[v])
	{
		if(!mark[u.first] && u.second == 1)
		{
			if(comps[u.first] != comps[v])
				com_adj[comps[v]].push_back(comps[u.first]);

			dag(u.first);
		}else if(u.second == 1 && comps[u.first] != comps[v])
				com_adj[comps[v]].push_back(comps[u.first]);
	}

}

int ans;
int timer = 1;
void final_dfs(int v,int par)
{
	start_time[v] = timer;
	timer++;

	ps[v] = comSize[v] + ps[par];

	ans = max(ans,comSize[v] + comSize[par]);
	for(auto u : com_adj[v])
	{
		if(!start_time[u])
			final_dfs(u,v);
		else if(start_time[v] <= start_time[u] && finish_time[v] >= finish_time[u])
			ans = max(ans,ps[u] - ps[v] + comSize[v]);
	}

	finish_time[v] = timer;
}	

int main()
{
	cin>>n>>m;
	
	for(int i=0;i<m;i++)
	{
		int u,v;
		cin>>u>>v;
		
		adj[u].push_back({v,1});
		adj[v].push_back({u,-1});
	}
	
	// topological sort
	for(int i=1;i<=n;i++)
		if(!mark[i])
			topsort(i,1);
	
	// clear
	for(int i=1;i<=n;i++)
		mark[i] = 0;
	
	// Strongly Connected Components
	SCC();

	for(int i=1;i<=n;i++)
		mark[i] = 0;

	// finding edges between SCCs
	for(int i=1;i<=n;i++)
		if(!mark[i])
			dag(i);

	// maximum component size
	compID--;
	for(int i=1;i<=compID;i++)
		ans = max(ans,comSize[i]);

	for(int i=1;i<=n;i++)
		finish_time[i] = INF;
	
	for(int i=1;i<=compID;i++)
		if(!start_time[i])
			final_dfs(i,0);
	
	cout<<ans<<"\n";

	return 0;
}
