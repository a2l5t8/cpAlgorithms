#include<bits/stdc++.h>

using namespace std;

const int maxk = 1e5 + 7;

int k,query;

priority_queue<pair<int,int>> heads;

queue<int> q[maxk];

void show()
{
	if(heads.empty())
	{
		cout<<"all empty\n";
		return ;
	}

	cout<<heads.top().first<<"\n";
	int bread = heads.top().second;

	heads.pop();
	q[bread].pop();
	
	if(!q[bread].empty())
		heads.push({q[bread].front(),bread});
	return ;
}

int main()
{
	ios_base::sync_with_stdio(0), cin.tie(0), cout.tie(0);

	cin>>query>>k;

	cin.ignore();

	string p1,p2;
	while(query--)
	{
		string s;
		getline(cin,s);
		
		if(s == "?") {
			show();
		}
		else {
//			cout<<s.size()<<"\n";
			
			p1 = " ";
			int i;
			for(i=2;i<s.size();i++)
			{
				if(s[i] == ' ')
					break;
				p1 += s[i];
			}
			
			p2 = " ";
			for(int j = i+1;j<s.size();j++)
			{
				if(s[j] == ' ')
					break;
				p2 += s[j];
			}

					
			int cult = stoi(p1);
			int group = stoi(p2);

			q[group].push(cult);
			if(q[group].size() == 1)
				heads.push({cult,group});
		}
	}
	
	return 0;
}
