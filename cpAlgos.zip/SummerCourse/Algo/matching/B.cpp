#include<bits/stdc++.h>

using namespace std;

const int maxn = 1e3 + 7;

vector<int> adj[maxn];
int mark[maxn],match[maxn];

int cover[maxn];

int n1,n2,m;

bool dfs(int v)
{
	mark[v] = true;
	for(auto u : adj[v])
	{	
		if(match[u] == -1 || (!mark[match[u]] && dfs(match[u])))
		{
			match[u] = v;
			match[v] = u;

			return true;
		}
	}

	return false;
}

void matching()
{
	for(int i=1;i<=(n1+n2);i++)
		match[i] = -1;
	
	while(true)
	{
		bool canFind = false;
		memset(mark,0,sizeof(mark));
		
		for(int v=1;v<=n1;v++) 
			if(!mark[v] && match[v] == -1) 
				canFind |= dfs(v);

		if(!canFind)
			break;
	}
}

void cov(int v,bool state)
{
	if(state)
		cover[v] = true;

	mark[v] = true;
	for(auto u : adj[v])
		if(!mark[u] && (match[u] != -1 && !cover[match[u]]))
			cov(u,true);
}

void covering()
{

	memset(mark,0,sizeof(mark));
	for(int i=1;i<=n1;i++)
		if(match[i] == -1)
			cov(i,false);

	memset(mark,0,sizeof(mark));
	for(int i=n1+1;i<=(n1+n2);i++)
		if(match[i] == -1)
			cov(i,false);

	
	for(int i=1;i<=(n1+n2);i++)
		if(match[i] != -1 && !cover[match[i]])
			cover[i] = true;
}

int main()
{
	cin>>n1>>n2>>m;

	for(int i=0;i<m;i++)
	{
		int u,v;
		cin>>u>>v;

		adj[u].push_back(v);
		adj[v].push_back(u);
	}

	matching();
	
	covering();

	for(int i=1;i<=n1+n2;i++)
		if(cover[i])
			cout<<i<<" ";

	cout<<"\n";

	return 0;
}
