#include<bits/stdc++.h>

using namespace std;

#define pb push_back

typedef long long ll;
typedef long double ld;

const int maxn = 1e5 + 7;
const int mod = 1e9 + 7;
const int INF = 1e9 + 7;
const int mlog = 30;
const int SQ = 400;

vector<int> adj[maxn];
int	subh[maxn];

vector<int> h[maxn];

int n,m;

void dfs(int v,int par=0)
{
	for(int u : adj[v])
	{
		if(u != par)
		{
			dfs(u,v);
			maxh[v] = max(maxh[v],maxh[u] + 1);
		}
	}
}

int main()
{
	cin>>n;
	m = n-1;

	for(int i=0;i<m;i++)
	{
		int u,v;
		cin>>u>>v;
		

		adj[v].pb(u);
		adj[u].pb(v);
	}

	dfs(1);

	for(int i=1;i<=n;i++)
		h[maxh[i]].pb(i);

	int cnt = 0;
	for(int k=n;k>0;k--)
	{
		

	}

	return 0;
}












