#include<bits/stdc++.h>

using namespace std;

const int maxn = 80;

char adj[maxn][maxn];
int mark[maxn];

int n,m;

int main()
{
	cin>>n;

	for(int i=0;i<n;i++)
		for(int j=0;j<n;j++)
			cin>>adj[i][j];		

	for(int i=0;i<n;i++)
		adj[i][i] = '1';
	
	vector<int> guards;
	for(int mask=1;mask<(1<<n);mask++)
	{
		for(int i=0;i<n;i++)
			mark[i] = 0;
		guards.clear();
		for(int i=0;i<n;i++)
			if(mask & (1<<i))
				guards.push_back(i);

		for(int v : guards)
			for(int u=0;u<n;u++)
				if(adj[v][u] == '1')
					mark[u] = 1;
		
		int cnt = 0;
		for(int i=0;i<n;i++)
			if(mark[i])
				cnt++;

		if(cnt == n)
			break;
	}
	
	cout<<guards.size()<<"\n";
	for(int v : guards)
		cout<<v<<" ";
	cout<<"\n";

	return 0;
}
