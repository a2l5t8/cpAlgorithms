#include<bits/stdc++.h>

using namespace std;

const int maxn = 500;

int dp[maxn][maxn];

int main()
{
	string a,b;
	cin>>a>>b;

	int n = a.size(),m = b.size();

	for(int i=0;i<n;i++)
	{
		for(int j=0;j<m;j++)
		{
			int ii = max(i-1,0), jj = max(j-1,0);
			dp[i][j] = max(dp[ii][j],max(dp[i][jj],dp[ii][jj] + (a[i] == b[j])));
		}
	}


	cout<<dp[n-1][m-1];

	return 0;
}
