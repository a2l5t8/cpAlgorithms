#include<bits/stdc++.h>

using namespace std;

const int maxn = 1e5 + 7;
const int mod = 1e9 + 7;
const int INF = 1e9 + 7;

int n,m,k;

vector<pair<int,pair<int,int>>> adj[maxn];
//vector<pair<pair<int,int>,int>> edges;

int main()
{
	cin>>n>>k;
	
	m = n-1;

	int sm = 0;
	for(int i=0;i<m;i++)
	{
		int u,v,l,r;
		cin>>u>>v>>l>>r;

		adj[u].push_back({v,{l,r}});
		adj[v].push_back({u,{l,r}});

		sm += l;
	}
	
	k -= sm;
	if(k < 0)
		return cout<<1<<"\n",0;

	

	return 0;
}
