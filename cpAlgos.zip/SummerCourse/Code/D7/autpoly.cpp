#include<bits/stdc++.h>

using namespace std;

#define x first
#define y second

typedef long long ll;

const int maxn = 500 + 7;
const long double INF = 1e16 + 7;

ll n,m;

pair<ll,ll> red[maxn],blue[maxn];

vector<pair<ll,long double>> adj[maxn];

bool isInside(pair<ll,ll> A,pair<ll,ll> B,pair<ll,ll> C)
{
	ll pos = (B.x - A.x)*(C.y-A.y) - (B.y - A.y)*(C.x-A.x);
	if(pos < 0)
		return true;
	return false;
}

long double dis(pair<ll,ll> A,pair<ll,ll> B)
{
	return sqrt((1.0*(A.x-B.x)*(A.x-B.x)) + 1.0*((A.y - B.y)*(A.y-B.y)));
}

long double d[maxn][maxn];
void floyd()
{
	for(int i=1;i<=n;i++)
		for(int j=1;j<=n;j++)
			if(!d[i][j])
				d[i][j] = INF;

	for(int k=1;k<=n;k++)
        for(int i=1;i<=n;i++)
            for(int j=1;j<=n;j++)
                d[i][j] = min(d[i][j],d[i][k] + d[k][j]);
}

vector<pair<pair<ll,ll>,long double>> norms;

int main()
{
	ios_base::sync_with_stdio(false), cin.tie(), cout.tie();

	cin>>n>>m;

	for(int i=1;i<=n;i++)
		cin>>red[i].x>>red[i].y;

	for(int i=1;i<=m;i++)
		cin>>blue[i].x>>blue[i].y;

	for(int i=1;i<=n;i++)
	{
		for(int j=1;j<=n;j++)
		{
			if(i==j)
				continue;

			auto A = red[i];
			auto B = red[j];

			bool flag = true;
			for(int z=1;z<=m;z++)
				if(!isInside(A,B,blue[z]))
					flag = false;
			
			if(flag)
			{	
				long double w = dis(A,B);
				adj[i].push_back({j,w});
				d[i][j] = w;
				norms.push_back({{i,j},w});
			}
		}
	}
	
	floyd();

	long double ans = INF;
	for(int i=0;i<norms.size();i++)
	{
		ll u = norms[i].first.first;
		ll v = norms[i].first.second;
		
		ans = min(ans,d[v][u] + d[u][v]);
	}
	if(ans >= INF)
		return cout<<"NO\n",0;
	cout<<setprecision(3)<<fixed<<ans<<"\n";


	return 0;
}
