#include<bits/stdc++.h>

using namespace std;

#define pb push_back
#define int long long

typedef long long ll;
typedef long double ld;

const int maxn = 5e5 + 7;
const int mod = 1e9 + 7;
const int INF = 1e9 + 7;
const int mlog = 30;
const int SQ = 400;

int a[maxn],lis[maxn];
int n;

ll power(ll a,ll b)
{
    if(b==0ll)
        return 1ll;

    ll x = (power(a,b/2))%mod;

    x = (x*x)%mod;
    if(b%2==1)
    {
        x = (x*a)%mod;
    }

    return x;
}

int32_t main()
{
	cin>>n;
	for(int i=0;i<n;i++)
		cin>>a[i];

	int ans = 0;

	if(n > 20)
	{
		for(int i=1;i<n;i++)
		{
			lis[i] = 1;
			for(int j=0;j < i;j++)
				if(a[i] > a[j] && lis[i] < lis[j] + 1)
					lis[i] = lis[j] + 1;
		}

		for(int i=0;i<n;i++)
			cout<<lis[i]<<" ";
		cout<<"\n";

		for(int i=0;i<n;i++)
			ans = (ans + power(2,lis[i]-1))%mod;

		return cout<<ans<<"\n",0;
	}

	for(int mask = 1;mask<(1<<n);mask++)
	{
		if(__builtin_popcount(mask) == 1) {
			ans++;
			continue;
		}

		vector<int> x;

		for(int i=0;i<n;i++) {
			if(mask & (1<<i))
				x.pb(i);
		}
		
		bool flag = true;
		for(int i=0;i<x.size()-1;i++) {
			if(a[x[i]] > a[x[i+1]])
				flag = false;

			for(int j=x[i]+1;j<x[i+1];j++) {
				if(a[j] < a[x[i]] || a[j] > a[x[i+1]])
					flag = false;
			}
		}

		if(flag)
			ans++;
	}

	cout<<(ans)%mod<<"\n";

	return 0;
}
