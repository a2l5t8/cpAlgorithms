#include<bits/stdc++.h>

using namespace std;

const int maxn = 1e5 + 7;

string s,t;

int f[maxn],ans[maxn];

void preprocess()
{
	int curr = 0;
	for(int i=1;i<t.size();i++)
	{	
		while(curr > 0 && t[i] != t[curr])
			curr = f[curr];

		if(t[curr] == t[i])
			curr++;

		f[i+1] = curr;
	}
}


int main()
{
	cin>>s>>t;

	preprocess();

	int cnt = 0;
	int curr = 0;
	for(int i=0;i<s.size();i++)
	{
		while(curr > 0 && t[curr] != s[i])
			curr = f[curr];

		if(s[i] == t[curr])
			curr++;

		ans[i+1] = curr;
		if(ans[i+1] == t.size())
		{
			curr = f[curr];
			cnt++;
		}
	}

	cout<<cnt<<"\n";

	return 0;
}
