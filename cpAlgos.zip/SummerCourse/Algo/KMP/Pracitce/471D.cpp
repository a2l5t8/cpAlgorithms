#include<bits/stdc++.h>

using namespace std;

const int maxn = 2e5 + 7;

int a[maxn],b[maxn];
int n,w;

int f[maxn];
void kmp()
{
    int curr = 0;
    for(int i=1;i<w;i++)
    {
        while(curr > 0 && b[i] != b[curr])
            curr = f[curr];

       	curr++;
        f[i+1] = curr;
    }
}


int solve()
{
	kmp();

	int ans = 0;

	int curr = 0;
	for(int i=0;i<n+1;i++)
	{
		while(curr > 0 && a[i] != b[curr])
			curr = f[curr];

		curr++;
		if(curr >= w)
		{
			ans++;
			curr = f[curr];
		}
	}
	return ans;
}

int main()
{
	cin>>n>>w;

	for(int i=0;i<n;i++)
	{
		cin>>a[i];
		if(i != 0)
			a[i-1]= a[i] - a[i-1];
	}

	for(int j=0;j<w;j++)
	{
		cin>>b[j];
		if(j != 0)
			b[j-1] = b[j] - b[j-1];
	}

	if(w == 1)
		return cout<<n<<"\n",0;
	
	n--;
	w--;
	
	cout<<solve()<<"\n";
	
	return 0;
}
