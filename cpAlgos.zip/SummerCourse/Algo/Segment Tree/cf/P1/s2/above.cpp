#include<bits/stdc++.h>

using namespace std;

const int maxn = 1e5 + 7;

int seg[maxn*4];

int n,q;
int a[maxn];

void build(int s=0,int e=n,int id=1)
{
	if(e - s < 2)
	{
		seg[id] = a[s];
		return;
	}

	int mid = (s+e)/2;
	
	build(s,mid,id*2);
	build(mid,e,id*2+1);

	seg[id] = max(seg[id*2], seg[id*2+1]);
}

void update(int index,int v,int s=0,int e=n,int id=1)
{
	if(index >= e || index < s)
		return;
	
	if(e - s < 2)
	{
		seg[id] = v;
		return;
	}

	int mid = (s+e)/2;

	update(index,v,s,mid,id*2);
	update(index,v,mid,e,id*2+1);

	seg[id] = max(seg[id*2], seg[id*2+1]);
}

int first_above(int x,int l,int s=0,int e=n,int id=1)
{
	if(e - s < 2)
	{
		if(seg[id] >= x)
			return s;	

		return -1;
	}
	
	int mid = (s+e)/2;
	if(l >= mid)
	{
		if(seg[id*2 +1] >= x)
			return first_above(x,l,mid,e,id*2+1);

		return -1;
	}

	if(seg[id*2] < x)
	{
		if(seg[id*2 +1] >= x) 
            return first_above(x,l,mid,e,id*2+1);

        return -1;
	}

	int p1 = first_above(x,l,s,mid,id*2);
	if(p1 != -1)
		return p1;

	if(seg[id*2 + 1] >= x)
		return first_above(x,l,mid,e,id*2+1);

	return -1;
}

int main()
{
	cin>>n>>q;
	
	for(int i=0;i<n;i++)
		cin>>a[i];

	build();
	
	while(q--)
	{
		int command;
		cin>>command;

		if(command == 1)
		{
			int i,v;
			cin>>i>>v;

			update(i,v);
		}else {
			int x,l=0;
			cin>>x>>l;

			cout<<first_above(x,l)<<"\n";
		}
	}

	return 0;
}
