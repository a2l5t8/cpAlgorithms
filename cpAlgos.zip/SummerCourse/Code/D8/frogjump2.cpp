#include<bits/stdc++.h>

using namespace std;

#define int long long

const int maxn = 3e5 + 7;
const int maxp = 1e2 + 7;
const int INF = 1e18 + 7;

int a[maxn],dp[maxp][maxn],maxdp[maxn];

int32_t main()
{
	ios_base::sync_with_stdio(false), cin.tie(), cout.tie();

	int n,k,p;
	cin>>n>>k>>p;

	for(int i=0;i<n;i++)
		cin>>a[i];

	for(int i=0;i<=p;i++)
		for(int j=0;j<n;j++)
			dp[i][j] = -INF;

	dp[0][0] = a[0];

	deque<int> dq;
	for(int i=1;i<=p;i++)
	{
		dq.clear();
		for(int r=0;r<n;r++)
		{
			int l = r-k+1;
			while(!dq.empty() && dp[i-1][dq.back()] <= dp[i-1][r])
				dq.pop_back();

			dq.push_back(r);
			while(!dq.empty() && dq.front() < l)
				dq.pop_front();

			maxdp[r] = dq.front();
		}

		for(int j=n-1;j >=0;j--)
			dp[i][j] = -INF;

        for(int j=n-1;j >= 0;j--)
            dp[i][j] = dp[i-1][maxdp[j-1]] + a[j];

        for(int j=i-1;j>=0;j--)
			dp[i][j] = -INF;
	}

	cout<<dp[p][n-1]<<"\n";

	return 0;
}
