#include<bits/stdc++.h>

using namespace std;

const int maxn = 2e5 + 7;

int a[maxn];

string s,t;
int n;

bool petya(int v)
{
	string tmp;
	vector<int> dele;
	
	for(int i=0;i<min(v,n);i++)
		dele.push_back(a[i]);
	
	sort(dele.begin(),dele.end());
	int j = 0;
	dele.push_back(-1);
	for(int i=0;i<n;i++)
	{
		if(i != dele[j])
			tmp.push_back(s[i]);
		else
			j++;
	}

//	cout<<v<<"->"<<tmp<<"\n";
	j = 0;
	int m  = t.size();
	int len = tmp.size();
	for(int i=0;i<len;i++)
	{
		if(tmp[i] == t[j])
			j++;
		
		if(j > m-1)
			return true;
	}
	
	return false;
}

void solve()
{
	int l = 0;
	int r = 2e5 + 7;
	
	int ans=0;
	while(r >= l)
	{	
		int mid = (l+r)/2;
		if(petya(mid))
			l = mid+1,ans = mid;
		else 
			r = mid-1;
	}

	cout<<ans<<"\n";
}	

int main()
{
	cin>>s>>t;
	
	n = s.size();
	for(int i=0;i<n;i++)
		cin>>a[i],a[i]--;

	solve();

	return 0;
}
