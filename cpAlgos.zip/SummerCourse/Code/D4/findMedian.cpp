#include<bits/stdc++.h>

using namespace std;

// max heap
priority_queue<int> s;

// min heap
priority_queue<int, vector<int>,greater<int>> g;

int med = -1;
int inMin = 0;

void addNum(int x)
{
	if(s.size() > g.size())
	{
		if(x < med)
		{
			g.push(s.top());
			s.pop();
			s.push(x);
		}else {
			g.push(x);
		}

		med = s.top();
	}

	else if(s.size() == g.size())
	{
		if(x < med)
		{
			s.push(x);
			med = s.top();
		}else {
			g.push(x);
			med = g.top();
		}
	}

	else 
	{
		if (x > med)
		{
			s.push(g.top());
			g.pop();
			g.push(x);
		}else {
			s.push(x);
		}

		med = s.top();
	}
}

int main()
{
	int n;
	cin>>n;

	for(int i=0;i<n;i++)
	{
		int a;
		cin>>a;

		addNum(a);
	}

	cout<<med<<"\n";

	return 0;
}
